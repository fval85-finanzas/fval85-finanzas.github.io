# 💰 Mis Finanzas

App personal de finanzas para **Android y iPhone**, hecha con **Google Sheets + Apps Script**.
Lleva tarjetas de crédito, cuentas, compras a tasa cero, sobres de presupuesto y el préstamo de casa, en **colones (₡) y dólares ($)**.

Las compras se registran **solas** leyendo los correos del banco en Gmail, y los pagos del préstamo
se cargan desde el comprobante `.txt` que manda el BCR.

![Pantallas](docs/muestra-pantallas-1.jpg)

## Cómo funciona

```
Correo del banco ──► Gmail ──► Apps Script (servidor) ──► Google Sheet (base de datos)
                                     ▲
                                     │  pedidos con clave (JSON)
                                     │
                     App en GitHub Pages (instalable en Android / iPhone)
```

Misma estructura que *Registro de Cajuelas*: la app es una PWA en GitHub Pages y Apps Script solo recibe y entrega datos (`doPost`), protegido con una clave.

## Qué hace

- **Inicio:** gastado del mes en ₡ y $ (con cuotas tasa cero), ingresos, lo que queda, sobres, próximos pagos.
- **Movimientos:** buscador y filtros por banco, moneda y "por revisar"; agregar, editar, eliminar; pasar una compra a tasa cero; crear reglas de categoría.
- **Tarjetas:** saldo ₡/$, uso del límite, días para pagar y compras a tasa cero de cada tarjeta.
- **Sobres:** presupuesto mensual por sobre, con aviso cuando se está acabando.
- **Préstamo:** saldo, estimado de la próxima cuota (TBP del mes anterior + 3), historial completo y días de anticipo.
- **Configuración:** tema claro/oscuro/automático, ocultar montos, PIN de acceso, recordatorios por correo.
- **Automático:** lectura de correos sin duplicados (autorización / comprobante), cobros recurrentes y recordatorios diarios.

## Carpetas

| Carpeta | Contenido |
|---|---|
| `web/` | **La app** (se sube al repositorio público `fval85-finanzas.github.io` de la organización `fval85-finanzas`) |
| `apps-script-simple/` | **El servidor** en un solo archivo (`Codigo.gs`, se pega en Apps Script) |
| `apps-script/` | El mismo servidor separado por partes (para mantenerlo) |
| `base-de-datos/` | La hoja base (`.xlsx`) que se convierte a Google Sheets |
| `iconos/` | Opciones de ícono |
| `pruebas/` | Pruebas del lector de correos, cálculos y servidor |
| `herramientas/` | `armar_codigo.py`: junta `apps-script/` en `Codigo.gs` |

## Instalación

Paso a paso: **[GUIA.md](GUIA.md)**

## Pruebas (opcional, en la computadora con Node.js)

```bash
TZ=America/Costa_Rica node pruebas/pruebas.test.js
node pruebas/servidor.test.js
```

> 🔒 Este repositorio debe ser privado: contiene el historial real del préstamo. Solo la carpeta `web/` va al repositorio público.
