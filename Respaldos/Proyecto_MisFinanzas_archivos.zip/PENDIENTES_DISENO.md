# Cambios aprobados (se programan todos juntos al final)

> Estado: puntos 1–6 en la versión 2.1.0; puntos 7–8 en la 2.2.0.

## 1. Calculadora · datos (C1) — aprobado completo
- Tasa "% al año" por defecto + texto "= x% por mes · así lo calculan los bancos (anual ÷ 12)".
- Aviso si la tasa al mes es > 3%: "7% al mes = 84% al año…" con botones "Usar 7% al año" / "Sí, es al mes".
- Tipo de préstamo: Casa (30 años, pólizas vida+incendio, TBP+margen), Personal (5 años, fija, comisión), Carro (8 años, póliza), Otro (en blanco). Solo sugiere plazo y campos.
- Campo nuevo: comisión de formalización (% una vez), en resumen y PDF.
- Selector Tasa fija / TBP + margen.
- Siempre se abre limpia + botón "🧹 Limpiar" arriba (sin gesto de arrastrar). Las guardadas se mantienen.

## 2. Gráficos (C2) — opción 1
- "Cuánto debés con el tiempo": línea de saldo; con abono extra, segunda línea (sin abonos gris / con abonos acento) y "terminás X años antes".
- Va debajo de Compartir PDF / ¿Y si…? / Guardar, antes del Mes a mes.
- (Confirmar: ¿agregar la pestaña "Por año" como en C3, o solo la 1?)

## 3. Resultado y ¿Y si…? (C3) — aprobado
- Mes a mes: "1 · nov 26" en la misma línea.
- ¿Y si…?: cuadros verdes uno debajo del otro, ancho completo, monto que se achica si no cabe.
- Gráfico con y sin abonos debajo del ahorro en ¿Y si…?.

## 4. PDF (C4) — aprobado
- Encabezado con más aire: "SIMULACIÓN DE PRÉSTAMO" / "PRÉSTAMO DE CASA" en dos líneas, "Preparado para" + nombre completo (sin cortar).
- Gráficos antes de la tabla (con abonos: saldo con y sin + capital/intereses por año; sin abonos: saldo + por año).
- Tabla: títulos (#, Fecha, Cuota, Capital, Interés, Pólizas, Abono, Saldo) alineados/centrados con sus montos.

## 5. Tasa cero · cuota baja o fija (T0) — A + B aprobado
- A: botón arriba en el detalle "Cuota baja con abonos" | "Cuota fija". Cambia tarjetas (termina / cuota del mes), resumen (+ "Última cuota" en fija) e historial (abono: "cuota → ₡x" vs "adelanta el final / quita N cuotas"). Recordar la vista por compra.
- Cuota fija: cuota original; abonos acortan el plazo; última cuota parcial.
- B: cuadro "¿Qué pasa con tus abonos?" comparando Cuota / Pagos que faltan / Termina / Última cuota; solo si hay abonos; tocar columna cambia la vista.
- Solo visualización: el gasto del mes no cambia.

## 6. Todo cerrado al entrar + botón de agregar (P1, P2, P3) — aprobado tal cual
- Arreglar en toda la app: ícono dentro de .btn sin tamaño (botón amarillo vacío en Viajes, + gigante en Fondos).
- Botón de agregar estilo A: pastilla arriba a la derecha con nombre ("＋ Nuevo viaje", "＋ Subcuenta", "＋ Nuevo sobre"…).
- Viajes: pantalla principal (en curso arriba con disponible y por día, Próximos, Terminados en fila cerrada). Vacío: maleta 🧳 + "✈ Crear presupuesto de viaje".
- Tasa cero: una fila por compra (cuota/mes, falta, "x de y · termina", barra, ›) → detalle; Abono extra y Ver detalle adentro; Terminadas en fila cerrada.
- Fondos: "＋ Subcuenta" arriba; aviso de una línea "N movimientos sin subcuenta · Asignar ›"; Últimos movimientos cerrado.
- Tarjetas: todas cerradas al entrar (ninguna abierta por defecto).
- Préstamo: "Saldo al cierre de cada año" e "Historial de pagos" cerrados.
- Patrimonio: "Ahorros e inversiones" y "Deudas" cerrados con su total.
- Regla general: nada se abre solo; lo plegable muestra total y ›.

## 7. Tarjetas · deuda real que sube y baja (S1) — programado en 2.2.0
- Pestaña Cuentas: columna nueva "Fecha del saldo" junto a "Saldo actual ₡" y "Saldo actual $" (servidor: asegurarColumnas_ + leer fechaSaldo).
- Deuda hoy = saldo a esa fecha + compras con esa tarjeta después (Gasto y Compra tasa cero completas, servicios públicos incluidos) − "Pago de tarjeta" a esa tarjeta después. Separado ₡ / $.
- Tarjeta cerrada: deuda hoy + "+₡x desde dd mmm" (o "sin cambios").
- Tarjeta abierta: Saldo al dd mmm (estado de cuenta), + N compras desde entonces, − pagos, = Deuda hoy, Disponible (límite − deuda), Reservado en sobres, Falta cubrir; botones Ver compras / Registrar pago / ↻ Actualizar saldo.
- "↻ Actualizar saldo": deuda ₡, deuda $, fecha (hoy por defecto) → guarda en Cuentas (acción de servidor nueva). Va en la cola local-primero.
- Encabezado: "Deuda total hoy" + % cubierto por sobres. Patrimonio y widget próximo pago usan la deuda viva.
- Requiere Codigo.gs nuevo.

## 8. Compras que no salen de un sobre (O1) — programado en 2.2.0
- Asignar compra (gasto): tres opciones ✉ De un sobre · 💳 Mía, sin sobre (gasto mío, no toca sobres) · 🤝 Para otra persona (nombre + nota).
- Para otra persona: suma a la deuda de la tarjeta, NO cuenta como gasto mío (ni "Te quedan" ni Reportes ni categorías), no toca sobres, queda en «Me deben».
- Pantalla «Me deben» (desde Más y como widget opcional de Inicio): total, por persona, compras pendientes.
- Al llegar un Ingreso/SINPE de esa persona por el mismo monto: "¿Es el pago de …?" → Sí cierra la deuda y ese ingreso no cuenta como ingreso mío. También marcar pagado a mano.
- Requiere guardar en la hoja (columna o pestaña "Me deben"); va con el Codigo.gs del punto 7.

## 9. Elegir sobre: lista propia en vez de la lista de Android (opción A) — programado en 2.4.0
- Bocetos: scratchpad/boceto-elegir/opciones.png (A/B/C) y adapta.png (360 px, 390 px, Fold abierto).
- Hoja de abajo "Elegí el sobre" con × arriba; buscador ("Buscar sobre…"); sección MÁS USADOS (3 sobres más usados) y TODOS (A–Z); al final "💳 Sin sobre" cuando aplica.
- Fila: ícono en cuadrito + nombre en una línea (corta con "…") + saldo a la derecha en color (verde; amarillo si queda poco; rojo si negativo); el elegido con borde dorado y ✓. Altura táctil ≥ 48 px, letra ≥ 15 px, respeta el tamaño de letra de Ajustes.
- Adaptable a todo teléfono: ancho completo en pantallas angostas; en anchas (Fold abierto, tablet) hoja centrada con ancho máximo (~480 px).
- Reemplaza TODOS los <select> de sobre: asignar compra/ingreso, filas del pago de tarjeta, mover entre sobres (De/A), sobre de ajuste del reparto, limpiar sobre → mover a, campo Sobre del formulario de movimiento, reglas.
- Arreglo (va sí o sí): no leer como sobres las filas de la hoja Sobres que no lo son ("Total asignado ₡/$", la nota de "Pago de tarjeta"…); filtrar en servidor y en la página.
- Confirmado por el usuario (31 oct):
  - Íconos automáticos según el nombre del sobre (🛒 super, 📚 inglés, 🎒 colegio, 🏠 casa/préstamo, 💳 tarjeta…), ✉ si no reconoce la palabra.
  - Nombres sin la palabra "SOBRE" al inicio y en tipo título, como en el boceto: "SOBRE SAMMY COLEGIO" → "Sammy Colegio". Solo visual; la hoja no cambia. Números largos (ej. cuenta del préstamo) se cortan con "…" en la fila.
  - Mismo estilo de lista propia para TODOS los selectores (Tarjeta o cuenta, Categoría, Tipo, Moneda, filtros…) para que todo se vea igual.

## 10. Un solo pago de tarjeta repartido en varios sobres (P2 · por compras) — programado en 2.4.0
- Boceto: scratchpad/boceto-pago/pago-varios.png. Motivo del usuario: "no tengo que escribir montos, se hace sola".
- Al asignar un Pago de tarjeta: arriba, aviso verde "✓ ₡x ya cubiertos · compras que asignaste a …" (lo reservado, como hoy).
- Lista "COMPRAS DE ESTA TARJETA SIN SOBRE (DESDE EL ÚLTIMO PAGO)": misma tarjeta y moneda, Gasto sin sobre / pendientes, más viejas primero. Cada fila: casilla, comercio, fecha, sobre sugerido (regla del comercio o el último sobre usado para ese comercio; si no hay, "elegí sobre ›" abre la lista opción A), monto.
- Marcar = esa compra sale de su sobre con este pago. Se marcan solas las más viejas hasta donde alcance el pago; el usuario puede desmarcar.
- Barra "Repartido ₡x de ₡pago" + "Falta ₡y" / "Listo ✓". Botones: "✨ Sugerir sobres" (llena los sobres de las marcadas sin sobre) y "Repartir ₡y a mano" (filas tipo P1 con la última que se llena sola; incluye 💳 Sin sobre) para intereses/comisiones.
- Las no marcadas quedan para el próximo pago. Si no hay compras sin sobre, se ve como P1 (filas que se completan solas).
- Guardado: filas en Movimientos de sobres del pago (una por sobre, sumando) y, por cada compra marcada, que quede asignada (no vuelva a salir en Por asignar). Revisar si requiere servidor.

## 11. Salario sin comprobante: aviso el día de pago (1) + "Salario" frecuente con reparto de siempre (2) — programado en 2.5.0
- Boceto: scratchpad/boceto-salario/salario.png. El usuario recibe pago BISEMANAL (cada 14 días, no 15/30).
- Ajustes → "Salario": monto, cuenta, frecuencia elegida por el usuario: Bisemanal (cada 2 semanas a partir de una fecha de pago conocida, ej. "viernes 31 oct") · Semanal · Quincenal (dos días del mes que él escoge) · Mensual (un día). Si cae fin de semana/feriado: día hábil antes / después / igual. Vista previa "Próximos pagos: 14 nov, 28 nov, 12 dic…".
- Inicio, el día de pago (y hasta que se confirme): tarjeta "💰 Hoy es día de salario · normalmente ₡x a <cuenta>" con "✓ Sí, llegó" · "Otro monto" · "Todavía no (recordarme mañana)". No crea nada solo.
- "Sí, llegó" crea el Ingreso (comercio "Salario", Origen Manual) y abre el reparto ya lleno.
- ＋ → Ingreso: "💰 Salario · ₡último monto" en Frecuentes. Sirve para aguinaldo/ingresos extra.
- Decisión del usuario (1 nov): CADA pago se reparte completo en sobres, sean 2 o 3 pagos en el mes; él decide el reparto en ese momento. Sin regla automática de "mitad del asignado". Al confirmar el salario se abre el reparto con el monto completo por repartir; como ayuda, prellenado con el reparto del salario anterior (editable, botón "Empezar de cero"). Todo debe quedar asignado ("Falta ₡0") para guardar sin aviso.
- Guardar configuración: en la hoja (Ajustes del servidor) para que no se pierda al cambiar de teléfono → probablemente requiere Codigo.gs.

## 12. "Super y Otros" (listas de compras compartidas) — programado en 2.5.0
- Boceto: scratchpad/boceto-lista/listas.png (4 pantallas aprobadas: Mis listas/editar · En el super · Compartir por link · Terminar compra).
- Nombre del botón en Más: "Super y Otros" (no "Listas").
- Compartir: opción A (Apps Script, datos en la hoja, pestaña "Listas", actualización cada 3–5 s, link solo de esa lista, "Cambiar link" revoca). Reabrir el link = misma lista con su estado; nombre recordado en ese navegador; marcas sin señal se guardan y se envían al volver.
- Decidido (1 nov): SIN precios (quitar estimados, total y "Ver en Walmart"). Foto por producto OPCIONAL, guardada pequeña en la hoja (≈ 25 KB, comprimida en el teléfono), se agrega poco a poco; sin foto se ve 📷 punteado.
- Boceto fotos: scratchpad/boceto-lista/fotos.png — quien compra ve foto grande + nota con "✓ Este es, va al carrito" · "📷 No está igual · ¿este sirve?" (toma foto, mensaje corto) · "✗ No hay". El otro recibe tarjeta con las dos fotos lado a lado + "Sí, llevalo" / "No, dejalo" (+ respuesta corta). Funciona en las dos direcciones. La foto de "¿este sirve?" se borra al terminar la compra. Aprobado 1 nov.
- Lista precargada (pedido 1 nov): al crear la primera lista, ofrecer "Empezar con una lista base de super" (~50 cosas típicas de Costa Rica agrupadas por pasillo: Frutas y verduras, Carnes, Lácteos y huevos, Granos y abarrotes (arroz, frijoles, azúcar, aceite, café, Lizano…), Panadería, Limpieza, Cuidado personal, Bebidas, Mascotas). Pantalla para desmarcar lo que no se usa antes de crear; cantidades vacías o sugeridas; todo editable después. Opción "Empezar vacía". La base también disponible en "⭐ Agregar básicos".

## 13. Avisos (A + C) y versión nueva — programado en 2.5.0
- Boceto: scratchpad/boceto-avisos/avisos.png.
- A: notificaciones en la barra con revisión automática del teléfono (Periodic Background Sync de Chrome en la PWA instalada; 1–2 veces al día, hora no exacta) + al abrir la app. Pide permiso de notificaciones. Botones en la notificación (Asignar / Revisar / Ver tarjeta / Actualizar ahora) que abren la pantalla correcta.
- C: resumen diario a Gmail desde Apps Script (activador de tiempo), hora elegida, "solo si hay algo" o siempre. Requiere Codigo.gs.
- Ajustes → Avisos: interruptor general + por tipo: Por asignar, Por revisar, Día de salario, Pago de tarjeta (2 días antes), Sobre en negativo, Super y Otros, Versión nueva. Horas de silencio (10 p.m.–7 a.m.). "Probar un aviso ahora".
- Versión nueva: al abrir y en cada revisión, comparar con la versión publicada en GitHub (sw.js nuevo); aviso en la barra + tarjeta en Inicio "Versión x lista · Actualizar" (recarga sin perder datos). Si la página necesita un Codigo.gs más nuevo que el del servidor: tarjeta roja "Falta actualizar el servidor · Ver guía".
- B (push al instante) queda para más adelante.

## 14. Bloquear zoom (que se sienta como app) — programado en 2.5.0
- index.html viewport: agregar maximum-scale=1, user-scalable=no.
- CSS: html, body, botones/inputs con touch-action: manipulation (sin zoom por doble toque).
- El tamaño de letra sigue en Ajustes → Tamaño de letra. Revisar que ningún input quede < 16 px.

## 15. Ajustes: animación al tocar (opción B) + letra "Pequeña" — programado en 2.5.0
- Boceto animado: scratchpad/boceto-anim/ajustes-animado.html.
- B: cada ícono de los grupos de Ajustes con su animación al tocar (☁ gira, 🎨 se menea, 🔒 salta, 🔔 suena, 💳 se voltea, ✉ brinca, Aa crece; 0,3–0,8 s). Acciones que tardan (revisar correos, guardar, probar avisos, actualizar saldo…): aro girando alrededor del ícono y al final ✓ (o ✗ si falló). Flecha › gira al abrir el grupo. Respetar prefers-reduced-motion.
- (No elegida: onda de la opción A en todos los botones; ofrecer de nuevo solo si el usuario la pide.)
- Tamaño de letra: Pequeña (≈ 92 %, data-letra="peq", zoom .92) · Normal · Grande · Muy grande.

## 16. Ajustes → Actualizaciones: todo con un botón (opción B) — programado en 2.5.0
- Boceto animado: scratchpad/boceto-anim/actualizar-animado.html.
- Tarjeta "Actualizaciones": versión App y Servidor (actual → nueva), Novedades en palabras simples, botón "Buscar actualizaciones". Pasos con ✓: buscar · copia de seguridad del servidor · instalar servidor · descargar página · recargar. Animación como la B de Ajustes (aro en el ícono, ✓ por paso, rebote al final).
- Servidor se actualiza a sí mismo: Apps Script API (projects.updateContent + versions.create + deployments.update de la MISMA implementación → la URL /exec NO cambia). Código nuevo publicado en GitHub Pages (sin secretos; la clave sigue en Propiedades del script). Verificar versión/hash antes de instalar.
- Configuración de una vez (guiada): activar "API de Google Apps Script" en script.google.com/home/usersettings + aceptar permiso script.projects (y script.deployments). Si falta, caer a pasos guiados (Copiar código nuevo + Abrir Apps Script).
- Copia de la versión anterior y botón "Volver a la versión anterior".
- Si alguna vez la URL /exec cambia: Ajustes → Google y datos → "Cambiar URL o clave" (ya existe); la actualización automática avisa si detecta otra implementación.

## 17. Proteger "Cambiar URL o clave" con PIN/huella — programado en 2.5.0
- Pedir PIN o huella antes de abrir "Cambiar URL o clave" (Ajustes → Google y datos) y antes de "Revisar la conexión" en la pantalla de error.
- Sin servidor: huella local (WebAuthn, ya existe) o verificación local del PIN con hash con sal (PBKDF2, guardado en el teléfono la última vez que el PIN se verificó bien en el servidor; nunca el PIN en claro).
- Clave mostrada como •••••• y URL recortada (…abc123…/exec); "Mostrar" vuelve a pedir PIN/huella; sin selección ni copia (user-select:none, sin botón copiar).
- 5 PIN incorrectos → esa pantalla bloqueada 5 minutos.
- Si no hay PIN activo: pedir crear uno antes de entrar.
- Limitación (dicha al usuario): una página web no puede impedir capturas de pantalla.
- Primera instalación (sin URL guardada): la pantalla de conexión sigue abierta sin PIN (no hay nada que proteger todavía).

## 18. Editar Inicio directamente (1 modo edición + 2 Más con mantener presionado) — programado en 2.5.0
- Boceto interactivo: scratchpad/boceto-anim/inicio-editar.html.
- 1: mantener presionado cualquier widget/acceso en Inicio → modo edición (todo tiembla, respeta reduced-motion): × quita, botón Tamaño (Chico → Mediano → Grande), arrastrar para reordenar (touch: pointer events, no HTML5 drag), barra inferior "＋ Widget" (hoja con widgets disponibles y vista previa) · "＋ Acceso" (lleva a Más) · "Listo" (guarda). Enlace "✏ Editar Inicio" al final de Inicio.
- 2: en Más, lo que está en Inicio NO aparece; mantener presionado → "Agregado a Inicio ✓". Inicio: 4 accesos + "Más"; si está lleno, preguntar cuál reemplazar. Quitar de Inicio lo devuelve a Más.
- Quitar de Ajustes la configuración de widgets/accesos (todo en Inicio). Guardar orden/tamaños como hoy (local + ajustes del servidor si ya se guardan ahí).

## 19. Préstamo: corregir sola la fórmula del Saldo al registrar un pago — aprobado 2 nov · PROGRAMADO en 2.5.5
- Caso real: J200 tenía `=SI(B200="";"";#REF!-D200-N(H200))` (fila borrada en algún momento); el usuario lo arregló copiando J199 hacia abajo.
- En registrarPagoPrestamo_ (Codigo.js): después de escribir la fila, poner en la columna Saldo la fórmula relativa a la fila anterior (misma forma que la fila de arriba, p. ej. copiar la fórmula de la fila anterior con copyTo o setFormulaR1C1 "=IF(R[0]C2=\"\";\"\";R[-1]C-R[0]C4-N(R[0]C8))" usando las columnas reales por encabezado). Revisar también otras columnas con fórmula en esa fila (si tienen #REF!, copiar la de la fila anterior).
- Prueba con hoja simulada.

## 20. Nombres cortados con el Fold cerrado (pantalla angosta) + revisión general — aprobado 2 nov · PROGRAMADO en 2.5.5
- Tarjetas: con el teléfono cerrado (~360 px) los nombres se cortan en 2 líneas con "…" ("Mastercar d…", "Tasa cer…"). Debe leerse el nombre completo en una sola línea y verse bonito: reacomodar la fila (monto debajo o más pequeño, chip "pagar en X días" debajo del nombre, ícono de tarjeta más chico), sin cortar palabras; usar nombre corto si hace falta (ej. quitar el banco repetido o "(Credix)" a una segunda línea suave).
- Revisar TODAS las pantallas a 344–360 px (Fold cerrado) y a ~700 px (abierto): Inicio, Movimientos, Tarjetas, Sobres, Por asignar, Préstamo, Fondos, Tasa cero, Viajes, Me deben, Super y Otros, Planear pago, Ajustes, hojas (panel) — textos cortados, montos que empujan, chips que se salen; dejar todo en una línea o con salto bonito.
- Además: en "Otras cuentas" aparece como cuenta la nota de la hoja Cuentas ("Saldo actual: en tarjetas, lo que debés hoy…"): no leerla como cuenta (filtrar filas de notas/ayuda, igual que se hizo con los sobres).

## 21. Cuenta de ahorros con saldo vivo (1 + 2 + 3) — aprobado 2 nov · PROGRAMADO en 2.5.5
- Boceto: scratchpad/boceto-ahorro/ahorros.png.
- 1 · Saldo vivo como las tarjetas (para cuentas de ahorro): saldo anotado + fecha (columna "Fecha del saldo" de Cuentas, ya existe) → + Ingresos y Retiros de fondo a esa cuenta, − Gastos/SINPE enviados desde esa cuenta, − Pagos de tarjeta, − cuota del préstamo, − aportes a fondos (Inversión), según la cuenta de origen elegida (punto 3). Cuenta desde el día siguiente a la fecha del saldo. Desglose en la tarjeta de la cuenta (Tarjetas → Otras cuentas). Bloque "¿Cuánto está en sobres?": En tus sobres (total sobres CRC) · Libre = saldo − sobres (aviso si negativo).
- 2 · "↻ Cuadrar con el banco": escribir saldo del banco → app calcula / banco dice / diferencia → "Ajustar y seguir desde hoy" (nuevo saldo + fecha hoy, como actualizarSaldoCuenta) o "Buscar qué falta" (movimientos sin cuenta, recientes). Opcional "📷 Saldo desde foto" con el lector.
- 3 · Ajustes → "Cuentas de dónde salen los pagos": Pagos de tarjetas / Cuota del préstamo / Aportes a fondos salen de [cuenta] (PREFS). Por defecto la primera cuenta de ahorro CRC.
- Dato del usuario: salario, SINPE recibidos y pagos de lo que le deben entran todos a "Ahorros BCR colones". Movimientos sin cuenta (Ingreso/SINPE) se toman como de esa cuenta (cuenta principal = la elegida en el punto 3).
- Filtrar de Cuentas la fila de nota de ayuda ("Saldo actual: en tarjetas, lo que debés hoy…") — ver punto 20.
- Aclarado con el usuario (2 nov): los sobres son etiquetas sobre la plata de Ahorros BCR (no otra cuenta). "Sacar de un sobre" = pagar desde la cuenta y asignar el pago al sobre: cuenta y sobre bajan juntos, "Libre" igual. Plata que entra y se usa directo para pagar la tarjeta: ingreso queda Libre y el pago "Sin sobre". Solo hay movimiento real entre cuentas con fondos (Retiro de fondo → entra a Ahorros).

## 22. Pantalla de cada sobre (B + tarjeta y 4 botones de A) — aprobado 2 nov · PROGRAMADO en 2.5.5
- Boceto: scratchpad/boceto-sobremov/sobre-B.png (y opciones en sobre-mov.png).
- Tocar un sobre → pantalla propia: tarjeta (ícono, nombre, tipo, meta, saldo, barra de meta) + 4 botones: 📥 Cargar (desde otro sobre / de un ingreso por asignar / de lo libre en la cuenta) · 📤 Descargar (a otro sobre / a un gasto / a libre) · 🧾 Movimientos · ✏️ Editar (nombre, meta, tipo).
- Resumen del período: venía · entró · salió; mini gráfico del saldo al cierre de cada mes (últimos 8).
- Filtros: Este mes · Mes pasado · Todo · Cargas · Descargas. Filas estilo banco: Carga/Descarga, descripción (Reparto del salario, Compra · comercio, Pago de tarjeta, Movido desde X…), monto, "Saldo final" corrido, fecha/hora; agrupadas por mes con total.
- Tocar un movimiento: detalle (fecha, sobre, saldo antes/después, movimiento de origen, "junto con N sobres" si fue reparto) + Ver el movimiento + Deshacer (eliminarGrupoSobres).

## 23. Tarjeta abierta con íconos + movimientos de la tarjeta + buscar por fechas — aprobado 2 nov · PROGRAMADO en 2.5.5
- Boceto: scratchpad/boceto-tj/tarjeta-mov.png.
- 1: botones de la tarjeta como 6 íconos en 2 filas (Planear pago, Movimientos, Registrar pago, Actualizar saldo, Pago con foto, Editar). Tasa cero solo de esa tarjeta (ya filtra por nombre; el caso del usuario era la columna "Tarjeta" de Tasa Cero con Davibank en vez de Credix).
- 2: "Movimientos" de la tarjeta = pantalla propia (no la lista general): resumen compras · pagos · deuda hoy; filtros Desde el corte · Este mes · Mes pasado · Rango; filas estilo banco agrupadas por mes; tocar abre el movimiento.
- 3: Movimientos general: chips de período (Hoy, Ayer, Esta semana, Este mes, Mes pasado, 3 meses, 📅 Rango…) + calendario de rango + buscador que entiende comercio, mes ("octubre"), fecha ("15/10") y montos (">20000", "5000-10000"); abajo cantidad y total.

## 24. Arreglos chicos · PROGRAMADO en 2.5.6
- Fondos: "Intereses (últimos ajustes)" mostraba "+-₡56,93" cuando el ajuste fue negativo; ahora muestra "−₡56,93" en rojo.

## 25. Lector de correos: Davibank · PROGRAMADO en 2.5.6
- "Envío exitoso de débito en tiempo real" (Davibank) + "Débito en Tiempo Real Entrante" (BCR): plata propia BCR → Davibank. Hoy entra como Gasto sin cuenta (fila 20, ₡32.978,54). Debe entrar como Transferencia (no gasto, no sobre).
- "Alerta Confirmación Pago Tarjeta de Crédito" (Davibank): hoy entra como Gasto con nota "Tarjeta ••XXXX no está en Cuentas" (fila 21). Debe entrar como Pago de tarjeta a la tarjeta Davibank.
- Ingreso ₡329 del 2 nov a las 00:00 (fila 19): averiguar de qué correo salió.
- Falta: texto de los correos (sin datos privados) para enseñarle al lector.

## 26. Nombres de cuenta sin importar mayúsculas · PROGRAMADO en 2.5.7
- El usuario renombró "Ahorros BCR colones" → "Ahorros BCR Colones" en Cuentas; las filas viejas de Movimientos y PREFS.origenes quedaron con el nombre anterior. Comparar nombres de cuenta sin importar mayúsculas/tildes/espacios (efectoCuenta, cuentaPorNombre, deudaTarjeta, origenes, completarCompra_ del lector).

## 27. De qué cuenta se paga cada tarjeta · PROGRAMADO en 2.5.7
- Ajustes → Cuentas de dónde salen los pagos: además del "por defecto", una fila por tarjeta activa (ej. Mastercard Davibank → Ahorros Davibank Colones; Mastercard BCR → Ahorros BCR Colones). Se usa cuando el pago no tiene al lado un débito de cuenta del mismo monto. La lista se arma sola con las tarjetas y cuentas de ahorro activas de la hoja Cuentas (las nuevas aparecen solas; tarjeta sin elegir = la cuenta por defecto).

## 28. ¿De dónde vino esta plata? · aprobado 3 nov (boceto boceto-origen/origen.png) · PROGRAMADO en 2.5.7
- Hoy: un "crédito a la cuenta" (Transferencia que entra) sin una salida del mismo monto en otra cuenta se toma como salida de la cuenta principal. Malo si vino de otro banco fuera de la app o de alguien que le pagó.
- Propuesta: esos créditos sin pareja aparecen en "Por asignar" con la pregunta "¿De dónde vino esta plata?": (1) De mi cuenta [principal/otra] → transferencia emparejada; (2) Me pagaron / venta → pasa a Ingreso y se reparte a sobres; (3) De una cuenta mía fuera de la app → entra sin restar de ninguna (no es ingreso nuevo para sobres salvo que se elija).
- Junto con el 27: Mastercard Davibank → se paga de Ahorros Davibank Colones; Mastercard BCR → de Ahorros BCR Colones.

## Nota de entrega (3 nov)
- El servidor se actualiza A MANO: el proyecto oculto de Google Cloud no deja habilitar la Apps Script API (error 403 "API has not been used in project…"). El usuario eligió no crear proyecto propio. En cada versión con cambios de servidor: mandar Codigo.gs (SendUserFile) + pasos: pegar en Código → Guardar → Implementar → Gestionar implementaciones → ✏ → Versión: Nueva → Implementar.
- PROGRAMADO en 2.5.8: en Ajustes → Actualizaciones, si el error es "API has not been used / disabled" en el proyecto, no intentar instalar solo: mostrar directo "Actualizalo a mano" (sin el mensaje largo de Google).

## 29. Anotado 3 nov (sin programar todavía)
- Pago de Servicio Davibank (ICE): el lector 2.5.8 ya lo lee bien (servicio, monto ₡30.465, tarjeta Davibank, fecha del correo). Lo que falló fue que el servidor todavía era 2.5.7.
- Detalle chico: el identificador con guion ("945189903642-1206130579") se guarda solo en parte en la nota/autorización; leerlo completo.
- Nombre del servicio largo ("INSTITUTO COSTARRICENSE DE ELECTRICIDAD - COBRO DE SERVICIOS ELECTRICOS"): mostrar corto en la app (ej. "ICE · Electricidad") sin cambiar la hoja.
- OJO (3 nov 12:45): el usuario dice que ya tenía el servidor 2.5.8 cuando llegó el correo del ICE (12:29) y aun así entró sin comercio/cuenta/categoría. Con el texto del PDF el lector 2.5.8 sí lo lee → el cuerpo real de Gmail (getPlainBody / HTML) debe venir distinto (posibles: ₡ como entidad HTML "&#8353;", "caracter&iacute;sticas", tabla en celdas). Falta: ver la columna Autorización de esa fila (auto-… = lector general) y, si hace falta, una función de diagnóstico que muestre el texto crudo del último correo de Davibank (sin guardar nada).
- Confirmado (12:47): fila ICE con Autorización "auto-…" y fecha 03/11 12:29 (la del correo: el arreglo 2.5.8 de "fecha futura" sí actuó) → lo leyó el lector GENERAL con el servidor 2.5.8. El lector de servicios no reconoce el cuerpo real de Gmail. Próximo paso: función de diagnóstico verCorreoCrudo() (muestra getPlainBody y textoDeHtml_ del último "Pago de Servicio" en el registro, sin guardar) y ajustar parsearDavibankServicio con ese texto.
- Fila de Telecable quedó con hora 00:00 (corregida a mano); da igual para cálculos.
- (3 nov) Transferencias que entran al BCR desde otro banco no mandan correo → se suben por "Leer comprobante (foto)". Mejora futura: que el lector de fotos reconozca un comprobante de transferencia recibida y proponga Tipo = Ingreso y la cuenta destino (hoy propone pago de tarjeta y hay que cambiar el tipo).
- (3 nov 13:29) Mismo problema con los avisos de la cuenta Davibank: "crédito" (13:07) y "débito" (13:08) a la cuenta ••XXXX entraron por el lector GENERAL como 2 Gastos (auto-…, sin comercio, cuenta Ahorros Davibank Colones por los últimos 4). El texto del PDF sí lo lee parsearDavibankCuenta → el cuerpo real de Gmail viene distinto. El "Pago de tarjeta" (dvpago-9615-…) SÍ entró bien. Resolver junto con el de servicios usando la función de diagnóstico (texto crudo).
- Además, red de seguridad: si el lector general ve "crédito"/"débito a la cuenta" debe usar Transferencia (entra/sale) y nunca Gasto.
- (3 nov) PROGRAMADO 2.5.9: emparejar transferencias/pagos por cercanía (doble débito en Ahorros Davibank por dos operaciones de ₡32.978,54 en días seguidos).
- PROGRAMADO 2.6.0: al cambiar la fecha de un movimiento en la app, actualizar también la fecha de sus filas en "Movimientos de sobres" (Telecable quedó con 10 nov en el sobre).

## 30. Más ágil: Para revisar + Todo al día · aprobado 3 nov · PROGRAMADO en 2.6.0
- Lo que más le cuesta al usuario: (1) corregir lo que entra mal (quiere hacer todo desde la app; al Excel solo para agregar tarjetas/cuentas); (2) se siente "a ciegas" cuando llegan movimientos.
- Plan: una sola versión grande (no muchas chicas):
  a) Lector Davibank arreglado con el texto real de Gmail (Diagnostico.gs → verCorreosDavibank; el usuario pega el registro).
  b) "Para revisar": tarjeta en Inicio ("Llegaron N · X listos · Y necesitan un toque"); pantalla con arriba lo que pide decisión (botones; sobre sugerido ya marcado; Recordar) y abajo lo que la app hizo sola; "Todo bien ✓" / "Algo está raro" (abre el movimiento en la app).
  c) "Todo al día ✓": cómo quedaron tarjetas, cuentas y sobres que cambiaron, con botón para cubrir sobres en negativo.
  d) Junto: fecha del sobre al editar fecha del movimiento; foto de transferencia recibida → Ingreso; nombres cortos.
- PROGRAMADO servidor 2.5.10 (3 nov): con el registro de Diagnostico.gs se vio que el texto plano de Gmail trae las negritas como *…* y el HTML trae &#x20A1; y espacios antes del punto. limpioDavi_() + entidades hex: los 5 correos reales (crédito, débito, pago tarjeta, Telecable, ICE) se leen completos. Punto 29 resuelto.

## 31. Tarjeta que cobra todo en colones + IVA aparte · PROGRAMADO en 2.7.0
- Caso: Netflix/Disney+ en Mastercard BCR (límite solo en ₡). El correo llega en dólares ($15,99) pero el banco carga colones → hoy la app lo anota en $ (deuda en $ que no existe, y el sobre en ₡ no lo puede tomar).
- Propuesta: en la cuenta (hoja Cuentas o Editar tarjeta) "Cobra todo en colones" (por defecto: tarjeta sin Límite $). El lector convierte USD → ₡ con el tipo de cambio de referencia (Config) y guarda "Cobro original $15,99 · TC 505" en la Nota. La diferencia con el tipo de cambio real del banco se ajusta sola al "Actualizar saldo" con el estado de cuenta.
- Alternativa que se le explicó: pasar las suscripciones a una tarjeta con saldo en dólares (Mastercard Davibank tiene límite en $) → coincide exacto, pero necesita sobre en dólares.
- Relacionado: mostrar el IVA de servicios digitales (cobro aparte del BCR) pegado a su suscripción.
- IVA (aclarado 3 nov): el IVA del BCR NO manda correo; solo aparece en el estado de cuenta, días después. Opción A: hoja Recurrentes (ya existe: día del mes + monto fijo; se anota solo). Opción B (recomendada): IVA automático pegado a la suscripción: cuando llega un cobro de servicio digital (Netflix, Disney+, Spotify, Apple, Google, Amazon Prime…) en una tarjeta marcada "agrega IVA aparte", la app anota sola "IVA · Netflix" = 13% del cobro en ₡ (mismo sobre, misma tarjeta, origen "Auto IVA"). Si el monto real difiere, se ajusta con el estado de cuenta.
- IVA aprobado por el usuario (3 nov) con este detalle: son DOS líneas (cobro + "IVA · Netflix"). La del IVA nace como "IVA estimado" (etiqueta amarilla) y queda en Para revisar → sección "Por confirmar" hasta que el banco lo aplique; ahí botón "Confirmar monto" (abre con el monto para ajustarlo al real) y queda confirmado. Igual para el cobro convertido de $ a ₡: "monto estimado" hasta confirmar con el monto real del banco. Lo estimado ya cuenta en sobre y deuda (para no quedarse corto).
- Quién lleva IVA lo ELIGE el usuario (3 nov): nada automático por nombre. La primera vez que llega un cobro de un comercio nuevo en tarjeta en ₡ (o en $ convertido), Para revisar pregunta "¿Este cobro trae IVA aparte?" [Sí, 13%] [No] y lo recuerda por comercio (regla, como el sobre). Ej.: Netflix y Disney+ = Sí; Google almacenamiento (~₡1.700) = No. Lista editable en Ajustes → "Cobros con IVA aparte".
  · Para no molestar con cada compra: la pregunta del IVA solo sale para cobros que llegan en DÓLARES (servicios del exterior) y solo la primera vez por comercio.

## 32. Foto de "Transferencia entre cuentas BCR" recibida · PROGRAMADO en 2.7.0
- Comprobante BCR: "Cuenta origen" y "Cuenta destino" con la etiqueta partida en 2 líneas ("Cuenta" / "destino") y el IBAN al lado. El lector 2.6.0 busca "cuenta destino" en una sola línea → no lo detectó → quedó Tipo Transferencia sin "Entró" → la app lo restó de Ahorros BCR (−₡6.700) y no pidió sobre.
- Arreglo: tomar todos los IBAN del texto en orden (1º origen, 2º destino); si el destino termina en los Últimos 4 de una cuenta tuya y el origen no es tuyo → Ingreso a esa cuenta (descripción "De <nombre origen> · <motivo>"); si los dos son tuyos → Transferencia "Entró desde …".
- Además: una Transferencia escrita a mano sin "Entró/Salió" → preguntar "¿Entró o salió de la cuenta?" en Para revisar en vez de suponer que salió.

## 33. Cuenta de ahorros como en la app del BCR: DISPONIBLE · PROGRAMADO en 2.7.0
- Los sobres del usuario son los SOBRES DEL BCR: meter plata a un sobre la saca del disponible; para pagar, primero sale del sobre (vuelve al disponible) y luego se paga.
- Número grande de la cuenta principal = Disponible = saldo total − sobres − reservado para tarjetas (= el "Libre" de hoy). Abajo chico: "En sobres ₡Y · Total con sobres ₡X".
- Cuadrar con el banco pide el DISPONIBLE del banco; la app guarda total = disponible + sobres + reservado a esa fecha.
- Confirmado: el ₡329,33 que cuadró el 3 nov era el disponible (deja centavos/montos chicos fuera de sobres) → con el cambio hay que cuadrar una vez más.
- Al asignar un ingreso a un sobre: disponible baja; pagar desde sobre: sobre baja, disponible igual (como en el banco).

## 34. Cuadrar con el disponible · PROGRAMADO en 2.8.0 (disponible anotado)
- Caso: cuadró Ahorros BCR con disponible ₡329,33 (el banco ya tenía los ₡6.700 de Jonathan en el sobre IPTV). Después subió la foto del ingreso (3 nov) y lo asignó a IPTV → disponible −₡6.370,67. La app había guardado total = 329,33 + sobres de ESE momento (sin los 6.700); el ingreso es de antes de la fecha del saldo y no suma, pero el sobre sí sube.
- Arreglo pensado: guardar el DISPONIBLE como saldo de la principal (marcado en PREFS) y calcular total = disponible anotado + sobres + reservado hasta el fin del día del saldo, con los datos de hoy (así lo que se anote después con fecha anterior queda bien solo).
- Mientras tanto: anotar primero lo pendiente y después cuadrar; si pasa, volver a cuadrar con el disponible del banco.

## 35. ESPEJO DEL BANCO · aprobado 4 nov (quitar asignaciones viejas: sí) · PROGRAMADO en 2.8.0
- El usuario lo plantea así: los sobres de la app = los sobres del BCR (mismo saldo). Compras con tarjeta NO tocan sobres: solo deuda + categoría. Él decide después de qué sobre paga.
- Sacar de un sobre (📤) → sube el disponible del BCR; opcional "¿para qué?": pagar tarjeta X / pasar a otra cuenta / dejar disponible. Meter (📥) → baja el disponible.
- Cuando sale plata del BCR (transferencia, pago, SINPE) y no se sacó antes de un sobre: Para revisar pregunta "¿La sacaste de un sobre?" [sobres] [Varios] [No, del disponible] → anota sacar + salida.
- Cada paso es una fila en la hoja Movimientos (Tipo nuevo "Sobre → disponible" / "Disponible → sobre", columna Sobre) y se ve en Movimientos de la app, en la cuenta y en el sobre.
- Se quitaría: "reservado para tarjetas", asignar compras a sobres, sobres en negativo por compras. (Revisar qué pasa con lo ya asignado: migración.)
- Pendiente revisar después de 2.8.0: el Planeador de pagos todavía deja elegir sobre por compra (eso ya no cuenta en el modelo espejo); simplificarlo para que al pagar pregunte de qué sobre(s) sacaste.

## 36. Pantallas más limpias + avisos de pago · APROBADO 4 nov (boceto tj2 + tj4) · PROGRAMADO en 2.9.0
- Cuenta → Movimientos: chips en orden Este mes · Mes pasado · Todo · 📅 Rango. Quitar "Desde el saldo" del menú (queda solo interno para "Cuadrar → Buscar qué falta"). Abre en "Este mes".
- Tarjetas (lista): solo nombre + monto adeudado (negativo = "₡X a favor" en verde, ej. Credix) + barra amarilla de uso. Quitar la línea verde/naranja del cambio "desde <fecha>" y la pill "pagar mañana / en X días".
- Avisos de pago (recomendado, sobre lo que ya existe: resumenAvisos_, periodicsync 'mf-avisos', correo diario):
  - Notificación al teléfono 3 días antes, 1 día antes y el día del pago (días configurables), con monto; no avisa si ya se registró el pago del período.
  - Correo de la mañana: tabla de pagos de los próximos 7 días con monto (incluye "a favor").
  - Interruptores en Ajustes → Avisos (teléfono / correo / días antes).
  - La fecha sigue visible dentro de cada tarjeta ("Corte y pago") y en el widget "Próximo pago".
- Ajuste 4 nov (boceto tj4, APROBADO): se mantiene el diseño aprobado tj2 (monto a la derecha). La deuda en dólares ("+ $104,00") hoy sale chica y gris → mismo tamaño y en blanco como los colones, en cada tarjeta y en "Deuda total hoy". (El boceto tj3 con monto grande abajo fue un malentendido: descartado.) Prueba real 4 nov completa (compra USD $104 Mastercard Davibank → depósito en $ a Ahorros Davibank Dólares → pago en $): todo bien, solo pidió categoría y la pregunta de IVA. Nota: el Planeador de pagos registra el pago siempre en CRC (moneda fija) → arreglar al simplificarlo.
- Cambia el servidor (Codigo.gs) por el correo y la ventana de días → hay que pegarlo a mano.

## 37. Tarjetas que no son mías (tarjeta de débito de la hija en BCR) · APROBADO 4 nov (boceto ajena) · PROGRAMADO en 2.9.0
- Caso: la hija (menor) tiene tarjeta de débito/ahorros BCR a cargo del usuario; los correos de sus compras le llegan a él y la app los anota como pendientes.
- Idea: en Ajustes → Cuentas, lista "Tarjetas que no son mías" (últimos 4, guardado en PREFS, no en el código). El lector de Gmail las salta (o las anota en una cuenta aparte que no suma, a elegir).
- Mientras tanto: eliminar el movimiento a mano (Editar → Eliminar movimiento, tocar 2 veces). El correo ya queda con la etiqueta de procesado, así que no vuelve a entrar.
- No poner los últimos 4 reales de la hija en código ni pruebas.
- Correo de ejemplo: "Notificación de Transacciones BCR" (bcrtarjestcta@…), tabla Fecha/Autorización/Referencia/Monto/Moneda/Comercio/Estado; la tarjeta viene como ****-****-****-XXXX. Hoy: últimos 4 no está en Cuentas → la app lo trató como salida de la principal (Ahorros BCR) y preguntó sobre.
- Boceto: (1) Para revisar, tarjeta desconocida → "¿Es tuya?" [➕ Sí, agregarla] [🚫 No es mía · ignorar] [1️⃣ Solo esta vez (borrar)]; no se anota en cuenta ni sobre hasta responder. (2) Ajustes → Cuentas → Tarjetas que no son mías: lista (últimos 4 + nombre opcional, "Quitar", contador de correos saltados) + agregar. Guardado en PREFS. (3) "Sí, agregarla": formulario Nueva cuenta (nombre sugerido, tipo débito/crédito, últimos 4) → crea la fila en Cuentas y anota la compra.
- Servidor: el lector salta las tarjetas ignoradas (las etiqueta como procesadas) y deja las desconocidas sin cuenta para la pregunta.

- 2.9.0: el monto del aviso es "lo que toca pagar" = deuda de hoy sin las compras hechas después del último corte; si queda algo (pago parcial), sigue avisando.
- 4 nov (2.9.0 instalada): "¿Es tuya?" probado con la compra real de la hija → No es mía, borrada y renombrada en Ajustes ✓. Disney (BCR "US DOLLAR") corregido a mano + IVA estimado; pendiente Confirmar monto cuando el banco aplique. GitHub Pages: deploy quedó en cola/timeout (problema de GitHub).

## 38. Pago con plata sacada de VARIOS sobres · APROBADO 7 nov (boceto "varios") · PROGRAMADO en 2.10.0
- Caso real: 📤 Sacar ₡10.000 (sobre A) + ₡5.000 (sobre B) "para pasar" → SINPE ₡15.000. autoSacado solo une si UNA sacada coincide con el monto exacto → la pregunta "¿La sacaste de un sobre?" solo ofrece un sobre.
- Respuesta correcta hoy: "🪙 No, del disponible" (las sacadas ya pasaron la plata al disponible).
- Idea: autoSacado también une varias sacadas recientes (≤4 días, "para pagar/pasar", sin usar) que sumen el monto; y en Para revisar, si hay sacadas sin usar, mostrar "Ya sacaste ₡15.000 de 2 sobres (A + B) → ✓ Es eso".
- Boceto aprobado: (1) se une solo si las sacadas suman justo y no hay dudas → Listos solos "✓ Con lo sacado de A ₡X + B ₡Y" + aviso; (2) con dudas → pregunta con la lista de sacadas y total [✓ Sí, es eso] [Otro sobre…] [🪙 No, del disponible]; (3) si no alcanza → usa lo sacado y pregunta por la diferencia [🪙 Del disponible] [📤 De otro sobre…] [No era para este pago]. Solo sacadas "para pagar/pasar" de ≤4 días sin usar.
- 7 nov: confirmado por el usuario → Disney + IVA confirmados ✓; correo de la mañana con tabla de pagos llega y se lee bien ✓; GitHub publicó 2.9.0 (app y servidor 2.9.0) ✓.

## 39. Planeador de pagos para el espejo del banco · APROBADO 7 nov (boceto "plan") · PROGRAMADO en 2.10.0
- 1 Cuánto pagar: "Por pagar" (deuda sin compras después del corte, como pagosProximos) + deuda hoy; [Todo lo del estado] [Mínimo] [Otro monto]; moneda ₡/$ (arregla que hoy guarda siempre CRC).
- 2 De dónde sale: casillas por sobre con monto (muestra lo que tiene) + "Del disponible"; total con ✓; "Sale de" cuenta. Ya no se elige sobre por compra.
- 3 Listo: anota solo las sacadas "📤 … → disponible · para pagar <tarjeta>"; el pago lo anota el correo y se une solo (usa el punto 38). Interruptor "Este pago no llega por correo → anotarlo ya".

## 40. Igualar sobres al saldo del BCR · APROBADO 7 nov (boceto "igualar") · PROGRAMADO en 2.10.0
- Botón ⚖ Igualar al BCR en cada sobre: en la app / lo que dice el BCR / diferencia; [✓ Corregir el sobre (disponible no cambia) = ajuste de saldo inicial] [📥/📤 Lo metí/saqué del disponible = fila Meter/Sacar].
- Sobres → ⋯ → Igualar todos al BCR: tabla sobre / BCR / dif + disponible app vs BCR; botón "Igualar N sobres".

## 41. Calculadora rápida flotante · APROBADO 7 nov (boceto "calc") · PROGRAMADO en 2.10.0
- Botón 🧮 flotante chico en todas las pantallas (arrastrable a cualquier borde, semitransparente si no se usa; se oculta en Ajustes → Apariencia).
- Se abre como calculadora compacta encima de la pantalla (C, ⌫, %, ÷ × − +, 00, coma, =); minimizar/cerrar; Copiar; Historial (últimas 10); recuerda el número.
- Si hay un campo de monto abierto: botón "Usar ₡X en Monto".
- Extra: escribir operaciones en cualquier campo de monto (10000+5000-329 → = ₡14.671).
- Distinta de la "Calculadora" de préstamos que ya existe.

## 42. Viajes: cada tarjeta por separado · APROBADO 7 nov (boceto "viaje") · PROGRAMADO en 2.10.0
- Hoy: todas las tarjetas del viaje van juntas (un gastado, categorías mezcladas, lista sin decir la tarjeta).
- 1 Resumen: bloque "POR TARJETA" (monto, % y n.º de compras por tarjeta + Efectivo) entre el total y las categorías. Total y límite siguen siendo del viaje.
- 2 Compras: cada compra con mini-plástico + banco; chips de filtro "Todas · N / BCR · N / Davibank · N".
- 3 Filtrado: tarjeta elegida con su total y categorías, y solo sus compras.

## 43. Viajes · sugerencias 1, 2, 4, 5 y 8 · APROBADO 7 nov (bocetos "viajes1" y "viajes2") · PROGRAMADO en 2.10.0
- 1 "✈ Es del viaje" en cualquier compra (sumar las de antes de las fechas, o sacar una que no era); al crear el viaje sugiere compras de antes que parecen del viaje (aerolínea, Booking…). Resumen: Antes del viaje / Durante.
- 2 Presupuesto por categoría opcional (Vuelos, Hospedaje, Comida, Transporte, Paseos, Compras) con barras (amarillo 80%, rojo al pasarse); "Repartir el límite solo".
- 4 Aviso diario durante el viaje (teléfono + correo de la mañana): ayer gastaste, quedan, por día, categoría pasada. Ajustes → Avisos → Viajes.
- 5 Efectivo del viaje: retiros de cajero pasan a efectivo (no son gasto); "+ Gasto en efectivo" rápido con categoría; saldo de efectivo.
- 8 Resumen al terminar: costo total, por día, antes/durante, por categoría, por tarjeta, comparado con viajes anteriores; PDF y Compartir.
- Categorías: agregar "Vuelos" a las de viaje (Transporte, Comida, Hospedaje, Tours, Compras, Otros); "Tours" se queda.
- Agregado por el usuario (7 nov): botón "＋ Anotar compra a mano" dentro del viaje (además del que ya existe para sumar compras de otra cuenta): monto, moneda (la del viaje por defecto), descripción, fecha (hoy), categoría del viaje (chips) y "Pagado con" (tarjetas del viaje / 💵 efectivo / otra cuenta). Queda como Gasto marcado del viaje. Aviso: las compras con tarjeta llegan solas por correo; si después llega un correo con el mismo monto ±1 día, preguntar "¿Es la misma que anotaste a mano?" para no duplicar.

- 2.10.0 notas: en Planear pago se cambió "Mínimo" por "Todo lo de hoy" (la app no conoce el mínimo del banco; para el mínimo usar "Otro monto"). Escribir operaciones en los montos funciona con teclado completo; el teclado numérico del teléfono no trae "+" → usar la calculadora 🧮 con "Usar en Monto".

## 44. Bandeja de entrada limpia · APROBADO 8 nov · PROGRAMADO en 2.10.1
- Al leer un correo de banco: queda con la etiqueta de siempre "Finanzas/Procesado" + se ARCHIVA (sale de la bandeja de entrada) + se marca como LEÍDO.
- Los que quedan en "Finanzas/Revisar" (la app no los entendió) se quedan en la bandeja para que se vean.
- Una sola vez: los correos ya procesados que siguen en la bandeja (label:finanzas-procesado in:inbox) se archivan y se marcan leídos.
- Ajustes → Correos de los bancos: interruptor "Sacar de la bandeja lo que la app ya leyó" (encendido) para poder apagarlo.
- La búsqueda de correos es por remitente + fecha (no depende de la bandeja), así que archivar no afecta la lectura.

## 45. Estados de cuenta se quedan en la bandeja · APROBADO 8 nov · PROGRAMADO en 2.10.2
- El usuario deja el estado de cuenta de la tarjeta en la bandeja hasta pagarla (recordatorio). La app no los toca (ni Revisar ni Procesado ni archivar), incluido el del préstamo y el de fondos. Devuelve a la bandeja los que 2.10.1 archivó.
- Ofrecido y NO elegido (por ahora): al registrar el pago de la tarjeta, sacar su estado de cuenta de la bandeja con la etiqueta del usuario. También ofrecido: elegir etiquetas propias por tipo de correo desde Ajustes (el usuario puede usar filtros de Gmail).

## 46. Super y Otros: listas de "Tiendas y mall" · PROPUESTO 8 nov (boceto "tiendas") · esperando visto bueno
- Al crear lista: Tipo [🛒 Super] [🛍 Tiendas y mall]; íconos propios; "¿Para quiénes?" (personas de la lista); lista base de viaje opcional.
- Cada cosa: nombre, sección (Ropa, Ropa deportiva, Calzado, Accesorios, Electrónica, Belleza, Hogar, Regalos, Otros), para quién, talla, color, cantidad, precio máximo, tienda, nota. Escritura rápida: "tenis talla 9 negros para Fernando".
- Ver por persona / por sección / por tienda. Mismas funciones del super: compartir con link (2, 3 o más), marcar en vivo, agregar/eliminar, "¿este sirve?" con foto. Al marcar, precio pagado opcional → "Gastado hasta ahora".
- 46 PROGRAMADO en 2.10.4 (aprobado 8 nov). Base de tiendas ampliada a pedido: ropa, ropa deportiva, ropa interior y medias, abrigos, calzado, accesorios, perfumería y belleza, cuidado personal, electrónica, hogar, niños, regalos. En la base todo empieza desmarcado (botón "todas" por sección).

## 47. Listas de tiendas: 📦 Encargos · APROBADO 8 nov · PROGRAMADO en 2.10.5
- Pestaña dentro de la misma lista: [🛍 Nuestras] [📦 Encargos]. Agrupar por persona / tienda / estado.
- Cada persona que encarga: nombre, adelanto (opcional) y moneda → "quedan del adelanto" o "te debe".
- Encargo: de parte de quién, qué, sección, talla/modelo, color, cantidad, precio máximo, foto/captura, nota. Estados: Pendiente · Comprado · Entregado · Cobrado.
- Al marcar comprado: cuánto costó + con qué pagó (tarjeta/efectivo) + foto del recibo opcional. Si fue con tarjeta, al llegar el correo se marca "para otra persona" (Me deben).
- Al volver: cuentas por persona (total, adelanto, le sobra / te debe en $ y ₡), "↗ Mandar cuenta" (texto para WhatsApp), "✓ Cerrar cuenta", "👛 Pasar a Me deben".

## 48. Viajes: tarjetas de la esposa (familia, solo viajes) · ✅ PROGRAMADO 8 nov · v2.10.6 (falta que el usuario lo pruebe)
- Ella reenvía con filtro de Gmail sus avisos de compra (2 Davibank + 1 BAC Credomatic) al Gmail del usuario. Davibank ya se lee; BAC necesita correo de ejemplo + remitente (agregar banco en Config).
- "¿Es tuya?" opción nueva: "👩 De mi familia · solo para viajes" → nombre de la persona + nombre de la tarjeta (PREFS, no código). Esas compras: no tocan cuentas/deudas/sobres/reportes; cuentan solo en viajes cuyas fechas las incluyen (y si el viaje tiene esas tarjetas elegidas).
- Ajustes → Cuentas → Tarjetas de la familia (por persona, últimos 4, contador, quitar, agregar).
- Viaje: POR TARJETA agrupado por persona (subtotal por persona y por tarjeta); filtros Todas / persona / tarjeta; cada compra con plástico y persona. Límite de los dos juntos (opción por persona más adelante).
- PDF: resumen por persona y tarjeta + una página por tarjeta con sus compras; botón "Solo <persona>".
- Pendiente del usuario: forwarding en el Gmail de ella, últimos 4 de las 3 tarjetas, un correo de compra BAC (PDF) y confirmar que le llegan avisos por cada compra.
- 8 nov: llegó correo de ejemplo BAC (guardado solo en el scratchpad, privado). Remitente NotificacionBAC@baccredomatic.cr; asunto "Notificación de transacción <COMERCIO> dd-mm-aaaa - hh:mm"; cuerpo en pares "Etiqueta: valor": Comercio, Ciudad y país, Fecha ("Nov 1, 2026, 11:55"), VISA|MASTERCARD|AMEX: ************XXXX, Autorización, Referencia, Tipo de Transacción (COMPRA…), Monto ("CRC 249,906.69" / USD). Falta: lista de las 3 tarjetas (el mensaje del usuario llegó cortado).
- 8 nov · v2.10.6: lector BAC; PREFS.familia {u4:{persona,nombre,desde}} (se cargan desde la app, nada en código); cuenta "Familia ••u4"; reenvío automático detectado por X-Forwarded-For y reenvío a mano por búsqueda del correo del banco en el texto; viaje con token "-Familia" para no incluirlas; PDF con página por tarjeta y PDF de una persona.

## 49. Correos de rechazo / reversión del banco · ✅ detector "¿Cobro repetido?" PROGRAMADO v2.11.0 · lector del correo de rechazo EN ESPERA hasta que el usuario tenga un comprobante real (15 nov)
- Caso real (Miami, Davibank): 1) correo con el cargo (intento) → la app lo anotó · 2) correo de RECHAZO de ese intento → la app lo ignoró · 3) correo con la compra que sí pasó → la app la anotó otra vez. Resultado: dos gastos iguales; el banco solo tiene uno. El usuario borró uno a mano.
- Pedido: que la app reconozca los correos de rechazo / reversión / anulación (nota de crédito) y deshaga sola el cargo anterior del mismo monto, misma tarjeta, en un rango de horas (borrarlo o marcarlo anulado; si ya estaba en un viaje, sale del viaje). Y si es una devolución real (nota de crédito después de un cobro), anotarla como devolución que resta en la tarjeta y en el viaje.
- Falta: el texto o PDF del correo de rechazo (Davibank, y si hay, BAC/BCR) para armar el lector. Probar con datos inventados.
- 14 nov · PROPUESTA (sin programar): como no siempre llega el correo de rechazo, agregar un detector de "¿Cobro repetido?" en Para revisar: dos compras por correo con la misma tarjeta, mismo monto y moneda, comercio parecido, hasta ~2 h de diferencia y autorizaciones distintas → "🗑 Borrar el primero (fue un intento rechazado)" / "Son dos compras distintas" (se recuerda). Nunca borra solo. Si después llega el correo de rechazo, anula solo el intento. Esperando visto bueno / boceto.

## 50. Calculadora: botón fijo y más grande · ✅ PROGRAMADO v2.11.0 (no hay + abajo: el botón quedó fijo abajo a la derecha)
- A: el botón 🧮 queda fijo justo encima del + amarillo (misma esquina, no arrastrable o con posición por defecto ahí).
- C: el panel sube desde abajo a todo el ancho (hoja con rayita para bajarla), teclas de 46 → ~60 px, números ~26 px, resultado ~44 px, operación arriba; abajo Copiar / Historial, o "Usar X en «Monto»" si hay un monto abierto (D).

## 51. Tasa cero: la cuota se carga a la tarjeta el día del corte · ✅ PROGRAMADO v2.11.0 (filas reales "Cuota tasa cero")
- Hoy: la "Compra tasa cero" suma completa a deudaTarjeta y a porPagarTarjeta (nuevas); las cuotas se cuentan por mes calendario (cuotaEnMes / primeraCuota).
- Nuevo: cada corte (c.diaCorte) carga la cuota del mes de cada tasa cero de esa tarjeta → suma al pago de contado, SIEMPRE (con saldo a favor la consume primero; si alcanza, "queda a favor · no hay que pagar"). El resto = "Saldo tasa cero" aparte (no entra al pago de contado).
- La compra tasa cero en sí deja de sumar completa al pago de contado / deuda de contado.
- Movimientos: cuotas visibles el día del corte ("Cuota X · n de m", etiqueta "automático · al corte"), sin preguntar sobre ni categoría (cuentan en el sobre especial Tasa cero). Abonos extra recalculan como hoy.
- Aviso el día del corte (notificación + correo): "Cargué N cuotas ₡X · pago de contado ₡Y · vence <día pago>".
- Cuota real: tocar la cuota y poner el monto del estado de cuenta (redondeos).
- Primera cuota = siguiente corte después de la compra (editable). Tarjeta sin día de corte → comportamiento actual.
- Decidir al programar: cuotas como filas reales (tipo "Cuota tasa cero", autorización TC-<id>-<n>, creadas por el servidor el día del corte) o calculadas. Preferencia: filas reales para verlas en la hoja.

## 52. Activar / desactivar tarjetas y cuentas desde Ajustes · ✅ PROGRAMADO v2.11.0 (boceto "activar")

## 53. Presupuesto (por categoría + inversiones) · ✅ PROGRAMADO v2.12.0 (bocetos "presupuesto", "presu-familia", "presu-inversion") · falta que el usuario lo pruebe
- Por mes Y por salario (las dos opciones, chip arriba).
- Límite mensual por categoría; cuenta todo lo gastado (tarjeta, cuenta, efectivo). Barra con rayita de "hoy", "vas bien / vas rápido / te pasaste", ₡ por día para llegar.
- Poner límites: "lo que te queda libre" (salario − sobres − cuotas tasa cero − préstamo − meta de inversión), sugerencia = promedio 3 meses, botón "Usar mis promedios", aviso si no caben.
- Detalle de categoría (compras que la llenaron, mes pasado). Avisos al 80% y al pasarse (teléfono + correo de la mañana).
- Cierre de mes: dónde sobró / se pasó + sugerencia de ajuste.
- No cuentan: viajes, compras para otros, pagos de tarjeta. Tarjetas de la familia: opción por tarjeta "¿dónde cuentan en el presupuesto?" → una categoría (ej. Supermercado) / según la categoría de cada compra / no cuenta. Dentro de un viaje solo cuentan en el viaje. Desglose "Quién gastó" por persona y tarjeta.
- Inversiones (propuesto): meta mensual por fondo ("primero, invertir"), cuenta aportes − retiros del mes (C.fondos aportesMes/retirosMes); se resta antes de lo libre para gastar (sin restar doble si ya va por un sobre de inversión); al cierre: meta cumplida, acumulado del año, y ofrecer mandar lo que sobró de gastos a un fondo (aporte).

## 54. Tasa cero: botón "Cambiar tarjeta" · ✅ PROGRAMADO v2.13.0 (dentro de 58c)
- Hoy hay que cambiarla a mano (movimiento en la app + pestaña Tasa Cero + Abonos tasa cero + cuotas ya cargadas). Propuesta: en el detalle de la compra tasa cero, "Cambiar tarjeta" hace todo de un toque.

## 55. Presupuesto: "lo libre" con salario bisemanal = pago × 26 ÷ 12 · ✅ PROGRAMADO v2.13.0
- Hoy usa el promedio de salario de los últimos 3 meses; un mes con 3 pagos lo infla (~11%). Con salario bisemanal configurado, usar el pago × 26 ÷ 12 (≈ 2,17 pagos por mes).
- Aclarado al usuario: el presupuesto cuenta por fecha de compra (no por corte de tarjeta); por salario, los límites mensuales se reparten por días (14 ÷ 30,44).

## 56. Calculadora: ícono nuevo, arriba junto al + y teclas centradas · ✅ PROGRAMADO v2.13.0
- Ícono A (dibujo de calculadora en amarillo). Botón redondo en el encabezado, al lado del + (mismo tamaño que las flechitas); fila 1: mes + botones, fila 2: título grande. Se quita el botón flotante.
- Arreglo de teclas: las teclas usaban la clase "op"/"c"/"eq", y ".op" global (opciones de formularios) les metía margin-top 8px, padding y alineación a la izquierda → renombrar a calc-op / calc-c / calc-eq; signos centrados y un poco más grandes.

## 57. Interruptores en Tarjetas de la familia y Tarjetas que no son mías · ✅ PROGRAMADO v2.13.0
- Familia: interruptor Activa/Pausada (familia[u4].pausada). Pausada → el servidor ignora sus avisos sin preguntar; lo anotado se queda. Confirmar al pausar si ya tiene compras. Filtros Todas/Activas/Pausadas.
- No son mías: interruptor Ignorada/Sin ignorar (ajenas[u4].off). Apagado → la próxima compra vuelve a "¿Es tuya?". Filtros Ignoradas/Sin ignorar + avisos saltados del mes.
- Resumen de las tres listas en Ajustes → Cuentas. Tocar el nombre = editar/quitar.
- Objetivo del usuario: poder modificar todo desde la app sin ir a la hoja.

## 58. Todo desde la app (sin ir a la hoja) · 58a–58c ✅ PROGRAMADO v2.13.0 · 58d–58g ✅ PROGRAMADO v2.14.0
- 58a. Categorías en Ajustes: agregar, renombrar (opción: pasar los movimientos viejos al nombre nuevo), quitar. Hoy en Config.
- 58b. Reglas automáticas (comercio → categoría / sobre): lista con buscador para ver, editar y borrar.
- 58c. Tasa cero: Editar completo (descripción, monto, meses, primera cuota, tarjeta = #54) y Quitar.
- 58d. Bancos que se leen (Config): agregar, pausar o quitar un banco desde Ajustes → Correos de los bancos. PENDIENTE.
- 58e. Recurrentes: pantalla en la app (ver, agregar, editar) en vez de abrir la hoja. PENDIENTE.
- 58f. Sobres: saldo inicial desde la app y archivar sobres que ya no se usan (interruptor activo/archivado). PENDIENTE.
- 58g. Subcuentas de fondos: archivar / quitar (interruptor). PENDIENTE.
- 15 nov · 58d–58g aprobados como en el boceto "pendientes58":
  - 58d Bancos que se leen: lista con interruptor (leer / pausar), correos del mes, "＋ Agregar banco" (nombre + correo remitente); "siempre se leen": SINPE, recibos del préstamo, SAFI. Escribe en Config (Banco / Correo de notificaciones / Estado).
  - 58e Recurrentes (Más → Planificar): lista con interruptor (Activo Sí/No), editar monto, día, tarjeta/cuenta, categoría, sobre; borrar; "próxima" y si ya se anotó el del mes; ＋ Nuevo. Pestaña Recurrentes.
  - 58f Sobres: filtros Activos/Archivados; saldo inicial editable (recalcula); archivar solo con saldo ₡0 (deja de salir en reparto y listas).
  - 58g Subcuentas de fondos: Activas/Archivadas; archivar solo con saldo 0; sale de Fondos, presupuesto y lista para aportar; historial se queda.

## 59. Ajustes ordenado · ✅ PROGRAMADO v2.14.0 (boceto "ajustes-orden")
- **Quitar:** interruptor "Calculadora rápida" (queda siempre arriba, en el encabezado); nota "Para agregar un banco, escribí su correo en Config" (lo reemplaza 58d); texto "los saldos iniciales se ponen en la pestaña Sobres" (lo reemplaza 58f; la fecha "Saldos desde" se queda).
- **Juntar:** "Cuentas de dónde salen los pagos" pasa adentro de cada cuenta en Mis tarjetas y cuentas (chips "De aquí salen los pagos de: Tarjetas / Préstamo / Fondos"; solo una cuenta por cada uno). "Servidor (Apps Script)" + "Cambiar URL o clave" → una fila "Conexión con Google".
- **Mover:** grupo "Calculadora · Preparado por (en los PDF)" → campo "Nombre en los PDF" dentro de la calculadora de préstamos.
- **Editable:** Tipo de cambio de referencia (hoja con campo ₡ por $1, se guarda en Config por el usuario).
- **Reagrupar:** Cuentas → "Cuentas y tarjetas" (Mis tarjetas y cuentas, Familia, No son mías) y "Movimientos" (Categorías, Reglas, IVA aparte, Recurrentes 58e). Sobres agrega "Mis sobres" (58f).
- Recargar datos: texto nuevo "Trae lo último (otro teléfono o la hoja)". Más → Recurrentes abre la pantalla nueva, no la hoja.

## 60. Destello al tocar · ✅ PROGRAMADO v2.14.0 (opción B, colores por tema)
- Error actual: con letra Pequeña/Grande (zoom en body) la .onda (position:fixed en clientX/Y) sale corrida (con Pequeña, arriba del dedo). Arreglo: dividir entre el zoom del body o dibujar la onda dentro del elemento.
- B: la onda nace en el dedo pero va DENTRO del botón/fila tocado (overflow:hidden, position relative), la fila se ilumina un poco.
- Color: en filas/tarjetas = var(--acento) del tema actual; en botones ya pintados del acento: onda clara si el texto del botón es oscuro, oscura si es blanco (Azul, Crema, Celeste).

## 61. Al abrir: todo al día solo · ✅ PROGRAMADO v2.14.0 (A + B + C + E) · D (revisión cada 5 min) queda para después
- A: una sola llamada al abrir (acceso + correos nuevos + datos). B: revisar correos al abrir y al volver a la app (visibilitychange), solo si pasaron > 2 min desde la última revisión. C: el servidor guarda una marca de "última modificación"; si no cambió nada responde "sin cambios" (rápido). E: píldora arriba "Revisando correos…" → "✓ 2 compras nuevas" / "✓ Al día · hace un momento" / "⚠ Sin conexión · datos de hace X"; compras nuevas marcadas NUEVA + aviso abajo con "Ver"; montos guardados un poco grises mientras.

## 62. Pagos por cada tasa cero · ✅ PROGRAMADO v2.15.0 (boceto "tasacero-pagos")
- Un solo pago a la tarjeta repartido entre las compras tasa cero (lleno con la cuota de cada una). Abono extra con "Mantiene la cuota · queda a favor" (adelanto). ＋ Pago para anotar pagos viejos. Detalle por compra: le has puesto / te falta poner, adelanto que queda y para cuántos meses alcanza. Resumen en la tarjeta.

## 63. Sacar de un sobre a Disponible: el monto empieza en cero · ✅ PROGRAMADO v2.16.0
- Hoy: al sacar de un sobre a Disponible y después sacar de otro sobre, el campo de monto trae el monto anterior y hay que borrarlo.
- Quiere: que cada vez que se abra "sacar de un sobre" el monto salga vacío (₡0), sin recordar el anterior.

## 64. Botón flotante de la calculadora estorba en "+" (agregar gasto) · ✅ PROGRAMADO v2.16.0 (opción A)
- El botón redondo 🧮 (#calc-btn, z-index 9000, abajo a la derecha) queda encima de la tecla ⌫ del teclado numérico del formulario rápido.
- Opciones dadas: A) esconderlo mientras hay un formulario o ventana abierta (la 🧮 de arriba sigue) · B) que suba/se corra cuando hay teclado · C) quitar el flotante del todo · D) más pequeño y transparente. Recomendado: A.
- ✔ Elegida A: el 🧮 flotante se esconde mientras haya un formulario o ventana abierta y vuelve al cerrarla; la 🧮 de arriba sigue siempre.

## 65. La ventana de "+" se corre hacia un lado · ✅ PROGRAMADO v2.16.0 (1 + 3)
- Al deslizar las sugerencias (IVA · UBR* PENDING.UBER.COM SAN FRANCISCO…) se mueve toda la ventana a los lados y queda cortada.
- Opciones dadas: 1) trabar la ventana: solo la fila de sugerencias se desliza · 2) sugerencias en dos líneas, sin deslizar · 3) acortar los nombres largos. Recomendado: 1 + 3.
- ✔ Elegidas 1 + 3: trabar la ventana (solo la fila de sugerencias se desliza) y acortar los nombres largos de las sugerencias (ej. "UBER · San Francisco").

## 66. Presupuesto por corte · súper de la casa · ✅ PROGRAMADO v2.17.0 (boceto "presupuesto-corte")
- En la tarjeta de la casa: "Llevar presupuesto por corte" con nombre, monto por corte; día de corte de la tarjeta (24), corte nuevo el 25. "Contar en mi presupuesto del mes" APAGADO por defecto (es aparte: ella maneja la casa, él lo demás). Aviso al 80%.
- Presupuesto: tu presupuesto mensual sin esas compras + bloque aparte "Súper de la casa · 25 oct – 24 nov": gastado, queda, días que faltan, cuánto por día para no pasarse.
- Detalle del corte: gastado vs presupuesto, promedio por día, ritmo vs ideal, compras del corte, flechas a cortes anteriores. Historial de cortes: sobró / se pasaron, promedio, vs anterior.
- Solo esa tarjeta (no por categoría, no efectivo).

## 67. Agregar a mano compras de la tarjeta de la casa cuando no llega el correo · ✅ PROGRAMADO v2.17.0
- Hoy ya se puede con "+" eligiendo la tarjeta en el selector de cuenta.
- Recomendado: botón "＋ Compra" dentro del bloque/detalle del súper (tarjeta ya elegida) y en "+" recordar la última tarjeta usada.
- Importante: si el correo llega después, la app debe reconocerla (misma tarjeta, mismo monto, fecha ±1 día, compra manual sin autorización) y unirla en vez de anotarla dos veces (hoy los repetidos solo se detectan por autorización).

## 68. "Sin cuenta (efectivo)" en el "+" descuenta de la cuenta principal · 🟡 EN PARTE v2.17.1 (la opción ahora dice "Sin cuenta · sale de …"; falta avisar si deja una cuenta en negativo)
- Un Gasto sin cuenta (cuenta vacía) se resta de la cuenta principal (efectoCuenta → o.principal); solo la cuenta llamada "Efectivo" no toca ahorros. La etiqueta "Sin cuenta (efectivo)" engaña: Fernando anotó una compra del súper sin cuenta (no le salía la tarjeta de la casa) y BCR colones ahorros quedó en negativo.
- Arreglo propuesto: que la opción diga la verdad ("Sale de: Ahorros BCR ₡") o que "Efectivo" sea de verdad efectivo; y avisar antes de guardar si deja una cuenta en negativo.
- Además: no le dejaba eliminar el movimiento (revisar si la cola de envío quedó trabada).

## 69. Súper de la casa: devoluciones, IVA de Google One y app para ella · ✅ PROGRAMADO v2.18.0 (boceto "super-casa-app")
- Devolución en el "+" con la tarjeta de la casa (resta del corte). IVA de servicios del exterior aunque llegue en colones, estimado por confirmar y se confirma solo con el correo del IVA (por confirmar con un correo real del banco). App aparte "Súper de la casa" con link privado: ve el corte y puede anotar/corregir lo suyo; se apaga desde la app.
