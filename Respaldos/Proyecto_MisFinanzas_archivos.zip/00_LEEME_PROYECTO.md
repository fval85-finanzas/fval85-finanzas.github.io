# Mis Finanzas — contexto del proyecto (leer primero)

App personal de finanzas de Fernando (Costa Rica, ₡ y $). Todo se habla en **español de Costa Rica con voseo** ("tocá", "fijate").
Versión al 20 nov 2026: **página 2.18.0 · servidor 2.18.0**.

## Cómo está armada
- **Página (PWA)** en GitHub Pages: https://fval85-finanzas.github.io — carpeta `web/` del repo (privado).
  - `web/casa.html` + `web/js/casa.js` (+ `casa-sw.js`, `casa.webmanifest`): app aparte "Súper de la casa" que usa la esposa con un link privado (solo ve y anota el presupuesto por corte de su tarjeta).
  - `web/js/app.js` pantallas y lógica · `web/js/calculos.js` cálculos (se usan también en el servidor) · `web/css/estilos.css` · `web/index.html` · `web/sw.js` (caché; su VERSION sube con cada entrega) · `web/version.json`.
- **Servidor**: Google Apps Script sobre una Google Sheet + Gmail (lee los correos de los bancos).
  - Fuentes en `apps-script/` (Config, Parser, ParserPrestamo, Hoja, Codigo, Gmail, Ajustes, Extras).
  - `python3 herramientas/armar_codigo.py` los junta (más calculos.js) en `apps-script-simple/Codigo.gs` y genera `web/version.json` y `web/servidor/Codigo.gs`.
  - En este proyecto el servidor completo está en **Codigo_servidor.js** (es el Codigo.gs armado).
- Versiones: `VERSION_WEB` y `SERVIDOR_MIN` en app.js, `VERSION` en sw.js, `VERSION_APP` en apps-script/Ajustes.js, novedades en `herramientas/novedades.txt`.
- Funciona "local primero": los cambios se encolan (`encolar`) y se mandan a Google; `srv()` para llamadas directas. Preferencias en PREFS (Script Property).
- Teléfono: Samsung Z Fold 5 con Chrome.

## Forma de trabajo
1. Fernando cuenta una idea → Claude da **opciones** y una recomendación.
2. Pide **boceto** → imagen PNG con pantallas de teléfono (montos y nombres inventados).
3. "**Guardalo**" = aprobado para después → se anota en PENDIENTES_DISENO.md.
4. "**Proceder**" = programar ya. "**Todavía no programar**" = solo ideas o bocetos.
5. Al programar: pruebas automáticas (`TZ=America/Costa_Rica node pruebas/<archivo>.test.js`) y pruebas en un teléfono simulado (Playwright); subir versión; sección nueva en GUIA.md; marcar en PENDIENTES_DISENO.md.
6. Entrega: `MisFinanzas_Web_vX.Y.Z.zip` (contenido de web/) y `Codigo.gs` si cambió el servidor, con pasos en español.

## Cómo se actualiza (lo hace Fernando)
1. Apps Script: borrar todo el archivo "Código", pegar Codigo.gs, 💾 → Implementar → Administrar implementaciones → ✏️ → Nueva versión → Implementar.
2. Subir el zip de la página a GitHub.
3. Revisar https://fval85-finanzas.github.io/version.json.
4. Si la app sigue vieja, cerrarla y abrirla.

## Privacidad (obligatorio)
- Nada de datos personales en el código ni en las pruebas: nombres, últimos 4 de tarjetas, números de cuenta, IBAN, cédula, correos. Las pruebas usan datos inventados.
- Los números de la tarjeta de la esposa solo se ponen en la app, nunca en el código.
- Textos reales de correos de bancos y PDFs: privados, nunca al repo.
- No usar la API de Drive. No borrar datos del sitio fval85.github.io (ahí vive la app "Cajuelas"; no tocarla).

## Pendientes abiertos
- #49 lector de correos de rechazo: EN ESPERA hasta tener un comprobante real.
- #61 D: revisar correos cada 5 min: para después.
- El resto está en PENDIENTES_DISENO.md (cada idea con su número y estado).

## Para programar en un chat nuevo
Adjuntar **MisFinanzas_respaldo_completo.zip** (el repo entero con pruebas y herramientas) al primer mensaje, y pedir:
"Descomprimí el respaldo en /home/claude/mis-finanzas y seguí con la forma de trabajo del proyecto."
Al terminar cada versión, Claude entrega también un respaldo nuevo para reemplazar el del proyecto.
