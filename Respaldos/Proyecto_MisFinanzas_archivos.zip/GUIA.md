# Guía paso a paso — Mis Finanzas

Igual que Registro de Cajuelas: la **hoja de Google** es la base de datos, **Apps Script** es el servidor (lee tus correos y guarda los datos) y **la app** está publicada en **GitHub Pages**, desde donde se instala en el teléfono.

| Parte | Tiempo |
|---|---|
| 1. Subir la base de datos a Google Sheets | 5 min |
| 2. El servidor: Apps Script | 5 min |
| 3. Activar y publicar el servidor | 5 min |
| 4. La app: GitHub Pages | 5 min |
| 5. Instalarla en el teléfono | 2 min |
| 6. Probar con los datos de muestra | — |
| 7. Pasar a tus datos reales | 15 min |
| 8. Guardar el proyecto en GitHub (privado) | 10 min |
| 9. Cómo actualizar después | — |
| 10. Si algo falla | — |
---

## 1. Subir la base de datos a Google Sheets (5 min)

1. Entrá a <https://drive.google.com> con la cuenta de Gmail donde te llegan los correos del banco.
2. **Nuevo → Subir archivo** → elegí `base-de-datos/Mis_Finanzas_BD.xlsx`.
3. Abrilo (doble clic). Arriba va a decir **.XLSX** al lado del nombre.
4. **Archivo → Guardar como Hojas de cálculo de Google**. Se abre una copia nueva, ya convertida. **Trabajá siempre con esta copia** (la que no dice .XLSX). El .xlsx subido lo podés borrar.
5. Cambiale el nombre arriba a la izquierda, por ejemplo `Mis Finanzas`.

> ⚠️ No cambiés los nombres de las pestañas ni los encabezados de la fila 4 (fila 6 en Tasa Cero, fila 15 en Préstamo casa). La app los usa para encontrar los datos. Sí podés agregar columnas al final.

---

## 2. El servidor: Apps Script (5 min)

1. Con la hoja abierta: **Extensiones → Apps Script**.
2. Arriba a la izquierda, cambiá "Proyecto sin título" por `Mis Finanzas`.
3. Abrí `apps-script-simple/Codigo.gs` con el Bloc de notas, `Ctrl + A`, `Ctrl + C`.
4. En Apps Script, dentro del archivo **Código**: `Ctrl + A` y `Ctrl + V`. Guardá.
5. ⚙️ **Configuración del proyecto → Zona horaria:** (GMT-06:00) Hora de Costa Rica.

> Solo ese archivo. Las pantallas ya no van en Apps Script: van en GitHub Pages (paso 4).

---

## 3. Activar y publicar el servidor (5 min)

1. Arriba elegí **`configurarInicial`** → **Ejecutar** → aceptá los permisos (*Configuración avanzada → Ir a Mis Finanzas → Permitir*).
2. En el registro aparece **🔑 Clave de la app: …** (32 letras y números). **Copiala y guardala.** Si la perdés, ejecutá `verClaveApp` para verla de nuevo.
3. **Implementar → Nueva implementación** → ⚙️ **Aplicación web**:
   - **Ejecutar como:** `Yo`
   - **Quién tiene acceso:** `Cualquier persona`
4. **Implementar** → copiá la **URL** (termina en `/exec`).

> 🔐 "Cualquier persona" es necesario para que la app en GitHub Pages pueda hablar con el servidor (igual que en Registro de Cajuelas). Lo que protege tus datos es la **clave de la app**: sin ella el servidor no responde nada. Si algún día creés que alguien la vio, ejecutá `cambiarClaveApp` y escribí la nueva en tu teléfono.

---

## 4. La app: GitHub Pages (10 min)

> 💡 **Regla para todas tus apps:** en Chrome, cada app instalada necesita su **propia dirección base**. Si dos apps comparten `fval85.github.io` (por ejemplo `fval85.github.io/cajuelas/` y `fval85.github.io/otra/`), chocan al instalarse. Por eso cada app va en su propia **organización** de GitHub (gratis).

1. **＋ → New organization → Free** → nombre `fval85-finanzas` → *My personal account* → saltá lo de miembros → **Complete setup**.
2. En la organización: **Create new repository**:
   - **Owner:** `fval85-finanzas`
   - **Repository name:** `fval85-finanzas.github.io` (nombre de la organización + `.github.io`)
   - **Public**, **Add README** → **Create repository**.
3. **Add file → Upload files** → arrastrá **todo el contenido** de `web/` (carpetas `css`, `js`, `icons` y archivos `index.html`, `manifest.webmanifest`, `sw.js`) → **Commit changes**.
4. **Settings → Pages:** con ese nombre especial GitHub lo activa solo. Arriba debe decir *Your site is live at https://fval85-finanzas.github.io/*.

Tu app queda en **`https://fval85-finanzas.github.io/`**. Para una app futura repetís lo mismo con otra organización.

---

## 5. Instalarla en el teléfono (2 min)

1. Abrí `https://fval85-finanzas.github.io/` en **Chrome**.
2. La primera vez pide **Conectar con tu hoja**: pegá la **URL /exec** (paso 3.4) y la **clave de la app** (paso 3.2) → **Conectar**.
3. **⋮ → Instalar app** (o **Agregar a la pantalla principal → Instalar**).

Queda instalada como una app normal, con el ícono de la billetera y sin el sello de Chrome. La conexión se guarda en el teléfono: no hay que volver a escribirla.

---

## 6. Probar con los datos de muestra

La hoja trae ejemplos para que veas todo funcionando antes de poner tus datos:

- **Inicio:** gastos de octubre en ₡ y $, sobres, próximos pagos y últimos movimientos.
- **Movimientos:** tocá "AMZN Mktp US" (está sin categoría). Elegí una categoría, marcá "Usar siempre…" y guardá: se crea una regla en la pestaña Reglas.
- **Pasar a tasa cero:** en un gasto, tocá **Pasar a tasa cero** y poné los meses. Se crea la fila en la pestaña Tasa Cero.
- **Tarjetas:** cada tarjeta con su saldo, uso del límite y sus compras a tasa cero.
- **Sobres:** tocá uno para cambiarle el monto.
- **Préstamo:** tu historial real, el estimado de la próxima cuota con la TBP de 3,56% y la gráfica por año.
- **Configuración** (⚙️ en Inicio): tema claro/oscuro, ocultar montos, PIN, recordatorios por correo.

Cada cambio que hagás en la app lo vas a ver en la hoja, y lo que cambiés en la hoja lo ves en la app (tocá **Configuración → Recargar datos**).

---

## 7. Pasar a tus datos reales

En la hoja de Google:

1. **Movimientos:** seleccioná las filas de ejemplo (desde la 5 hasta la última con datos) → clic derecho → **Borrar contenido** (no "eliminar filas").
2. **Tasa Cero:** borrá el contenido de las columnas azules de los ejemplos y escribí tus compras reales (descripción, tarjeta, fecha de compra, monto, moneda, meses, primera cuota).
3. **Cuentas:** cambiá los ejemplos por tus tarjetas reales (nombre, banco, **últimos 4 dígitos**, límites, día de corte y de pago, saldo actual). Borrá las que no uses. Los últimos 4 dígitos son lo que permite asignar sola cada compra del correo.
4. **Sobres:** poné tus montos por mes. Podés renombrar, agregar o borrar sobres (los de "Cuota casa" y "Cuotas tasa cero" se calculan solos).
5. **Recurrentes:** borrá los ejemplos y agregá tus cobros pequeños sin correo.
6. **Config:**
   - Escribí el correo de **Davibank** cuando lo tengas y poné el Estado en `Activo`.
   - Actualizá el **tipo de cambio** de referencia.
7. **Préstamo casa:** ya es tu historial real. Revisá las 4 celdas naranjas (tienen un comentario con lo que corregí).
8. En Apps Script ejecutá **`procesarCorreos`** una vez: carga las compras de los últimos 30 días.

> Si querés empezar con el historial de compras más largo, en Apps Script buscá `DIAS_ATRAS` (con `Ctrl + F`) y cambiá el 30, antes del paso 8 (por ejemplo `90`).

---

## 8. Guardar el proyecto en GitHub (privado) (10 min)

> Este es un repositorio **aparte** del de la app (`fval85-finanzas.github.io`), para guardar todo el proyecto.
>
> 🔒 **Hacé el repositorio PRIVADO.** La carpeta `base-de-datos` y el archivo `pruebas/datos-muestra.json` tienen tu historial real del préstamo. En el código no hay claves ni contraseñas.

### Opción fácil: desde la página de GitHub (sin terminal)

1. Entrá a <https://github.com> e iniciá sesión.
2. **＋ → New repository**:
   - **Repository name:** `mis-finanzas`
   - **Private** ✅
   - No marques "Add a README".
   - **Create repository**.
3. En la página nueva, tocá el enlace **"uploading an existing file"**.
4. Descomprimí el zip en tu computadora, abrí la carpeta `mis-finanzas` y **arrastrá todo su contenido** (carpetas y archivos) a la página.
5. Abajo, en "Commit changes", escribí `Versión 1 de Mis Finanzas` y tocá **Commit changes**.

### Opción con terminal (si tenés Git instalado)

```bash
cd ruta/a/mis-finanzas
git init
git add .
git commit -m "Versión 1 de Mis Finanzas"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/mis-finanzas.git
git push -u origin main
```

---

## 9. Cómo actualizar después

**Cambios en la app (carpeta `web/`):** en el repositorio `fval85-finanzas.github.io` → **Add file → Upload files** → subí los archivos nuevos (reemplazan a los viejos) → **Commit**. Esperá 1-2 minutos y abrí la app: se actualiza sola y avisa la versión nueva.

**Cambios en el servidor (`Codigo.gs`):** pegá el código nuevo en Apps Script, guardá y publicá una nueva versión: **Implementar → Administrar implementaciones → ✏️ → Versión: Nueva versión → Implementar**. La URL `/exec` no cambia.

**Cambios sin código:** bancos y correos, categorías, sobres, reglas, recurrentes y tipo de cambio se cambian directo en la hoja.

---

## 10. Si algo falla

| Problema | Solución |
|---|---|
| Chrome dice que ya está instalada pero no aparece en ningún lado | Quedó un registro trabado en ese Chrome. Instalala desde **Samsung Internet** (☰ → Añadir página a → Pantalla Inicio) o desde **Chrome Beta**. No borres los datos del sitio `TU-USUARIO.github.io`: borrarías también los de otras apps tuyas en GitHub Pages (como Cajuelas). |
| La app dice *La clave no es correcta* | En Apps Script ejecutá `verClaveApp` y copiá la clave exacta (sin espacios). |
| *Respuesta inesperada de Google* | La URL no termina en `/exec`, o la implementación no está en **Cualquier persona**. |
| *Demasiados intentos con una clave incorrecta* | Esperá 10 minutos y escribí la clave correcta. |
| No aparece **Extensiones → Apps Script** | La hoja sigue en modo .xlsx. Hacé **Archivo → Guardar como Hojas de cálculo de Google** (paso 1.4). |
| *No encuentro la pestaña "…"* | Le cambiaste el nombre a una pestaña. Debe llamarse igual que en la hoja original. |
| *Falta la columna "…"* | Se cambió el texto de un encabezado. Volvé a escribirlo exacto. |
| No veo un cambio que hice en el código | Publicá una nueva versión (9.1, paso 2). |
| Una compra no se registró | Buscá en Gmail la etiqueta **Finanzas/Revisar** y mandame ese correo (con datos cambiados). |
| La compra quedó sin tarjeta | Revisá que los **últimos 4** de la tarjeta en Cuentas sean iguales a los del correo. |
| Se repitió una compra | No debería pasar (se usa el número de autorización). Si pasa, mandame los dos correos. |
| Olvidé el PIN | En Apps Script ejecutá **`borrarPINOlvidado`**. Después creás uno nuevo en Configuración. |
| *Demasiados intentos* | Por seguridad, después de 5 PIN incorrectos hay que esperar 5 minutos. |
| No llegan los recordatorios | Activalos en **Configuración** y probá con "Enviar uno de prueba". Solo llega correo los días que hay algo que avisar. |

---

## Pendientes conocidos

- **Comprobante del préstamo (.txt):** el lector está hecho para formatos comunes. Con un `.txt` real (datos cambiados) lo dejo exacto.
- **Compras del BCR:** igual, con un correo real lo ajusto si hace falta.
- **Davibank:** falta el correo del remitente (se pone en Config).

## Actualizar la app (ejemplo: versión 1.2.0)
1. Descomprimí `MisFinanzas_Web_v1.2.0.zip` en el teléfono o la computadora.
2. En GitHub abrí el repositorio **fval85-finanzas.github.io** → **Add file → Upload files**.
3. Arrastrá **todo el contenido** de la carpeta (index.html, sw.js, manifest.webmanifest y las carpetas css, js, icons). GitHub reemplaza los archivos que ya existen.
4. Abajo tocá **Commit changes** y esperá 1–2 minutos.
5. Abrí la app en el teléfono: aparece "App actualizada a la versión 1.2.0" y se recarga sola. Si no aparece, cerrala del todo y abrila otra vez.
El Apps Script y la hoja NO cambian en esta versión.


## Versión 1.3.0 (ícono negro y amarillo, nombre "Finanzas", PIN y huella)
Esta versión cambia **la app y el servidor**.
1. **Servidor:** abrí Apps Script → archivo Código → borrá todo → pegá el `apps-script-simple/Codigo.gs` nuevo → Guardar.
   Después: **Implementar → Administrar implementaciones → lápiz ✏️ → Versión: Nueva versión → Implementar**. La URL /exec no cambia.
2. **App:** subí el contenido de `MisFinanzas_Web_v1.3.0.zip` al repositorio, igual que en la 1.2.
3. **Huella:** en la app, Configuración → Seguridad → **Entrar con huella** → escribí tu PIN → poné el dedo.
4. El ícono y el nombre en la pantalla de inicio los actualiza Chrome solo (puede tardar hasta un día). Si Chrome pregunta si querés actualizar el ícono, aceptá.


## Versión 1.4.0 (abonos extra en tasa cero)
Cambia **la app y el servidor** (igual que la 1.3):
1. **Servidor:** Apps Script → Código → borrar todo → pegar el `Codigo.gs` nuevo → Guardar → **Implementar → Administrar implementaciones → ✏️ → Nueva versión → Implementar**.
2. **App:** subir el contenido de `MisFinanzas_Web_v1.4.0.zip` al repositorio.
3. La pestaña **"Abonos tasa cero"** se crea sola en la hoja con el primer abono. No hace falta crearla.
4. Si le cambiás la **Descripción** a una compra en la pestaña Tasa Cero, cambiala igual en la columna **Compra** de sus abonos (así se unen).


## Versión 1.5.0 (correos reales de BCR y Davibank, montos con miles, pantallas que se ajustan)
Cambia **la app y el servidor**:
1. **Servidor:** Apps Script → Código → borrar todo → pegar `Codigo.gs` → Guardar → **Implementar → Administrar implementaciones → ✏️ → Nueva versión → Implementar**.
2. **App:** subir el contenido de `MisFinanzas_Web_v1.5.0.zip` al repositorio.
3. **Hoja:**
   - Config: fila **Davibank** con `Alertas@davibank.cr` y Estado **Activo**.
   - Cuentas: la cuenta BCR de colones (Banco **BCR**, Tipo **Cuenta de ahorro**, Moneda **CRC**). Ahí se anotan los SINPE.
   - Las tarjetas con sus **Últimos 4** (BCR 9125, Davibank 9615).
4. En la app: **Inicio → Correos**. Los correos que estaban en *Finanzas/Revisar* se vuelven a leer solos.

Qué se lee: compras BCR (tabla, varias por correo, solo aprobadas), SINPE enviados (gasto; a tu nombre = transferencia) y recibidos (ingreso), recibos del préstamo (con ajuste para que el saldo cuadre con el del banco; el estado de cuenta mensual no se anota), compras Davibank en ₡ y $, y pagos de servicio Davibank (a la tarjeta Davibank, categoría Servicios).


## Versión 1.6.0 (sobres con saldo real)
Cambia **la app y el servidor**:
1. **Servidor:** Apps Script → Código → borrar todo → pegar `Codigo.gs` → Guardar → **Implementar → Administrar implementaciones → ✏️ → Nueva versión → Implementar**.
2. **App:** subir el contenido de `MisFinanzas_Web_v1.6.0.zip` al repositorio.
3. **Abrí la app una vez.** Eso prepara la hoja sola: agrega en **Sobres** las columnas *Saldo inicial*, *Ajuste del reparto* y *Meta*, crea el sobre **Pago tarjetas** y anota la fecha de inicio (hoy).
4. **En la hoja, pestaña Sobres:** escribí el *Saldo inicial* de cada sobre (lo que tiene hoy). Opcional: *Sí* en *Ajuste del reparto* para el sobre que recibe la diferencia del salario.
5. En la app: **Configuración → Recargar datos**.

Cómo funciona: lo que entra (salario, SINPE recibido) y lo que sale de la cuenta (SINPE enviado, pagos de tarjeta) aparece en **Por asignar**. Las compras con tarjeta no tocan los sobres: se descuentan cuando asignás el pago de la tarjeta. Todo queda en la pestaña nueva **Movimientos de sobres**.


## Versión 1.6.1 (solo servidor)
Apps Script → Código → pegar `Codigo.gs` → Guardar → Implementar → Administrar implementaciones → ✏️ → Nueva versión → Implementar. La app (GitHub) no cambia.
- Un "pago" del préstamo sin capital ni intereses ya no se anota.
- Las columnas nuevas de Sobres quedan con formato de título y notas explicativas; se crea la pestaña Movimientos de sobres.
- No borra ni cambia datos que hayas escrito.


## Versión 1.7.0 (rapidez, fondos BCR SAFI, viajes, hoja de Sobres al día)
Cambia **la app y el servidor**:
1. **Servidor:** Apps Script → Código → pegar `Codigo.gs` → Guardar → **Implementar → Administrar implementaciones → ✏️ → Nueva versión → Implementar**.
2. **App:** subir el contenido de `MisFinanzas_Web_v1.7.0.zip` al repositorio.
3. Abrí la app una vez: crea las pestañas **Fondos** y **Viajes**, las columnas **Subcuenta** y **Viaje** en Movimientos, el sobre **Fondos**, y cambia los títulos de Sobres (E = *Salió este mes*, F = *Saldo actual*) y del Resumen.
4. **Fondos → Agregar subcuenta**: una por cada subcuenta de BCR SAFI, con el saldo del último estado de cuenta.
5. **Más → Viajes → Nuevo presupuesto** cuando tengas un viaje.

Notas: la app abre con los datos guardados en el teléfono y se actualiza sola (barrita amarilla arriba). El botón atrás del teléfono vuelve a la pantalla anterior; en Inicio hay que tocarlo dos veces para salir. Las columnas de Sobres E–H las llena el servidor en cada revisión de correos (cada 15 min o con el botón Correos).

## Versión 1.7.1 (sobres especiales con tus nombres)
Servidor (pegar `Codigo.gs` + Nueva versión) y app (subir `MisFinanzas_Web_v1.7.1.zip`).
En **Configuración → Sobres → Sobres especiales** elegís cuál de tus sobres recibe los pagos del préstamo, las inversiones de BCR SAFI y el botón "Todo de…" del pago de tarjetas. Si no elegís, la app los busca por el nombre (OPERACIÓN/PRÉSTAMO, FONDOS/INVERSIÓN, TARJETAS).

## Versión 1.8.0 (más rápida y compras con tarjeta a un sobre)
Servidor (pegar `Codigo.gs` + Nueva versión) y app (subir `MisFinanzas_Web_v1.8.0.zip`).
- Configuración abre al instante; aviso "Guardando… / Actualizando…" arriba en cualquier acción; destello al tocar; los cambios se ven antes de que Google confirme.
- Las compras con tarjeta aparecen en **Por asignar**: elegís el sobre (baja en el momento) y queda **reservado** para esa tarjeta. Con «Recordar» las próximas del mismo comercio se asignan solas.
- Al pagar la tarjeta, lo reservado la cubre solo; solo se pregunta lo que falte.
- Si antes registrabas a mano un segundo movimiento para bajar el sobre de una compra con tarjeta, ya no hace falta: borrá esos movimientos manuales para que no se cuente dos veces.

## Versión 1.8.1 (no se puede asignar dos veces)
- El servidor rechaza asignar un movimiento que ya estaba asignado (o asignar más de lo que falta).

## Versión 1.9.0 (local primero, sin barras)
- Asignar, repartir, mover, limpiar, guardar o editar movimientos, abonos tasa cero, subcuentas, compras del viaje y "Recordar" se aplican **al instante** en el teléfono y se envían a Google por detrás (con reintentos: al volver el internet, al abrir la app y cada 30 s).
- Si quedó algo sin enviar, aparece un número amarillo en ⚙. Al tocarlo: "Por enviar a Google", con el último error y **Reintentar ahora**. También en Configuración → Sincronización.
- Si Google rechaza algo: aviso "⚠️ No se guardó «…» … Se deshizo." y la app se recarga.
- PIN, huella, conexión, crear/borrar cuentas y borrar movimientos siguen esperando a Google (circulito solo en el botón). Borrar un movimiento espera a que la cola esté vacía.
- Sin barra de progreso ni aviso de "Actualizando/Guardando". La descarga es silenciosa.
- Servidor: al borrar un movimiento, las asignaciones a sobres y abonos de los movimientos de abajo se corren una fila (antes quedaban apuntando al de al lado).

## Versión 2.0.0 (diseño nuevo · solo página, el servidor sigue en 1.9)
- Barra de abajo: Inicio · Movimientos · Tarjetas · Ajustes. "Más" queda en los accesos de Inicio. El + amarillo pasa arriba a la derecha.
- Inicio con widgets: Ajustes → Apariencia → Tu inicio (encender, apagar y ordenar).
- Movimientos: nombres legibles, ícono por categoría, total por día, resumen del mes, chips por categoría, etiqueta del sobre, 🔍 y ☰ filtros.
- Tarjetas: lista compacta que se despliega, "Por pagar este ciclo" y % cubierto por sobres, botones Ver compras / Registrar pago / Editar.
- El +: teclado grande, frecuentes (se aprenden solos), "Pegar mensaje del banco" y "Otros ⋯" con el resto de acciones.
- Ajustes: estado de la app, botones rápidos, buscador y secciones que se abren. Temas nuevos (Azul noche, Morado suave, Claro crema, Claro azul), automático día/noche y tamaño de letra.

## Versión 2.1.0 (solo página; servidor sigue en 1.9)
- Calculadora: tipo de préstamo (Casa/Personal/Carro/Otro), tasa al año por defecto con equivalencia por mes, aviso si la tasa al mes parece un error, TBP + margen, comisión en monto o %, se abre limpia + botón Limpiar, gráfico "Cuánto debés con el tiempo", mes a mes con fecha en la misma línea, ¿Y si…? con cuadros apilados y gráfico con/sin abonos.
- PDF: encabezado en dos líneas con el nombre completo, gráficos de saldo y capital/intereses por año, títulos de la tabla centrados sobre los montos.
- Tasa cero: lista corta → detalle; en el detalle "Cuota baja con abonos / Cuota fija" y cuadro comparativo (solo para ver).
- Todo cerrado al entrar (Tarjetas, Préstamo, Patrimonio, Fondos, Viajes terminados, Tasa cero terminadas); botón de agregar con nombre arriba a la derecha.

## Versión 2.2.0 (página + servidor)
- Tarjetas con deuda real: pestaña Cuentas → "Fecha del saldo" (nueva). Deuda hoy = saldo a esa fecha + compras − pagos desde el día siguiente. En la app: Tarjetas → tarjeta → ↻ Actualizar saldo.
- Al asignar una compra: ✉ De un sobre · 💳 Mía, sin sobre · 🤝 Para otra persona. Pantalla «Me deben» (Más) y widget en Inicio. Al llegar un ingreso por el mismo monto: "¿Es el pago de…?". Columnas nuevas en Movimientos: "Para otra persona" y "Cobro".
- Servidor 2.2.0: actualizarSaldoCuenta, marcarMovimiento acepta Para otra persona / Cobro / Nota; las columnas se crean solas la primera vez (V22_LISTO).

## Versión 2.3.0 (solo página; servidor 2.2.1)
- Leer comprobantes en foto (dentro del teléfono, Tesseract en js/vendor/ocr): + → Otros → 📷 Leer comprobante, o Tarjetas → 📷 Pago desde foto, o Compartir → Finanzas desde la app del banco. Toma monto, tarjeta (últimos 4), fecha, cuenta origen y documento (no duplica).
- Estado de cuenta de BCR SAFI en PDF (pdf.js en js/vendor/pdfjs): Fondos → 📄 Cargar estado de cuenta, o Compartir → Finanzas. Lee el "Saldo Final" de cada subcuenta y lo empareja por nombre (la subcuenta 0 = Principal).
- Compartir → Finanzas: manifest share_target + sw.js guarda el archivo en la caché "mf-compartido".

## Versión 2.3.1 (página + servidor) · arreglo de filas repetidas
- Servidor: cada orden de la cola trae un id; si llega repetida (se cortó la respuesta), devuelve el mismo resultado sin volver a escribir (CacheService 6 h). guardarMovimiento_ no agrega otro movimiento con la misma Autorización. Origen fuera de la lista de Config → "Manual".
- Página: lo leído de fotos se guarda con Origen "Manual"; reintentos con espera creciente (30 s → 10 min) si falla la red; "Quitar" en Por enviar a Google.

## Versión 2.3.2 (solo página; servidor 2.3.1)
- Pago de tarjeta: al asignarlo se puede elegir "💳 Sin sobre" (chip "Todo sin sobre" o en la lista de cada fila), también para solo una parte del pago. Se guarda como fila sin sobre en Movimientos de sobres, así el pago deja de estar en Por asignar y ningún sobre baja.
- Detalle del movimiento: la caja Sobres muestra "✓ Cubierto con lo reservado de tus compras ₡x" y las filas sin sobre como "💳 Sin sobre". En la lista, un pago cerrado solo con "sin sobre" lleva la etiqueta "💳 Sin sobre".

## Versión 2.4.0 (solo página; servidor 2.3.1)
- Selector propio en TODAS las listas (<select> queda escondido y guarda el valor; un botón abre una hoja "Elegí…" con buscador si hay más de 7 opciones). Para sobres: MÁS USADOS (3), TODOS (A–Z), ícono, saldo en color (verde / amarillo bajo / rojo negativo), "💳 Sin sobre" al final. Hoja centrada con ancho máximo 520 px (Fold abierto, tablet); filas de 52 px.
- Nombres de sobre bonitos (solo visual): sin "SOBRE" al inicio y en tipo título ("SOBRE SAMMY COLEGIO" → "Sammy Colegio"); siglas como BCR/IPTV y números quedan igual. Íconos automáticos por palabras del nombre, ✉ si no reconoce.
- Las filas de la hoja Sobres que no son sobres ("Total asignado ₡/$", la nota de Pago de tarjeta) ya no se leen como sobres (C.esSobreReal).
- Pago de tarjeta (P2): lista de compras de esa tarjeta sin sobre (pendientes, y las "sin sobre" desde el pago anterior), con sobre sugerido (último usado para ese comercio o el más usado de la categoría) y marcadas solas hasta donde alcance el pago. Al guardar, cada compra marcada se asigna a su sobre ("Compra con tarjeta") y lo reservado cubre el pago; lo que sobre se reparte a mano con filas donde la última se llena sola. Barra "Repartido ₡x de ₡pago".

## Versión 2.4.1 (solo página; servidor 2.3.1)
- Asignar un gasto (SINPE, compra): opción nueva "✉ De varios sobres" con filas sobre + monto (la última se llena sola) y barra "Repartido ₡x de ₡y". Guarda una fila por sobre en Movimientos de sobres (tipo Gasto, o Compra con tarjeta si es tarjeta; "Sin sobre" si la fila no tiene sobre).

## Versión 2.5.0 (página + servidor + manifiesto)
- Servidor: Extras.js (preferencias PREFS; resumenAvisos_; llave de avisos del teléfono; resumen diario por correo con activador cada hora `avisoCorreoHora`; actualización automática por API de Apps Script con URL fija la primera vez, verificación sha256 y "volver a la versión anterior"; listas "Super y Otros" en pestañas "Listas" y "Fotos listas", acceso por link con token propio por lista). appsscript.json con oauthScopes (script.projects y script.deployments nuevos).
- Página: zoom bloqueado; letra Pequeña; Ajustes animados (opción B); PIN/huella para cambiar URL o clave (verificación local PBKDF2 sin servidor, 5 intentos → 5 min); editar Inicio con mantener presionado (tamaños, arrastrar, ×, + Widget/+ Acceso) y Más sin repetir lo fijado (4 accesos); salario (bisemanal/semanal/quincenal/mensual, tarjeta "Hoy es día de salario", reparto con lo del salario anterior); avisos A (periodicSync en sw.js) + C; tarjeta de versión nueva y de servidor desactualizado; Ajustes → Actualizaciones; Super y Otros (lista base, editar/en el super, fotos opcionales, "¿este sirve?", compartir por link → lista.html + js/lista.js, terminar compra).
- Publicación: herramientas/armar_codigo.py ahora también escribe web/servidor/Codigo.gs y web/version.json (versión, sha256, novedades de herramientas/novedades.txt y manifiesto).

## Versión 2.5.1 (solo página; servidor 2.5.0)
- "＋ Acceso" abre una hoja: elegir el acceso y su tamaño (Ícono en la fila · Mediano media fila · Ancho fila entera) con vista previa. Los accesos medianos/anchos son widgets `acc:<clave>` con un dato útil (datoAcceso) y se mueven, cambian de tamaño y se quitan como los demás; en Más no se repiten.
- Mover widgets: mantener presionado el widget entero (o la manija ⠿) y arrastrar, siguiendo el dedo en todo el documento (antes se perdía el dedo al mover el nodo); la pantalla se desliza sola cerca del borde; botones ↑ ↓ en cada widget.

## Versión 2.5.2 (solo página; servidor 2.5.0)
- Widgets que solo tienen algo en ciertos casos (Viaje activo, Me deben, Tasa cero, Fondos, Préstamo, Sobres…) ya no desaparecen de Inicio cuando no hay datos: se ven punteados con un mensaje ("Ningún viaje en curso · Crear uno ›", "Nadie te debe ✓"…) y llevan a su pantalla. Antes parecía que "no se agregaban".

## Versión 2.5.3 (solo página; servidor 2.5.0)
- Planeador de pagos (Tarjetas → "📋 Planear pago" y Más → Planificar → "Planear pago", también como acceso de Inicio): compras y devoluciones de la tarjeta sin marcar como pagadas (columna Cobro = "Pagada dd mmm · plan"), desde el corte que cubrió el último pago; atajos Hasta el corte / Todo / Solo sin sobre / Ninguna; elegir sobre por compra (sugerido, "Todo de un sobre…", "💳 Sin sobre"); total en vivo y "Sacá de tus sobres".
- Pagar: copiar monto; "Ya pagué" crea el Pago de tarjeta (Autorización PLAN-…), asigna las compras a sus sobres, las marca pagadas y, cuando el pago llega a Google, cierra lo que lo apartado no cubra con una fila sin sobre (cerrarPagoPlan: ya se descontó en cada compra). "Guardar plan" (PREFS.planes): cuando llega un Pago de tarjeta por el mismo monto, tarjeta en Inicio y botón en Asignar "Usar el plan".
- Movimientos: mantener presionado un movimiento → modo seleccionar; barra con total de gastos/ingresos, desglose por sobre, Copiar y "Asignar a un sobre" para los que están por asignar.

## Versión 2.5.4 (solo página; servidor 2.5.0)
- Historial del préstamo: "Días de anticipo" se muestra redondeado (la hora del recibo hacía 6,9583…).

## Versión 2.5.5 (página + servidor 2.5.5)
- **Sobres:** tocar un sobre abre su pantalla: saldo, meta, botones Cargar / Descargar / Movimientos / Editar, resumen (venía, entró, salió), mini gráfico de 8 meses y filas tipo banco con "Saldo final". Tocar una fila: detalle + Ver el movimiento + Deshacer.
- **Cuenta de ahorros con saldo vivo:** Tarjetas → Otras cuentas → tu cuenta. Primero "↻ Cuadrar con el banco" (poné el saldo de hoy); desde mañana suma ingresos y resta gastos, SINPE, pagos de tarjeta, cuota del préstamo y aportes a fondos. Muestra cuánto está en sobres y cuánto está libre.
- **Ajustes → Cuentas → Cuentas de dónde salen los pagos:** cuenta principal (salario, SINPE, movimientos sin cuenta) y de qué cuenta salen tarjetas, préstamo y fondos.
- **Tarjeta abierta:** 6 íconos; "Movimientos" abre solo los de esa tarjeta (desde el corte, este mes, mes pasado, todo, rango).
- **Movimientos:** chips Hoy, Ayer, Esta semana, mes, Mes pasado, 3 meses, Todo y 📅 Rango; el buscador entiende "octubre", "15/10", ">20000", "5000-10000". Abajo: cantidad y totales.
- **Pantalla angosta (Fold cerrado):** nombres de tarjetas y cuentas completos arriba, chip y monto abajo; la nota de la hoja Cuentas ya no aparece como cuenta.
- **Servidor:** al registrar un pago del préstamo, si una columna con fórmula quedó vacía o con #REF!, copia la fórmula de la fila de arriba.

## Versión 2.5.6 (página + servidor 2.5.6)
- Lector de correos Davibank: "se recibió el pago a su tarjeta" → Pago de tarjeta; avisos de crédito/débito de la cuenta Davibank → Transferencia (con la cuenta, si sus "Últimos 4" están en Cuentas).
- Montos sin separador de miles ("32978.54") se leen completos (antes salía 329).
- Cuentas de ahorro: las transferencias entre tus cuentas suman en una y restan en la otra; si entra plata tuya sin ver de dónde salió, sale de la cuenta principal. Un pago de tarjeta sale de la cuenta donde se ve la salida (o donde entró esa plata justo antes).
- Sobre: el mini gráfico no muestra los meses antes de empezar con sobres. Fondos: intereses negativos con "−".

## Versión 2.5.7 (página + servidor 2.5.7)
- **¿De dónde vino esta plata?** (Sobres → Por asignar): cuando entra plata a una cuenta y la app no ve de dónde salió, pregunta: de otra cuenta tuya (y si era de un sobre), me pagaron (pasa a Ingreso y se reparte) o de una cuenta fuera de la app. Se guarda en la columna nueva **Desde** de Movimientos.
- Si elegís el sobre, el pago de tarjeta del mismo monto (±3 días) se asigna solo a ese sobre.
- Ajustes → Cuentas: "Cada tarjeta se paga desde" (por defecto la cuenta del mismo banco).
- Nombres de cuenta sin importar mayúsculas, tildes ni espacios.

## Versión 2.5.8 (página + servidor 2.5.8 — el servidor se pega a mano)
- Lector: "Pago de Servicio" de Davibank se lee aunque el correo llegue en una línea o con la tabla desordenada (nombre del servicio, fecha del correo, tarjeta Davibank).
- Lector general: una fecha futura del texto (vencimiento) no se usa; vale la del correo.
- Ajustes → Actualizaciones: si el servidor no se puede instalar solo (API de Apps Script sin habilitar en el proyecto oculto), se recuerda y se muestran directo los pasos para pegarlo a mano, con botón para actualizar la app igual.

## Versión 2.5.9 (solo página; servidor 2.5.8)
- Cuentas de ahorro: transferencias entre cuentas y pagos de tarjeta se emparejan por cercanía en el tiempo (antes, dos operaciones del mismo monto en días seguidos podían cruzarse y salía un débito doble).

## Servidor 2.5.10 (página sigue 2.5.9)
- Lector Davibank con el formato real de Gmail (negritas con *, ₡ como &#x20A1;): pago de servicio, crédito y débito de la cuenta entran completos.

## Versión 2.6.0 (página + servidor 2.6.0 — el servidor se pega a mano)
- **Para revisar**: tarjeta en Inicio ("Llegaron N · X listos ✓ · Y necesitan un toque") → pantalla con lo que necesita una decisión (sobre sugerido, categoría, ¿de dónde vino?) con botones, y lo que la app hizo sola. "Todo bien ✓" guarda lo revisado; "Algo está raro" → tocar el movimiento para corregirlo en la app.
- **Todo al día**: tarjetas, cuentas y sobres que cambiaron, con botón "Cubrir" para sobres en negativo.
- Lector Davibank con el texto real de Gmail; cambiar la fecha de un movimiento cambia la de sus sobres; foto de transferencia recibida → Ingreso; nombres cortos.
- El aviso del teléfono "por revisar" abre Para revisar.

## Versión 2.7.0 (página + servidor 2.7.0 — el servidor se pega a mano)
- Tarjeta con límite solo en ₡: el lector pasa a colones los cobros en dólares (Nota "Cobro original $… · TC … · monto estimado").
- IVA aparte por comercio (Para revisar pregunta la primera vez en cobros en dólares; Ajustes → Cuentas → "Cobros con IVA aparte"); la línea "IVA · X" nace estimada.
- Para revisar: "Por confirmar" (Confirmar monto: ajusta el monto y el sobre) y "¿Entró o salió?" en transferencias sin dirección.
- Lector de fotos: IBAN de origen y destino en orden → Ingreso / Transferencia / Gasto según cuáles sean tuyos (poné los Últimos 4 de tus cuentas).
- Cuenta principal: el número grande es el Disponible (total − sobres − reservado); Cuadrar con el banco pide el disponible.

## Versión 2.8.0 (página + servidor 2.8.0 — el servidor se pega a mano)
- **Espejo del banco**: sobres = sobres del BCR. Compras con tarjeta no tocan sobres (solo deuda + categoría). Al instalar se quitan solas las asignaciones viejas de compras con tarjeta.
- En cada sobre: **📥 Meter** (desde el disponible, de un ingreso o de otro sobre) y **📤 Sacar** (al disponible, con "¿para qué?": pagar una tarjeta / pasar a otra cuenta; o a otro sobre). Queda como fila en Movimientos con Tipo "Sobre → disponible" o "Disponible → sobre".
- Para revisar: si sale plata del BCR, "¿La sacaste de un sobre?" [sobres] [Otro sobre…] [No, del disponible]; si entra: "¿La metiste a un sobre?" [Repartir como siempre] [sobres] [Dejarla disponible]. Si ya sacaste con "para pagar/pasar", se une sola.
- Cuadrar con el banco (cuenta principal) guarda el disponible tal cual.
- Después de instalar: revisar que cada sobre tenga lo mismo que en el BCR (ajustar con Meter/Sacar o Editar → saldo inicial) y cuadrar el disponible.

## Versión 2.9.0 (página + servidor 2.9.0 — el servidor se pega a mano)
- **Tarjetas**: la lista muestra solo lo que debés (o "a favor" en verde) y la barra de uso; la deuda en dólares va del mismo tamaño y en blanco (también en "Deuda total hoy"). Sin "pagar en X días" ni el cambio "desde …": adentro de cada tarjeta quedan "Corte y pago" y "Próximo pago".
- **Avisos de pago**: en el teléfono 3 días antes, 1 día antes y el mismo día (se cambia en Ajustes → Avisos → Pago de tarjeta), con el monto por pagar (la deuda sin las compras hechas después del corte). Si ya pagaste, no avisa. El correo trae la tabla de pagos de los próximos 7 días.
- **Movimientos de la cuenta**: Este mes · Mes pasado · Todo · Rango ("Desde el saldo" solo aparece al venir de Cuadrar → Buscar qué falta).
- **Cobros del BCR en dólares**: el correo dice "US DOLLAR" y se leía como colones (₡13,99 en vez de $13,99); ahora se reconoce y se convierte a colones con nota "monto estimado" (luego Confirmar monto e IVA).
- **Tarjetas que no son mías**: compra de una tarjeta que no está en Cuentas → Para revisar pregunta "¿Es tuya?": ➕ Sí, agregarla (crea la cuenta y anota la compra) · 🚫 No es mía (se ignoran sus correos desde ahora y se borra la compra) · 1️⃣ Solo esta vez. Lista en Ajustes → Cuentas → Tarjetas que no son mías. Mientras no se responde, la compra no toca ninguna cuenta ni sobre.

## Versión 2.10.0 (página + servidor 2.10.0 — el servidor se pega a mano)
- **Varios sobres en un pago**: si sacaste de 2 o más sobres ("para pagar / pasar") y después sale un solo pago, se une solo con esas sacadas; si hay dudas, Para revisar muestra la lista de sacadas [✓ Sí, es eso] [Otro sobre…] [No, del disponible]; si lo sacado no alcanza, pregunta solo por la diferencia [Del disponible] [De otro sobre…] [No era para este pago].
- **Planear pago** (desde la tarjeta → 📋): 1) cuánto (lo del estado de cuenta / todo lo de hoy / otro monto) y moneda ₡ o $; 2) de qué sobres (casillas + monto) y el resto del disponible; 3) anota solo las sacadas; el correo del pago se une solo. Interruptor "Este pago no llega por correo" para anotarlo ya.
- **⚖ Igualar al BCR**: en cada sobre (Corregir el sobre = ajusta el saldo inicial; o Lo metí/saqué del disponible = fila Meter/Sacar) y "⚖ Igualar" en Sobres para todos de una vez.
- **🧮 Calculadora rápida**: botón flotante (se arrastra; se oculta en Ajustes → Apariencia). Con un campo de monto abierto: "Usar ₡X en Monto". En los montos también se puede escribir 10.000+5.000-329.
- **Viajes**: "Por tarjeta" y filtros por tarjeta; cada compra dice su tarjeta; "✈ Es del viaje" en cualquier compra (y sugerencia de vuelos/hotel de antes); presupuesto por categoría opcional (+ "Repartir el límite solo"); categoría nueva Vuelos; efectivo del viaje (retiros de cajero no son gasto) y "+ Gasto en efectivo"; "+ Anotar compra a mano" (avisa si después llega repetida por correo); aviso diario mientras dura el viaje (Ajustes → Avisos → Viajes); 📄 Resumen del viaje con PDF y Compartir.
- Servidor: columnas nuevas en Viajes (ID, Presupuesto) y Movimientos guarda "Viaje" al anotar a mano; resumen de avisos con el viaje en curso.

## Versión 2.10.1 (página + servidor 2.10.1)
- **Bandeja limpia**: lo que la app lee sale de la bandeja de entrada (se archiva, no se borra) y queda leído, con la etiqueta Finanzas/Procesado. Lo que no entiende (Finanzas/Revisar) se queda en la bandeja. La primera vez también se ordenan los correos viejos ya procesados. Interruptor en Ajustes → Correos de los bancos.

## Versión 2.10.2 (página + servidor 2.10.2)
- **Estados de cuenta**: la app los reconoce (asunto "estado de cuenta") y no los toca: se quedan en la bandeja, sin "Revisar" ni "Procesado", para usarlos de recordatorio. Una sola vez, los estados de cuenta que 2.10.1 había sacado de la bandeja vuelven a ella. Compras, pagos y movimientos siguen a Finanzas/Procesado (o Revisar si no se entienden).
- Davibank manda el estado de cuenta desde otro correo (estadosdecuenta@…), que la app no lee: siempre se quedó en la bandeja.

## Versión 2.10.3 (solo página)
- Arreglo: Ajustes → Estado de la app decía "El servidor tiene una versión vieja (2.10.2)" por error (comparaba "2.10" con "2.2" como texto). El servidor no cambia.

## Versión 2.10.4 (página + servidor 2.10.4)
- **Super y Otros → Nueva lista → 🛍 Tiendas y mall**: lista para ropa, calzado, medias, ropa interior, abrigos, accesorios, perfumería, electrónica, hogar, niños y regalos. Se pone para quiénes es (separados por coma). Lista base con lo más común de un mall (se marca lo que se quiere; "todas" por sección).
- Cada cosa: sección, para quién, talla, color, cantidad, precio máximo, tienda, nota y foto. Escritura rápida: "tenis talla 9 negros para Fernando", "2 medias deportivas para todos en Albrook".
- Ver por persona / por sección / por tienda. Modo 🛍 Comprando: marcar lo comprado y anotar cuánto se pagó (＋ $) → "Gastado hasta ahora". Compartir con link igual que la del super (la otra persona ve las mismas vistas, marca, agrega y pregunta "¿este sirve?").
- Personas de la lista: ⋯ → Personas.

## Versión 2.10.5 (página + servidor 2.10.5)
- **📦 Encargos** (listas de Tiendas y mall): pestaña aparte [🛍 Nuestras] [📦 Encargos]. Cada persona que encarga tiene nombre, adelanto y moneda; cada encargo: qué, sección, talla/modelo, color, cantidad, precio máximo, tienda, foto y nota. Ver por persona / tienda / estado.
- Al marcar un encargo: cuánto costó y con qué se pagó (tarjeta o efectivo); "No lo encontré".
- Si se pagó con tarjeta, cuando llega el correo del banco (mismo monto, también si la tarjeta lo convirtió a colones) la compra queda "para" esa persona en Me deben y el encargo dice "👛 ligado".
- 🧾 Cuentas: por persona total, adelanto, le sobran / te debe ($ y ₡), "↗ Mandar cuenta" (texto para WhatsApp), Entregado, "👛 Pasar a Me deben", "✓ Cerrar cuenta". "Terminar compras" no borra los encargos.
- En la lista compartida los encargos se ven aparte, por persona.
## Versión 2.10.6 (página + servidor 2.10.6)
- **👪 Tarjetas de la familia (solo viajes):** compras de tarjetas de otra persona de la casa (esposa, hijos) que llegan reenviadas a tu Gmail. Se anotan como "Familia ••1234" y **no tocan** cuentas, deudas, sobres, resumen del mes ni Me deben; solo cuentan en los viajes.
- Lector nuevo de **BAC Credomatic** ("Notificación de transacción"); el remitente NotificacionBAC@baccredomatic.cr se lee aunque no esté en Config.
- Correos reenviados (filtro de Gmail, o a mano): solo se anotan compras de tarjetas de la familia; pagos de su tarjeta y otros avisos de ella no se anotan.
- "¿Es tuya?" → "👪 De mi familia · solo para viajes" (persona + nombre de la tarjeta); las compras que ya habían llegado de esa tarjeta pasan solas. Ajustes → Cuentas → **Tarjetas de la familia** (agregar, editar, quitar, contador).
- Viaje: entran solas las de la familia en las fechas (se puede desmarcar "👪 Tarjetas de la familia" en Editar viaje). **Por persona y tarjeta**, filtros por persona y tarjeta, cada compra dice de quién es.
- Resumen: por persona y tarjeta; **PDF completo** (resumen + una página por tarjeta) y **📄 Solo <persona>**.

## Versión 2.10.7 (solo página)
- 🏧 Retiros del viaje tocables: en "Te queda en efectivo" cada retiro tiene ›. Retiro real de la cuenta → "Quitar del viaje" (queda marcado Fuera; la cuenta y los sobres no cambian). Anotado a mano → "Borrar retiro". En el detalle del movimiento: "🏧 Efectivo del viaje X · Quitar del viaje".
## Versión 2.10.8 (página + servidor 2.10.8)
- 💵 "＋ Efectivo / retiro" en el viaje: "¿De dónde sale?" tiene la opción "De ninguna cuenta (ya lo tengo en efectivo)". Se anota con cuenta Efectivo y marca Efectivo@viaje: suma a "Te queda en efectivo", no es gasto del mes, no toca cuentas ni sobres. Tocándolo → Borrar.
## Versión 2.10.9 (solo servidor)
- Arreglo: la columna "Cuenta / tarjeta" de Movimientos tiene lista desplegable que rechazaba "Efectivo" (y rechazaría "Familia ••1234"): la fila quedaba a medias (sin cuenta ni viaje) y la app lo deshacía. Ahora esa validación pasa a "mostrar advertencia" sola y se escribe completo; si algo falla, un movimiento nuevo no queda a medias.
## Versión 2.10.10 (página + servidor)
- Arreglo de verdad del efectivo del viaje: Google junta las escrituras y el rechazo de la lista desplegable de "Cuenta / tarjeta" salía después, sin error (la fila quedaba sin cuenta ni viaje). Ahora antes de escribir revisa si el valor está en la lista; si no, esa columna pasa a "advertencia". Además flush() para que cualquier error salga en el momento. La app avisa si el servidor es menor a 2.10.10.
## Versión 2.10.11 (solo página)
- Viaje → ＋ Anotar compra a mano: "Pagado con" incluye las tarjetas de la familia (👪 Ana · Visa BAC ••1234). Se anota como Familia ••1234 (solo viajes). Si después llega el correo con el mismo monto (±36 h), el viaje pregunta "¿Es la misma compra?" → borrar la de a mano.
## Versión 2.11.0 (página + servidor 2.11.0)
- **#52 Activar / desactivar tarjetas y cuentas:** Ajustes → Cuentas → "Mis tarjetas y cuentas": interruptor por cada una (filtros Todas / Activas / Desactivadas), tocar el nombre para editar, ＋ agregar. Si una tarjeta con deuda se desactiva, avisa antes. En Tarjetas sale "N desactivadas · tocá para activar". Si llega una compra de una desactivada: se anota igual y Para revisar pregunta "Activarla / Anotar sin activarla".
- **#49 ¿Cobro repetido?:** dos compras por correo con la misma cuenta, monto y moneda, comercio parecido y hasta 2 h de diferencia (autorizaciones distintas) → Para revisar y el viaje preguntan "Borrar el 1ro / Son distintas". Nunca borra sola. (Falta: leer el correo de rechazo/devolución, cuando llegue un ejemplo.)
- **#51 Cuotas tasa cero al corte:** en tarjetas con día de corte, cada cuota se carga como fila "Cuota tasa cero" (autorización TC-<fila>-<n>) en el corte anterior a su fecha de pago; suma al pago de contado siempre (con saldo a favor, lo consume). La compra tasa cero ya no suma completa a la deuda. Detalle de la tarjeta: "+ N cuotas tasa cero (al corte)" y "SALDO TASA CERO". No pide sobre ni cuenta como gasto del mes. Solo carga cortes después del saldo puesto (máx. 120 días atrás). Si se borra una cuota, no se vuelve a crear en ese teléfono.
- **#50 Calculadora:** botón fijo abajo a la derecha (ya no se arrastra); se abre como hoja desde abajo a todo el ancho, teclas de 60 px y resultado grande.
## Versión 2.12.0 (página + servidor 2.12.0)
- **#53 Presupuesto** (Más → Planificar → Presupuesto). PREFS.presupuesto = { modo: 'mes'|'salario', limites: {categoría: ₡ al mes}, inv: {fondo: meta al mes} }.
- Cuenta todo Gasto por categoría (tarjeta, cuenta, efectivo; USD al tipo de cambio). No cuentan: viajes, "para otra persona", pagos de tarjeta, efectivo llevado al viaje.
- Por mes o por salario (período entre pagos; los límites se reparten por días/30,44). Barra con rayita de "hoy"; estados Vas bien / Vas rápido (>10 pts adelante del tiempo y ≥50%) / Te pasaste; ₡ por día.
- "📈 Primero, invertir": meta por fondo; cuenta aportes − retiros del período.
- Límites y metas: "lo libre" (salario promedio 3 meses − sobres − tasa cero − préstamo − inversión, sin restar doble), promedio de 3 meses como sugerencia, "Usar mis promedios".
- Tocar una categoría: quién gastó (persona y tarjeta), compras, cambiar el límite. Cierre del período anterior: sobró / se pasó, sugerencia de subir si lleva 3 períodos pasándose.
- Tarjetas de la familia: campo nuevo "En el presupuesto…" (no cuentan / según la categoría / todo en una categoría, ej. Supermercado). familia[u4].presu.
- Avisos al 80% y al pasarse: en la app (toast), notificación del teléfono y correo de la mañana (tipo "Presupuesto" en Ajustes → Avisos).
## Versión 2.13.0 (página + servidor 2.13.0)
- **#56 Calculadora:** ícono nuevo (dibujo de calculadora). En Inicio, Movimientos, Tarjetas, etc. va en el encabezado al lado del + (fila 1: mes + botones; fila 2: título). El botón flotante solo sale en pantallas sin + o con un formulario abierto. Teclas alineadas y signos centrados (la clase global ".op" les metía margen: ahora calc-op / calc-c / calc-eq). La preferencia "mostrar calculadora" pasó a la clave mf-calc-ver (mf-calc es la calculadora de préstamos).
- **#57 Interruptores:** Tarjetas de la familia → Activa / Pausada (familia[u4].pausada; el servidor salta sus avisos sin preguntar, cuenta en AJENAS_SALTADAS como "f1234"). Tarjetas que no son mías → Ignorada / Sin ignorar (ajenas[u4].off; apagada → vuelve a "¿Es tuya?"). Filtros y resumen en Ajustes.
- **#58a Categorías** (Ajustes → Cuentas → Categorías): agregar, renombrar (opción: pasar movimientos, reglas, límite del presupuesto y tarjetas de familia al nombre nuevo), quitar. Escribe en Config → "Categorías" (ya lee más de 30).
- **#58b Reglas automáticas** (Ajustes → Cuentas → Reglas automáticas): lista con buscador y filtros (con sobre / sin usar), editar, borrar, nueva. D.reglas en obtenerDatos.
- **#58c / #54 Tasa cero:** ✏️ en el detalle de la compra: descripción, monto, meses, tarjeta, primera cuota. Al cambiar la tarjeta mueve la compra original, los abonos y las cuotas ya cargadas. "Quitar de tasa cero": la compra vuelve a Gasto, se borran abonos y cuotas; la fila de Tasa Cero queda con Estado = "Quitada" (no se borra para no mover el número de las otras, que usan TC-<fila>-n).
- **#55:** "Lo libre" del presupuesto con salario bisemanal = pago × 26 ÷ 12 (semanal × 52 ÷ 12, quincenal × 2). Sin monto configurado usa el promedio de cada pago.

## Versión 2.14.0 (página + servidor 2.14.0)
- **#61 Al abrir: todo al día solo.** Al abrir (o volver a la app después de 20 s afuera) se ven al instante los datos guardados (montos un poco grises) y por detrás, en paralelo: `abrirApp` (¿PIN? + datos, o "sin cambios" si la marca DATOS_VER es la misma y los datos tienen menos de 6 h) y `revisarAlAbrir` (lee los correos nuevos si pasaron más de 2 min; REVISION_APP). Si entraron compras, se vuelven a traer los datos. Píldora arriba: "Revisando correos…" → "✓ N compras nuevas" / "✓ Al día" / "⚠ Sin conexión · datos de hace X". Lo que entró por correo o recurrente desde la última vez sale con la etiqueta NUEVA (30 min) y un aviso abajo con "Ver". La marca DATOS_VER cambia con cualquier escritura de la app (todo lo que no está en LECTURAS_), con correos/recurrentes nuevos, cada mañana y al editar la hoja a mano (activador `alEditarHoja`, se instala solo la primera vez). Con un servidor viejo la app usa el arranque de antes.
- **#60 Destello:** la onda nace donde tocás y se queda dentro del botón o fila (sirve con cualquier tamaño de letra). Color del tema; en botones pintados, clara u oscura según la letra.
- **#58d Bancos que se leen** (Ajustes → Correos): lista con interruptor (Activo / Inactivo en Config!C), agregar (primera fila libre de la 5 a la 14), cambiar correo, quitar. Siempre se leen: SINPE BCR, préstamo, fondos SAFI, BAC (familia).
- **#58e Recurrentes** (Ajustes → Movimientos o Más → Recurrentes): lista, pausar, editar, nuevo, borrar. Los nuevos van al final y los borrados dejan la fila vacía (la clave REC-mes-fila no se corre).
- **#58f Mis sobres** (Ajustes → Sobres): saldo inicial, reparto, meta y archivar (solo con saldo 0; columna "Archivado" en Sobres; el reparto queda en 0). Archivados aparte (D.sobresArch), se pueden activar.
- **#58g Subcuentas de fondos:** archivar desde la subcuenta (solo con saldo 0; columna "Archivada" en Fondos). Sección "Archivadas" en Fondos.
- **#59 Ajustes ordenado:** sin interruptor de la calculadora (siempre arriba); "Cuentas" → "Cuentas y tarjetas" + "Movimientos"; "de dónde salen los pagos" pasa a chips dentro de cada cuenta de ahorro (Principal / Tarjetas / Préstamo / Fondos; el detalle por tarjeta sigue en "Cada tarjeta por separado"); tipo de cambio editable (Config B15); "Conexión con Google" junta servidor + cambiar URL o clave; "Nombre en los PDF" pasó a la calculadora de préstamos.
- Arreglo: los avisos (toast) ya no muestran código HTML (ej. cuotas de tasa cero al corte).

## Versión 2.15.0 (página + servidor 2.15.0)
- **#62 Pagos por cada tasa cero.** Pestaña "Abonos tasa cero" con columna nueva **Tipo** (se crea sola): "Baja la cuota" (o vacío, como antes), "Adelanto" (el banco mantiene la cuota y queda saldo a favor) o "Pago de cuota" (parte de un pago a la tarjeta).
  - **Registrar pago** a una tarjeta con tasa cero: sección "¿A qué tasa cero va?", llena con la cuota de cada compra (la del plan más cercana a la fecha del pago). Sigue siendo un solo pago; el reparto se guarda como filas "Pago de cuota" ligadas al pago (`guardarRepartoTC`; un pago nuevo se encuentra por su autorización PAGO-…). Al abrir el pago se puede cambiar el reparto; al borrarlo se borra su reparto.
  - **Abono extra:** "¿Qué hizo el banco?" → Bajó la cuota (como antes) / Mantiene la cuota · queda a favor (adelanto: no cambia la cuota ni cuenta como gasto). Un abono viejo se puede abrir y pasar a adelanto.
  - **＋ Pago** dentro de la compra: anota pagos de meses atrás sin tocar la deuda de la tarjeta.
  - **Detalle:** "Le has puesto / Te falta poner", cobrado por el banco, cuotas de antes (antes del primer pago o adelanto se toman como pagadas), pagado por vos, cubierto con el adelanto, cuotas sin pago anotado, adelanto que queda y para cuántos meses alcanza pagando lo mismo. En la tarjeta: "vos ₡X" junto a cada cuota y "Adelantos a favor".

## Versión 2.16.0 (solo página; el servidor sigue en 2.15.0)
- **#63** Sacar o meter de un sobre: al abrir de nuevo el monto empieza vacío (solo se conserva al cambiar de opción dentro de la misma ventana).
- **#64** La calculadora flotante se esconde mientras haya una ventana abierta (formulario, "+", elegir); vuelve al cerrarla.
- **#65** La ventana de "+" ya no se corre de lado: solo la fila de sugerencias se desliza. Sugerencias con nombres cortos (sin PENDING, .COM, país, INC; ej. "IVA · Uber San Francisco").

## Versión 2.17.0 (página + servidor 2.17.0)
- **#66 Presupuesto por corte.** Ajustes → Cuentas y tarjetas → Presupuesto por corte (o desde Presupuesto). Se guarda en PREFS.cortes: `[{ cuenta ("Familia ••1234" o el nombre de una tarjeta), nombre, monto, dia (día de corte), enMes (contar en el presupuesto del mes, apagado por defecto), aviso, on }]`. Corte = del día siguiente al corte anterior hasta el día de corte (día 31 en meses cortos → último día). En Presupuesto: bloque "APARTE · POR CORTE" con gastado, queda, días que faltan y por día; detalle con ritmo vs ideal, compras del corte, ＋ Compra, cortes anteriores (sobró / se pasaron) y flechas. Aviso al 80 % y al pasarse (una vez por corte). Con `enMes` apagado esas compras no cuentan en el presupuesto del mes.
- **#67 Compras a mano.** El "+" ofrece también las tarjetas de la familia activas ("👪 Persona · Visa ••1234") y recuerda la última tarjeta. Al leer correos, si una compra ya estaba anotada a mano (misma cuenta, tipo, moneda y monto, mismo día o un día de diferencia, sin autorización) se **une**: toma la autorización y la fecha del correo, Origen pasa a Correo, se quedan tu nombre y categoría, y la nota dice "Unida con el correo del banco".

## Versión 2.17.1 (solo página; servidor 2.17.0)
- Arreglo: al tocar "Cambiar ›" en el "+" con la tarjeta de la familia, el formulario completo no la tenía en la lista y la compra quedaba sin cuenta (se restaba de la cuenta principal). Ahora el formulario de movimientos también ofrece las tarjetas de la familia, y una compra de la familia no lleva sobre.
- #68 (parte): la opción sin cuenta ahora dice "Sin cuenta · sale de <cuenta principal>".

## Versión 2.18.0 (página + servidor 2.18.0)
- **Devoluciones en la tarjeta de la casa.** En el "+", con la tarjeta de la familia elegida, los botones son "Compra" y "↩ Devolución" (se guarda como Ingreso en esa tarjeta, nota "Devolución / crédito"). El presupuesto por corte resta las devoluciones (Ingreso) y separa compras, devoluciones y lo "por confirmar". Una devolución de la familia no cuenta como ingreso tuyo.
- **IVA de servicios del exterior aunque llegue en colones.** Google, Netflix, Spotify, Apple, Disney, YouTube, Microsoft, etc. en tus tarjetas o en las de la familia: "¿El banco le cobra el IVA aparte?" en Para revisar; si sí, se anota "IVA · …" estimado (13 %) por confirmar. Al leer correos, un cobro que diga IVA / impuesto en la misma tarjeta (2 días antes a 20 después, monto ±25 % o ₡300) **confirma** el estimado con el monto real (`buscarIVAEstimado_`).
- **App de la casa** (`web/casa.html`, `js/casa.js`, `casa-sw.js`, `casa.webmanifest`, íconos `icons/casa-*.png`). Desde el detalle del corte → "📲 App para …": crear link, WhatsApp/Copiar, permisos (anotar; corregir/borrar lo suyo), link nuevo, apagar. El link es `casa.html#s=<implementación>&k=<llave>`; la página lo guarda en el teléfono y se instala con su propio ícono. Servidor: propiedad `CASA` `{ "<cuenta>": { token, persona, anotar, corregir, creado, ultima } }`; `doPost` con `casa` → `apiCasa_` (ver / guardar / borrar). Solo devuelve los Gasto/Ingreso de esa tarjeta de los últimos 6 cortes, sin autorizaciones; lo que ella anota va siempre a esa tarjeta, sin sobre, nota "app de la casa · <persona>", y solo puede cambiar o borrar lo suyo.
