/**
 * Codigo.js — La web app: muestra la página y responde a lo que pide.
 */

/**
 * Codigo — La app vive en GitHub Pages (carpeta web/). Este código es el
 * "servidor": recibe los pedidos de la app (doPost) y lee/escribe la hoja.
 */
function doGet() {
  return ContentService.createTextOutput('Finanzas: servidor funcionando. La app se abre desde GitHub Pages.');
}

/** Ejecutar UNA vez desde el editor: guarda la hoja, la zona horaria y activa lo automático. */
function configurarInicial() {
  var libro = SpreadsheetApp.getActive();
  if (!libro) throw new Error('Abrí Apps Script desde la hoja: Extensiones → Apps Script.');
  var p = PropertiesService.getScriptProperties();
  p.setProperty('SHEET_ID', libro.getId());
  libro.setSpreadsheetTimeZone('America/Costa_Rica');
  if (!p.getProperty('CLAVE_APP')) p.setProperty('CLAVE_APP', nuevaClave_());
  activarAutomatico();
  console.log('✅ Listo. Hoja: ' + libro.getName() + '. Correos cada 15 min; recurrentes y recordatorios cada día.');
  verClaveApp();
}

function nuevaClave_() {
  return (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '').slice(0, 32);
}

/** Muestra la clave que se escribe en la app (Configuración → Conexión). */
function verClaveApp() {
  console.log('🔑 Clave de la app: ' + PropertiesService.getScriptProperties().getProperty('CLAVE_APP'));
}

/** Crea una clave nueva (la anterior deja de funcionar en todos los teléfonos). */
function cambiarClaveApp() {
  PropertiesService.getScriptProperties().setProperty('CLAVE_APP', nuevaClave_());
  verClaveApp();
}

// ---------------------------------------------------------------------
// LECTURA: todo lo que la app necesita, en una sola llamada
// ---------------------------------------------------------------------
function obtenerDatos_() {
  var marca0 = marcaDatos_();   // v2.14: se lee ANTES de leer la hoja (si algo cambia mientras tanto, la próxima vez trae todo)
  try { asegurarTiposV28_(); } catch (e) { console.log(e); }
  var cfgH = hoja_('Config');
  var tc = num_(cfgH.getRange('B15').getValue()) || 0;

  var cuentas = leerTabla_('Cuentas', 'Nombre (único)').filas.map(function (r) {
    return {
      fila: r._fila, nombre: texto_(r['Nombre (único)']), tipo: texto_(r['Tipo']), banco: texto_(r['Banco']),
      ultimos4: texto_(r['Últimos 4']), moneda: texto_(r['Moneda principal']) || 'CRC',
      limiteCRC: num_(r['Límite ₡']), limiteUSD: num_(r['Límite $']),
      diaCorte: num_(r['Día de corte']), diaPago: num_(r['Día de pago']),
      activa: texto_(r['Activa']) !== 'No',
      saldoCRC: num_(r['Saldo actual ₡']), saldoUSD: num_(r['Saldo actual $']), fechaSaldo: iso_(r['Fecha del saldo']), notas: texto_(r['Notas'])
    };
  });

  var mov = leerTabla_('Movimientos', 'Fecha').filas;
  var movimientos = mov.slice(-3000).map(function (r) {
    return {
      fila: r._fila, fecha: iso_(r['Fecha']), comercio: texto_(r['Comercio / descripción']), lugar: texto_(r['Lugar']),
      monto: num_(r['Monto']) || 0, moneda: texto_(r['Moneda']) || 'CRC', tipo: texto_(r['Tipo']) || 'Gasto',
      cuenta: texto_(r['Cuenta / tarjeta']), categoria: texto_(r['Categoría']), sobre: texto_(r['Sobre']),
      origen: texto_(r['Origen']), autorizacion: texto_(r['Autorización']), nota: texto_(r['Nota']),
      subcuenta: texto_(r['Subcuenta']), viaje: texto_(r['Viaje']), para: texto_(r['Para otra persona']), cobro: texto_(r['Cobro']), desde: texto_(r['Desde'])
    };
  });

  // las preparaciones de versiones anteriores solo corren hasta que quedan hechas (una lectura de propiedades)
  if (PropertiesService.getScriptProperties().getProperty('V17_LISTO') !== 'si') { prepararSobresV16_(); prepararV161_(); prepararV17_(); }
  if (PropertiesService.getScriptProperties().getProperty('V22_LISTO') !== 'si') prepararV22_();
  var sobres = leerTabla_('Sobres', 'Sobre');
  var formulasSob = sobres.hoja.getRange(1, sobres.cols['Asignado por mes'], sobres.hoja.getLastRow(), 1).getFormulas();
  var listaSobres = sobres.filas.map(function (r) {
    return {
      fila: r._fila, nombre: texto_(r['Sobre']), moneda: texto_(r['Moneda']) || 'CRC',
      asignado: num_(r['Asignado por mes']), tipo: texto_(r['Tipo']) || 'Variable', notas: texto_(r['Notas']),
      asignadoAuto: !!formulasSob[r._fila - 1][0],
      saldoInicial: num_(r['Saldo inicial']) || 0, ajuste: texto_(r['Ajuste del reparto']) === 'Sí', meta: num_(r['Meta']),
      archivado: texto_(r['Archivado']) === 'Sí'   // v2.14 (#58f)
    };
  });

  var tasaCero = leerTabla_('Tasa Cero', 'Descripción').filas.filter(function (r) { return texto_(r['Estado']) !== 'Quitada'; }).map(function (r) {
    return {
      fila: r._fila, descripcion: texto_(r['Descripción']), tarjeta: texto_(r['Tarjeta']),
      fechaCompra: iso_(r['Fecha de compra']), monto: num_(r['Monto total']) || 0, moneda: texto_(r['Moneda']) || 'CRC',
      meses: num_(r['Meses']) || 1, primeraCuota: iso_(r['Primera cuota']), abonos: []
    };
  });
  // Abonos extra: se unen a su compra por descripción + tarjeta
  leerAbonosTC_().forEach(function (a) {
    var t = tasaCero.filter(function (x) { return x.descripcion === a.compra && (!a.tarjeta || x.tarjeta === a.tarjeta); })[0];
    if (t) t.abonos.push(a);
  });

  return JSON.stringify({
    hoy: new Date().toISOString(),
    marca: marca0,
    tipoCambio: tc,
    cuentas: cuentas,
    movimientos: movimientos,
    sobres: listaSobres,
    tasaCero: tasaCero,
    prestamo: datosPrestamo_(),
    tasas: leerTabla_('Tasas BCCR', 'Fecha de la TBP (día 7)').filas.slice(-24).map(function (r) {
      return { fecha: iso_(r['Fecha de la TBP (día 7)']), tbp: num_(r['TBP']), tasa: num_(r['Tasa del préstamo']) };
    }),
    categorias: listaConfig_('Categorías'),
    reglas: leerTabla_('Reglas', 'Si el comercio contiene').filas.map(function (r) { return { fila: r._fila, patron: texto_(r['Si el comercio contiene']), categoria: texto_(r['Categoría']), sobre: texto_(r['Sobre']) }; }).filter(function (r) { return r.patron; }),
    tiposCuenta: listaConfig_('Tipos de cuenta'),
    tiposMovimiento: listaConfig_('Tipo de movimiento'),
    sobreEspecial: sobresEspeciales_(listaSobres.map(function (s) { return s.nombre; })),
    sobresMov: leerSobresMov_(),
    ajustes: (function () { try { return obtenerAjustes_(); } catch (e) { return null; } })(),
    fondos: leerFondos_(),
    recurrentes: (function () { try { return leerRecurrentes_(); } catch (e) { return []; } })(),   // v2.14 (#58e)
    viajes: leerViajes_(),
    sobresDesde: PropertiesService.getScriptProperties().getProperty('SOBRES_DESDE'),
    ultimaRevision: PropertiesService.getScriptProperties().getProperty('ULTIMA_REVISION')
  });
}

function datosPrestamo_() {
  var t = leerTabla_('Préstamo casa', 'Fecha de pago');
  var h = t.hoja;
  // Cuadro de indicadores (celdas fijas de la pestaña)
  var g = h.getRange('G4:G11').getValues().map(function (r) { return r[0]; });
  var c = h.getRange('C4:C11').getValues().map(function (r) { return r[0]; });
  var k = h.getRange('K5:K8').getValues().map(function (r) { return r[0]; });
  return {
    operacion: texto_(c[0]), saldoInicial: num_(c[1]), plazo: num_(c[3]),
    tbp: num_(c[6]), tasa: num_(c[7]),
    saldo: num_(g[0]), pagadoPct: num_(g[1]), cuotasPagadas: num_(g[2]), restantes: num_(g[3]),
    ultimoPago: iso_(g[4]), proximoVenc: iso_(g[5]), interesesTotal: num_(g[7]),
    estimado: { principal: num_(k[0]), intereses: num_(k[1]), polizas: num_(k[2]), total: num_(k[3]) },
    pagos: t.filas.map(function (r) {
      return {
        fecha: iso_(r['Fecha de pago']), comprobante: texto_(r['N° comprobante']),
        principal: num_(r['Abono principal']) || 0, intereses: num_(r['Intereses']) || 0,
        polizas: (num_(r['Pólizas']) || 0) + (num_(r['Pólizas BCR']) || 0),
        total: num_(r['Total pagado']) || 0, saldo: num_(r['Saldo']),
        tbp: num_(r['TBP (tasa real)']), tasa: num_(r['Tasa BCR']),
        vence: iso_(r['Vence (día 7)']), anticipo: num_(r['Días de anticipo'])
      };
    })
  };
}

// ---------------------------------------------------------------------
// ESCRITURA
// ---------------------------------------------------------------------
function conBloqueo_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function fechaDe_(isoOTexto) {
  var d = new Date(isoOTexto);
  if (isNaN(d.getTime())) throw new Error('Fecha inválida: ' + isoOTexto);
  return d;
}

/** Crea o actualiza un movimiento. `m.fila` vacío = nuevo. */
function guardarMovimiento_(m) {
  return conBloqueo_(function () {
    if (/→/.test(m.tipo || '')) { try { asegurarTiposV28_(); } catch (e) { console.log(e); } }
    var t = leerTabla_('Movimientos', 'Fecha');
    // v2.3.1: un movimiento nuevo con el mismo número de autorización/documento no se agrega dos veces
    if (!m.fila && m.autorizacion) {
      var ya = t.filas.filter(function (r) { return texto_(r['Autorización']) === String(m.autorizacion); })[0];
      if (ya) return ya._fila;
    }
    // el origen tiene que ser uno de la lista de Config (si la columna tiene validación, otro valor da error)
    var origenes = listaConfig_('Origen');
    if (origenes.length && origenes.indexOf(m.origen || 'Manual') < 0) m.origen = origenes.indexOf('Manual') >= 0 ? 'Manual' : origenes[0];
    var fila = m.fila || primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Fecha']);
    if (m.fila) verificarFila_(t.hoja, m.fila, t.cols, m.control);
    var datosMov = {
      'Fecha': fechaDe_(m.fecha),
      'Comercio / descripción': m.comercio || '',
      'Lugar': m.lugar || '',
      'Monto': Number(m.monto),
      'Moneda': m.moneda,
      'Tipo': m.tipo,
      'Cuenta / tarjeta': m.cuenta || '',
      'Categoría': m.categoria || '',
      'Sobre': m.sobre || '',
      'Origen': m.origen || 'Manual',
      'Autorización': m.autorizacion || '',
      'Nota': m.nota || ''
    };
    // v2.10.0: compras de viaje anotadas a mano ("+Comida@id") o retiros para efectivo del viaje
    if (m.viaje !== undefined && m.viaje !== null) { if (!t.cols['Viaje']) { asegurarColumnas_('Movimientos', ['Viaje']); t = leerTabla_('Movimientos', 'Fecha'); } datosMov['Viaje'] = m.viaje; }
    try { escribirFila_(t.hoja, fila, t.cols, datosMov); }
    catch (e) {   // v2.10.9: si no se pudo escribir completo, un movimiento nuevo no queda a medias en la hoja
      if (!m.fila) { try { t.hoja.getRange(fila, 1, 1, t.hoja.getLastColumn()).getFormulas()[0].forEach(function (f, i) { if (!f) t.hoja.getRange(fila, i + 1).clearContent(); }); } catch (e2) { console.log(e2); } }
      throw e;
    }
    if (m.recordarRegla && m.comercio && (m.categoria || m.sobre)) guardarRegla_(m.comercio, m.categoria, m.sobre);
    if (m.fila) { try { fechaSobresDeMov_(m.fila, m.fecha); } catch (e) { console.log(e); } }
    return fila;
  });
}

/** v2.6.0: si cambia la fecha de un movimiento, sus filas en "Movimientos de sobres" toman la fecha nueva. */
function fechaSobresDeMov_(fila, fecha) {
  if (!fecha || !libro_().getSheetByName('Movimientos de sobres')) return 0;
  var t = leerTabla_('Movimientos de sobres', 'Fecha'), c = t.cols['Movimiento'], f = fechaDe_(fecha), n = 0;
  if (!c) return 0;
  t.filas.forEach(function (r) {
    if (String(num_(r['Movimiento'])) !== String(fila)) return;
    var antes = r['Fecha'] instanceof Date ? r['Fecha'].getTime() : null;
    if (antes !== f.getTime()) { t.hoja.getRange(r._fila, t.cols['Fecha']).setValue(f); n++; }
  });
  return n;
}

/** Evita editar/borrar la fila equivocada si la hoja cambió mientras la app estaba abierta. */
function verificarFila_(h, fila, cols, control) {
  if (!control) return;
  var v = h.getRange(fila, 1, 1, h.getLastColumn()).getValues()[0];
  var monto = num_(v[cols['Monto'] - 1]);
  if (Math.abs((monto || 0) - Number(control.monto)) > 0.001) {
    throw new Error('La hoja cambió desde que abriste la app. Tocá Configuración → Recargar datos e intentá de nuevo.');
  }
}

function eliminarMovimiento_(fila, control) {
  return conBloqueo_(function () {
    var t = leerTabla_('Movimientos', 'Fecha');
    verificarFila_(t.hoja, fila, t.cols, control);
    t.hoja.deleteRow(fila);
    // 1.9: las pestañas que apuntan a un movimiento por su número de fila se corren una fila (y se borran las del movimiento eliminado)
    ajustarReferencias_('Movimientos de sobres', 'Fecha', fila);
    ajustarReferencias_('Abonos tasa cero', 'Fecha', fila);
    return true;
  });
}
function ajustarReferencias_(pestaña, clave, fila) {
  if (!libro_().getSheetByName(pestaña)) return;
  var t = leerTabla_(pestaña, clave), c = t.cols['Movimiento'];
  if (!c) return;
  var borrar = [];
  t.filas.forEach(function (r) {
    var m = num_(r['Movimiento']);
    if (!m) return;
    if (m === fila) { if (pestaña === 'Movimientos de sobres' || (pestaña === 'Abonos tasa cero' && tipoAbonoDe_(r['Tipo']) === 'pago')) borrar.push(r._fila); else t.hoja.getRange(r._fila, c).setValue(''); }
    else if (m > fila) t.hoja.getRange(r._fila, c).setValue(m - 1);
  });
  borrar.sort(function (a, b) { return b - a; }).forEach(function (f) { t.hoja.deleteRow(f); });
}

function guardarRegla_(patron, categoria, sobre) {
  var t = leerTabla_('Reglas', 'Si el comercio contiene');
  var p = String(patron).trim().toUpperCase();
  var existente = t.filas.filter(function (r) { return texto_(r['Si el comercio contiene']).toUpperCase() === p; })[0];
  var fila = existente ? existente._fila : primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Si el comercio contiene']);
  escribirFila_(t.hoja, fila, t.cols, { 'Si el comercio contiene': p, 'Categoría': categoria || '', 'Sobre': sobre || '' });
}

// ---------------------------------------------------------------------
// v2.13.0 (#58) · TODO DESDE LA APP: categorías, reglas y tasa cero
// ---------------------------------------------------------------------
/** Escribe una columna entera (desde la fila `desde`); si una lista desplegable rechaza un valor, la pasa a "advertencia" y reintenta. */
function escribirColumna_(h, desde, col, valores) {
  if (!valores.length) return;
  var r = h.getRange(desde, col, valores.length, 1), datos = valores.map(function (v) { return [v]; });
  try { r.setValues(datos); vaciar_(); }
  catch (e) { if (!permitirFueraDeLista_(h, desde, col, 1)) throw e; r.setValues(datos); vaciar_(); }
}
/** Guarda la lista de categorías (pestaña Config, columna "Categorías"). */
function guardarCategorias_(lista) {
  return conBloqueo_(function () {
    var h = hoja_('Config'), cols = columnas_(h, 4), c = cols['Categorías'];
    if (!c) throw new Error('No encontré la columna "Categorías" en la pestaña Config.');
    var limpia = [], vistos = {};
    (lista || []).forEach(function (x) { x = String(x || '').trim(); if (x && !vistos[x.toLowerCase()]) { vistos[x.toLowerCase()] = 1; limpia.push(x); } });
    var largo = Math.max(30, limpia.length, h.getLastRow() - 4);
    var v = []; for (var i = 0; i < largo; i++) v.push(limpia[i] || '');
    escribirColumna_(h, 5, c, v);
    return limpia.length;
  });
}
/** Cambia el nombre de una categoría; con `mover`, también en los movimientos y las reglas. */
function renombrarCategoria_(viejo, nuevo, mover) {
  viejo = String(viejo || '').trim(); nuevo = String(nuevo || '').trim();
  if (!viejo || !nuevo) throw new Error('Falta el nombre.');
  var lista = listaConfig_('Categorías').map(function (x) { return x === viejo ? nuevo : x; });
  if (lista.indexOf(nuevo) < 0) lista.push(nuevo);
  guardarCategorias_(lista);
  var r = { movimientos: 0, reglas: 0 };
  if (!mover) return r;
  return conBloqueo_(function () {
    [['Movimientos', 'Fecha', 'movimientos'], ['Reglas', 'Si el comercio contiene', 'reglas']].forEach(function (x) {
      var t = leerTabla_(x[0], x[1]), c = t.cols['Categoría']; if (!c || !t.filas.length) return;
      var ini = t.filaEnc + 1, n = t.hoja.getLastRow() - t.filaEnc; if (n <= 0) return;
      var vals = t.hoja.getRange(ini, c, n, 1).getValues().map(function (f) { return f[0]; }), cambio = 0;
      vals = vals.map(function (v) { if (String(v).trim() === viejo) { cambio++; return nuevo; } return v; });
      if (cambio) escribirColumna_(t.hoja, ini, c, vals);
      r[x[2]] = cambio;
    });
    return r;
  });
}
/** Edita una regla (comercio → categoría / sobre). ctl = texto anterior, para no tocar otra fila. */
function editarRegla_(fila, regla, ctl) {
  return conBloqueo_(function () {
    var t = leerTabla_('Reglas', 'Si el comercio contiene');
    var ex = t.filas.filter(function (r) { return r._fila === fila; })[0];
    if (!ex || texto_(ex['Si el comercio contiene']).toUpperCase() !== String(ctl || '').toUpperCase()) throw new Error('La regla cambió en la hoja. Recargá los datos.');
    var p = String(regla.patron || '').trim().toUpperCase(); if (!p) throw new Error('Falta el texto del comercio.');
    escribirFila_(t.hoja, fila, t.cols, { 'Si el comercio contiene': p, 'Categoría': regla.categoria || '', 'Sobre': regla.sobre || '' });
    return true;
  });
}
function eliminarRegla_(fila, ctl) {
  return conBloqueo_(function () {
    var t = leerTabla_('Reglas', 'Si el comercio contiene');
    var ex = t.filas.filter(function (r) { return r._fila === fila; })[0];
    if (!ex || texto_(ex['Si el comercio contiene']).toUpperCase() !== String(ctl || '').toUpperCase()) throw new Error('La regla cambió en la hoja. Recargá los datos.');
    t.hoja.deleteRow(fila);
    return true;
  });
}
/** Busca en Movimientos la compra tasa cero y sus cuotas al corte (TC-<fila>-n). */
function movsDeTasaCero_(t, fila, antes, z) {
  var compra = null, cuotas = [], porFecha = null;
  var dia = function (x) { return x && typeof x.getFullYear === 'function' ? Utilities_fecha_(x) : ''; };
  var fz = z ? dia(z['Fecha de compra']) : '', mz = z ? num_(z['Monto total']) : null;
  t.filas.forEach(function (r) {
    var tipo = texto_(r['Tipo']), aut = texto_(r['Autorización']);
    if (tipo === 'Cuota tasa cero' && aut.indexOf('TC-' + fila + '-') === 0) { cuotas.push(r); return; }
    if (tipo !== 'Compra tasa cero' || texto_(r['Cuenta / tarjeta']) !== antes.tarjeta) return;
    if (!compra && texto_(r['Comercio / descripción']) === antes.descripcion) compra = r;
    else if (!porFecha && fz && dia(r['Fecha']) === fz && mz !== null && Math.abs(num_(r['Monto']) - mz) < 0.01) porFecha = r;   // la descripción se cambió antes
  });
  return { compra: compra || porFecha, cuotas: cuotas };
}
function Utilities_fecha_(d) { return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
/**
 * Edita una compra tasa cero. d = { descripcion, tarjeta, monto, meses, primeraCuota (ISO) }; antes = { descripcion, tarjeta }.
 * Si cambia la tarjeta o la descripción, arregla también la compra original, los abonos y las cuotas ya cargadas.
 */
function editarTasaCero_(fila, d, antes) {
  return conBloqueo_(function () {
    var z = leerTabla_('Tasa Cero', 'Descripción'), r = z.filas.filter(function (x) { return x._fila === fila; })[0];
    if (!r || texto_(r['Descripción']) !== antes.descripcion) throw new Error('La compra cambió en la hoja. Recargá los datos.');
    var desc = String(d.descripcion || '').trim() || antes.descripcion, tj = d.tarjeta || antes.tarjeta, zAntes = { 'Fecha de compra': r['Fecha de compra'], 'Monto total': r['Monto total'] };
    escribirFila_(z.hoja, fila, z.cols, { 'Descripción': desc, 'Tarjeta': tj, 'Monto total': Number(d.monto) || num_(r['Monto total']), 'Meses': Number(d.meses) || num_(r['Meses']), 'Primera cuota': d.primeraCuota ? fechaDe_(d.primeraCuota) : r['Primera cuota'] });
    var res = { compra: 0, abonos: 0, cuotas: 0 };
    var t = leerTabla_('Movimientos', 'Fecha'), m = movsDeTasaCero_(t, fila, antes, zAntes);
    if (m.compra) { var cm = { 'Cuenta / tarjeta': tj }; if (Number(d.monto)) cm['Monto'] = Number(d.monto); escribirFila_(t.hoja, m.compra._fila, t.cols, cm); res.compra = 1; }
    m.cuotas.forEach(function (q) {
      var com = texto_(q['Comercio / descripción']).replace(antes.descripcion, desc);
      escribirFila_(t.hoja, q._fila, t.cols, { 'Cuenta / tarjeta': tj, 'Comercio / descripción': com }); res.cuotas++;
    });
    if (libro_().getSheetByName('Abonos tasa cero') && (desc !== antes.descripcion || tj !== antes.tarjeta)) {
      var a = leerTabla_('Abonos tasa cero', 'Fecha');
      a.filas.forEach(function (x) {
        if (texto_(x['Compra']) !== antes.descripcion || (texto_(x['Tarjeta']) && texto_(x['Tarjeta']) !== antes.tarjeta)) return;
        escribirFila_(a.hoja, x._fila, a.cols, { 'Compra': desc, 'Tarjeta': tj }); res.abonos++;
      });
    }
    return res;
  });
}
/** Quita una compra de tasa cero: vuelve a ser un gasto normal de la tarjeta; borra sus abonos y las cuotas cargadas.
 *  La fila de "Tasa Cero" queda marcada "Quitada" (no se borra, para no mover el número de las otras). */
function quitarTasaCero_(fila, antes) {
  return conBloqueo_(function () {
    asegurarColumnas_('Tasa Cero', ['Estado']);
    var z = leerTabla_('Tasa Cero', 'Descripción'), r = z.filas.filter(function (x) { return x._fila === fila; })[0];
    if (!r || texto_(r['Descripción']) !== antes.descripcion) throw new Error('La compra cambió en la hoja. Recargá los datos.');
    escribirFila_(z.hoja, fila, z.cols, { 'Estado': 'Quitada' });
    var res = { compra: 0, abonos: 0, cuotas: 0 };
    var t = leerTabla_('Movimientos', 'Fecha'), m = movsDeTasaCero_(t, fila, antes, r), borrar = [];
    if (m.compra) { escribirFila_(t.hoja, m.compra._fila, t.cols, { 'Tipo': 'Gasto', 'Sobre': '' }); res.compra = 1; }
    m.cuotas.forEach(function (q) { borrar.push(q._fila); });
    borrar.sort(function (a, b) { return b - a; }).forEach(function (f) { t.hoja.deleteRow(f); res.cuotas++; });
    if (libro_().getSheetByName('Abonos tasa cero')) {
      var a = leerTabla_('Abonos tasa cero', 'Fecha'), ba = [];
      a.filas.forEach(function (x) { if (texto_(x['Compra']) === antes.descripcion && (!texto_(x['Tarjeta']) || texto_(x['Tarjeta']) === antes.tarjeta)) ba.push(x._fila); });
      ba.sort(function (p, q) { return q - p; }).forEach(function (f) { a.hoja.deleteRow(f); res.abonos++; });
    }
    return res;
  });
}

/** Convierte una compra en compra a tasa cero y crea su fila en la pestaña Tasa Cero. */
function pasarATasaCero_(fila, control, meses, primeraCuotaIso) {
  return conBloqueo_(function () {
    var t = leerTabla_('Movimientos', 'Fecha');
    verificarFila_(t.hoja, fila, t.cols, control);
    var v = t.hoja.getRange(fila, 1, 1, t.hoja.getLastColumn()).getValues()[0];
    var get = function (n) { return v[t.cols[n] - 1]; };
    escribirFila_(t.hoja, fila, t.cols, { 'Tipo': 'Compra tasa cero', 'Sobre': SOBRE_TASA_CERO });

    var z = leerTabla_('Tasa Cero', 'Descripción');
    var fz = primeraFilaVacia_(z.hoja, z.filaEnc, z.cols['Descripción']);
    escribirFila_(z.hoja, fz, z.cols, {
      'Descripción': texto_(get('Comercio / descripción')) || 'Compra tasa cero',
      'Tarjeta': get('Cuenta / tarjeta'),
      'Fecha de compra': get('Fecha'),
      'Monto total': get('Monto'),
      'Moneda': get('Moneda'),
      'Meses': Number(meses),
      'Primera cuota': fechaDe_(primeraCuotaIso)
    });
    return true;
  });
}

// ---------------------------------------------------------------------
// ABONOS EXTRA A COMPRAS TASA CERO (pestaña "Abonos tasa cero", se crea sola)
// ---------------------------------------------------------------------
var COLS_ABONOS = ['Fecha', 'Compra', 'Tarjeta', 'Monto', 'Moneda', 'De dónde salió', 'Contar como gasto', 'Movimiento', 'Nota', 'Tipo'];
// v2.15 (#62): Tipo = "Baja la cuota" (vacío = igual) · "Adelanto" (el banco mantiene la cuota, queda a favor) · "Pago de cuota" (parte de un pago a la tarjeta)
var TIPOS_ABONO_ = { abono: 'Baja la cuota', adelanto: 'Adelanto', pago: 'Pago de cuota' };
function tipoAbonoDe_(v) { v = texto_(v); return v === 'Adelanto' ? 'adelanto' : v === 'Pago de cuota' ? 'pago' : 'abono'; }

function hojaAbonos_() {
  var libro = libro_();
  var h = libro.getSheetByName('Abonos tasa cero');
  if (h) return h;
  h = libro.insertSheet('Abonos tasa cero');
  h.getRange('A1').setValue('Abonos extra a compras tasa cero').setFontSize(14).setFontWeight('bold');
  h.getRange('A2').setValue('La app los anota sola. "Compra" debe ser igual a la Descripción en la pestaña Tasa Cero. La cuota se recalcula: lo que falta ÷ cuotas que faltan.');
  h.getRange('A2').setFontColor('#666666');
  h.getRange(4, 1, 1, COLS_ABONOS.length).setValues([COLS_ABONOS]).setFontWeight('bold').setBackground('#121417').setFontColor('#F5B82E');
  h.setFrozenRows(4);
  h.getRange('A5:A').setNumberFormat('dd/mm/yyyy');
  h.getRange('D5:D').setNumberFormat('#,##0.00');
  h.setColumnWidth(2, 220); h.setColumnWidth(6, 200); h.setColumnWidth(9, 200);
  return h;
}
function hojaAbonosV215_() { hojaAbonos_(); asegurarColumnas_('Abonos tasa cero', ['Tipo']); }

function leerAbonosTC_() {
  if (!libro_().getSheetByName('Abonos tasa cero')) return [];
  return leerTabla_('Abonos tasa cero', 'Fecha').filas.map(function (r) {
    return {
      fila: r._fila, fecha: iso_(r['Fecha']), compra: texto_(r['Compra']), tarjeta: texto_(r['Tarjeta']),
      monto: num_(r['Monto']) || 0, moneda: texto_(r['Moneda']) || 'CRC', origen: texto_(r['De dónde salió']),
      gasto: texto_(r['Contar como gasto']) !== 'No', movimiento: num_(r['Movimiento']) || null, nota: texto_(r['Nota']),
      tipo: tipoAbonoDe_(r['Tipo'])
    };
  });
}

/** Crea o actualiza un abono. a = { fila?, fecha, compra, tarjeta, monto, moneda, origen, gasto, movimiento, nota, control? } */
function guardarAbonoTC_(a) {
  return conBloqueo_(function () {
    if (!a.compra) throw new Error('Falta la compra.');
    if (!(Number(a.monto) > 0)) throw new Error('El monto debe ser mayor que cero.');
    hojaAbonosV215_();
    var t = leerTabla_('Abonos tasa cero', 'Fecha');
    if (a.fila) verificarFila_(t.hoja, a.fila, t.cols, a.control);
    var tipo = TIPOS_ABONO_[a.tipo] ? a.tipo : 'abono';
    var fila = a.fila || primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Fecha']);
    escribirFila_(t.hoja, fila, t.cols, {
      'Fecha': fechaDe_(a.fecha), 'Compra': a.compra, 'Tarjeta': a.tarjeta || '', 'Monto': Number(a.monto),
      'Moneda': a.moneda || 'CRC', 'De dónde salió': a.origen || '', 'Contar como gasto': a.gasto === false ? 'No' : 'Sí',
      'Movimiento': a.movimiento || '', 'Nota': a.nota || '', 'Tipo': TIPOS_ABONO_[tipo]
    });
    return true;
  });
}

/**
 * v2.15 (#62): cuánto de un pago de tarjeta fue a cada compra tasa cero.
 * r = { movimiento?: fila, autorizacion?: (si el pago es nuevo, para encontrarlo), fecha, moneda, reparto: [{ compra, tarjeta, monto }] }
 * Reemplaza los "Pago de cuota" que ya tenía ese pago.
 */
function guardarRepartoTC_(r) {
  return conBloqueo_(function () {
    var fila = Number(r.movimiento) > 0 ? Number(r.movimiento) : 0;
    var mv = leerTabla_('Movimientos', 'Fecha');
    if (!fila && r.autorizacion) {
      mv.filas.forEach(function (x) { if (texto_(x['Autorización']) === String(r.autorizacion)) fila = x._fila; });
    }
    if (!fila) throw new Error('No encontré el pago de tarjeta.');
    var pago = mv.filas.filter(function (x) { return x._fila === fila; })[0];
    if (!pago || texto_(pago['Tipo']) !== 'Pago de tarjeta') throw new Error('Ese movimiento no es un pago de tarjeta.');
    var lista = (r.reparto || []).filter(function (x) { return x && x.compra && Number(x.monto) > 0; });
    var suma = lista.reduce(function (s, x) { return s + Number(x.monto); }, 0);
    if (suma > (num_(pago['Monto']) || 0) + 0.01) throw new Error('El reparto es mayor que el pago.');
    hojaAbonosV215_();
    var t = leerTabla_('Abonos tasa cero', 'Fecha');
    t.filas.filter(function (x) { return tipoAbonoDe_(x['Tipo']) === 'pago' && num_(x['Movimiento']) === fila; })
      .map(function (x) { return x._fila; }).sort(function (a, b) { return b - a; })
      .forEach(function (f) { t.hoja.deleteRow(f); });
    if (!lista.length) return 0;
    t = leerTabla_('Abonos tasa cero', 'Fecha');
    var f0 = primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Fecha']);
    var fecha = pago['Fecha'] ? new Date(pago['Fecha']) : fechaDe_(r.fecha);
    lista.forEach(function (x, i) {
      escribirFila_(t.hoja, f0 + i, t.cols, {
        'Fecha': fecha, 'Compra': x.compra, 'Tarjeta': x.tarjeta || texto_(pago['Cuenta / tarjeta']), 'Monto': Number(x.monto),
        'Moneda': texto_(pago['Moneda']) || r.moneda || 'CRC', 'De dónde salió': '', 'Contar como gasto': 'No',
        'Movimiento': fila, 'Nota': '', 'Tipo': TIPOS_ABONO_.pago
      });
    });
    return lista.length;
  });
}

function eliminarAbonoTC_(fila, control) {
  return conBloqueo_(function () {
    var t = leerTabla_('Abonos tasa cero', 'Fecha');
    verificarFila_(t.hoja, fila, t.cols, control);
    t.hoja.deleteRow(fila);
    return true;
  });
}

// ---------------------------------------------------------------------
// SOBRES CON SALDO (v1.6): pestaña "Movimientos de sobres" (se crea sola)
// Cada fila suma (+) o resta (−) plata a un sobre. Las de un mismo "Grupo" se hicieron juntas.
// ---------------------------------------------------------------------
var COLS_SOBRES_MOV = ['Fecha', 'Sobre', 'Monto', 'Tipo', 'Movimiento', 'Grupo', 'Nota'];

/** Una sola vez: columnas nuevas en Sobres, fecha de inicio y el sobre "Pago tarjetas". */
function prepararSobresV16_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('V16_LISTO') === 'si') return;
  asegurarColumnas_('Sobres', ['Saldo inicial', 'Ajuste del reparto', 'Meta']);
  if (!p.getProperty('SOBRES_DESDE')) {
    var hoy = new Date(); hoy.setHours(0, 0, 0, 0);
    p.setProperty('SOBRES_DESDE', hoy.toISOString());
  }
  var t = leerTabla_('Sobres', 'Sobre');
  if (!t.filas.some(function (r) { return texto_(r['Sobre']) === SOBRE_TARJETAS; })) {
    var f = primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Sobre']);
    escribirFila_(t.hoja, f, t.cols, { 'Sobre': SOBRE_TARJETAS, 'Moneda': 'CRC', 'Asignado por mes': 0, 'Tipo': 'Ahorro', 'Saldo inicial': 0 });
  }
  p.setProperty('V16_LISTO', 'si');
}

/** 1.6.1: títulos nuevos con formato, nota en "Asignado por mes" y la pestaña de movimientos de sobres. */
function prepararV161_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('V161_LISTO') === 'si') return;
  var cols = asegurarColumnas_('Sobres', ['Saldo inicial', 'Ajuste del reparto', 'Meta']);
  var h = hoja_('Sobres'), f0 = FILA_ENCABEZADO['Sobres'];
  ['Saldo inicial', 'Meta'].forEach(function (c) { h.getRange(f0 + 1, cols[c], 200, 1).setNumberFormat('#,##0.00'); });
  if (cols['Asignado por mes']) h.getRange(f0, cols['Asignado por mes']).setNote('Tu reparto de siempre: la app lo usa para llenar el reparto cuando entra el salario.');
  if (cols['Saldo inicial']) h.getRange(f0, cols['Saldo inicial']).setNote('Lo que tenía cada sobre el día de inicio (Configuración → Saldos de los sobres desde).');
  if (cols['Ajuste del reparto']) h.getRange(f0, cols['Ajuste del reparto']).setNote('Escribí Sí en UN sobre: recibe (o cubre) la diferencia cuando el salario no es el de siempre.');
  hojaSobresMov_();
  p.setProperty('V161_LISTO', 'si');
}

// ---------------------------------------------------------------------
// v1.7: FONDOS DE INVERSIÓN y VIAJES (pestañas que se crean solas)
// ---------------------------------------------------------------------
var COLS_FONDOS = ['Subcuenta', 'Fondo', 'Moneda', 'Saldo', 'Fecha del saldo', 'Meta', 'Intereses (último ajuste)', 'Notas'];
var COLS_VIAJES = ['Viaje', 'Desde', 'Hasta', 'Límite', 'Moneda', 'Tarjetas', 'Subcuenta', 'Activo', 'Avisado'];

function crearPestaña_(nombre, titulo, nota, cols, anchos) {
  var libro = libro_(), h = libro.getSheetByName(nombre);
  if (h) return h;
  h = libro.insertSheet(nombre);
  h.getRange('A1').setValue(titulo).setFontSize(14).setFontWeight('bold');
  h.getRange('A2').setValue(nota).setFontColor('#666666');
  h.getRange(4, 1, 1, cols.length).setValues([cols]).setFontWeight('bold').setBackground('#121417').setFontColor('#F5B82E');
  h.setFrozenRows(4);
  (anchos || []).forEach(function (w, i) { if (w) h.setColumnWidth(i + 1, w); });
  return h;
}

/** v2.8.0: tipos de movimiento nuevos en la lista de Config (sacar / meter de sobres). Se revisa una vez. */
function asegurarTiposV28_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('V28_TIPOS') === 'si') return;
  var cfg = hoja_('Config'), cc = columnas_(cfg, 4);
  if (cc['Tipo de movimiento']) {
    var v = cfg.getRange(5, cc['Tipo de movimiento'], 30, 1).getValues().map(function (r) { return texto_(r[0]); });
    ['Sobre → disponible', 'Disponible → sobre'].forEach(function (tipo) {
      if (v.indexOf(tipo) >= 0) return;
      var i = v.indexOf(''); if (i < 0) return;
      cfg.getRange(5 + i, cc['Tipo de movimiento']).setValue(tipo); v[i] = tipo;
    });
  }
  p.setProperty('V28_TIPOS', 'si');
}

/** Una sola vez: columnas Subcuenta y Viaje en Movimientos, sobre Fondos, tipos nuevos, pestañas Fondos/Viajes y títulos de Sobres. */
function prepararV17_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('V17_LISTO') === 'si') return;
  asegurarColumnas_('Movimientos', ['Subcuenta', 'Viaje']);
  var t = leerTabla_('Sobres', 'Sobre');
  // solo si no tenés ya un sobre de fondos con tu propio nombre (ej. "SOBRE FONDOS DE INVERSION")
  if (!t.filas.some(function (r) { return /fondo|inversi/i.test(texto_(r['Sobre'])); })) {
    var f = primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Sobre']);
    escribirFila_(t.hoja, f, t.cols, { 'Sobre': SOBRE_FONDOS, 'Moneda': 'CRC', 'Asignado por mes': 0, 'Tipo': 'Ahorro', 'Saldo inicial': 0 });
  }
  // tipos nuevos en la lista de Config (para el menú desplegable)
  var cfg = hoja_('Config'), cc = columnas_(cfg, 4);
  if (cc['Tipo de movimiento']) {
    var v = cfg.getRange(5, cc['Tipo de movimiento'], 30, 1).getValues().map(function (r) { return texto_(r[0]); });
    ['Inversión', 'Retiro de fondo'].forEach(function (tipo) {
      if (v.indexOf(tipo) >= 0) return;
      var i = v.indexOf(''); if (i < 0) return;
      cfg.getRange(5 + i, cc['Tipo de movimiento']).setValue(tipo); v[i] = tipo;
    });
  }
  crearPestaña_('Fondos', 'Fondos de inversión', 'Una fila por subcuenta. "Saldo" es el del estado de cuenta a la "Fecha del saldo"; la app suma las inversiones y resta los retiros de después.', COLS_FONDOS, [200, 180, 80, 120, 120, 120, 150, 220]);
  crearPestaña_('Viajes', 'Presupuestos de viaje', 'Los crea la app. "Tarjetas" separadas por coma (puede incluir Efectivo).', COLS_VIAJES, [180, 100, 100, 100, 70, 280, 160, 70, 80]);
  // Sobres: las columnas E–H pasan a mostrar lo mismo que la app (las llena el servidor cada 15 min)
  var s = hoja_('Sobres'), sc = columnas_(s, 4);
  var nuevos = { 'Gastado en el mes': 'Salió este mes', 'Disponible': 'Saldo actual' };
  Object.keys(nuevos).forEach(function (k) { if (sc[k]) s.getRange(4, sc[k]).setValue(nuevos[k]); });
  var res = libro_().getSheetByName('Resumen');
  if (res) {
    var vals = res.getRange(1, 1, Math.min(res.getLastRow(), 80), 8).getValues();
    vals.forEach(function (fila, i) {
      if (texto_(fila[0]) === 'Sobre') {
        fila.forEach(function (x, j) {
          if (texto_(x) === 'Gastado') res.getRange(i + 1, j + 1).setValue('Salió este mes');
          if (texto_(x) === 'Disponible') res.getRange(i + 1, j + 1).setValue('Saldo actual');
        });
      }
    });
  }
  p.setProperty('V17_LISTO', 'si');
}

function leerFondos_() {
  if (!libro_().getSheetByName('Fondos')) return [];
  return leerTabla_('Fondos', 'Subcuenta').filas.map(function (r) {
    return { fila: r._fila, nombre: texto_(r['Subcuenta']), fondo: texto_(r['Fondo']), moneda: texto_(r['Moneda']) || 'CRC',
      saldo: num_(r['Saldo']) || 0, fechaSaldo: iso_(r['Fecha del saldo']), meta: num_(r['Meta']), intereses: num_(r['Intereses (último ajuste)']) || 0, notas: texto_(r['Notas']),
      archivada: texto_(r['Archivada']) === 'Sí' };   // v2.14 (#58g)
  });
}
function leerViajes_() {
  if (!libro_().getSheetByName('Viajes')) return [];
  return leerTabla_('Viajes', 'Viaje').filas.map(function (r) {
    return { fila: r._fila, nombre: texto_(r['Viaje']), desde: iso_(r['Desde']), hasta: iso_(r['Hasta']), limite: num_(r['Límite']) || 0,
      moneda: texto_(r['Moneda']) || 'USD', tarjetas: texto_(r['Tarjetas']).split(',').map(function (x) { return x.trim(); }).filter(String),
      subcuenta: texto_(r['Subcuenta']), activo: texto_(r['Activo']) !== 'No', avisado: num_(r['Avisado']) || 0,
      id: texto_(r['ID']) || ('f' + r._fila), presupuesto: (function () { try { return JSON.parse(texto_(r['Presupuesto']) || '{}'); } catch (e) { return {}; } })() };
  });
}

/** Crea o actualiza una subcuenta. f = { fila?, nombre, fondo, moneda, saldo, meta } */
function guardarFondo_(f) {
  return conBloqueo_(function () {
    prepararV17_();
    var t = leerTabla_('Fondos', 'Subcuenta');
    var nombre = String(f.nombre || '').trim();
    if (!nombre) throw new Error('Falta el nombre de la subcuenta.');
    if (t.filas.some(function (r) { return texto_(r['Subcuenta']) === nombre && r._fila !== f.fila; })) throw new Error('Ya existe la subcuenta "' + nombre + '".');
    var fila = f.fila || primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Subcuenta']);
    var datos = { 'Subcuenta': nombre, 'Fondo': f.fondo || '', 'Moneda': f.moneda || 'CRC', 'Meta': f.meta ? Number(f.meta) : '' };
    if (!f.fila) { datos['Saldo'] = Number(f.saldo) || 0; datos['Fecha del saldo'] = new Date(); }
    escribirFila_(t.hoja, fila, t.cols, datos);
    return fila;
  });
}
/** Actualizar a mano el saldo de una subcuenta (con el estado de cuenta). Lo que difiere del cálculo son los intereses. */
function actualizarSaldoFondo_(fila, saldo, intereses) {
  return conBloqueo_(function () {
    var t = leerTabla_('Fondos', 'Subcuenta');
    escribirFila_(t.hoja, fila, t.cols, { 'Saldo': Number(saldo) || 0, 'Fecha del saldo': new Date(), 'Intereses (último ajuste)': Math.round((Number(intereses) || 0) * 100) / 100 });
    return true;
  });
}
/** Escribe un valor en una columna de un movimiento (Subcuenta, Viaje…), verificando que sea el mismo. */
/** v2.2: "Fecha del saldo" en Cuentas (deuda que sube y baja) y "Para otra persona" / "Cobro" en Movimientos (Me deben). */
function prepararV22_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('V22_LISTO') === 'si') return;
  var c = asegurarColumnas_('Cuentas', ['Fecha del saldo']);
  var h = hoja_('Cuentas');
  if (c['Fecha del saldo']) {
    var t = leerTabla_('Cuentas', 'Nombre (único)');
    h.getRange(t.filaEnc + 1, c['Fecha del saldo'], 300, 1).setNumberFormat('dd/mm/yyyy');
    h.getRange(t.filaEnc, c['Fecha del saldo']).setNote('Fecha a la que corresponde el saldo actual. Desde ese día la app suma las compras de la tarjeta y resta los pagos. Si está vacía, el saldo no se mueve solo.');
  }
  asegurarColumnas_('Movimientos', ['Subcuenta', 'Viaje', 'Para otra persona', 'Cobro']);
  p.setProperty('V22_LISTO', 'si');
}
/** Guarda la deuda real de una tarjeta a una fecha (desde la app: Tarjetas → ↻ Actualizar saldo). */
function actualizarSaldoCuenta_(fila, saldoCRC, saldoUSD, fecha) {
  return conBloqueo_(function () {
    prepararV22_();
    var t = leerTabla_('Cuentas', 'Nombre (único)');
    if (!t.filas.some(function (r) { return r._fila === fila; })) throw new Error('No encontré esa cuenta. Recargá.');
    escribirFila_(t.hoja, fila, t.cols, { 'Saldo actual ₡': Number(saldoCRC) || 0, 'Saldo actual $': Number(saldoUSD) || 0, 'Fecha del saldo': fecha ? fechaDe_(fecha) : new Date() });
    return true;
  });
}
function marcarMovimiento_(fila, columna, valor, control) {
  return conBloqueo_(function () {
    if (['Subcuenta', 'Viaje', 'Para otra persona', 'Cobro', 'Nota', 'Desde'].indexOf(columna) < 0) throw new Error('Columna no permitida.');
    asegurarColumnas_('Movimientos', ['Subcuenta', 'Viaje', 'Para otra persona', 'Cobro'].concat(columna === 'Desde' ? ['Desde'] : []));
    var t = leerTabla_('Movimientos', 'Fecha');
    verificarFila_(t.hoja, fila, t.cols, control);
    t.hoja.getRange(fila, t.cols[columna]).setValue(valor || '');
    return true;
  });
}
/** Crea o actualiza un viaje. v = { fila?, nombre, desde, hasta, limite, moneda, tarjetas:[], subcuenta, activo } */
function guardarViaje_(v) {
  return conBloqueo_(function () {
    prepararV17_();
    var t = leerTabla_('Viajes', 'Viaje');
    if (!String(v.nombre || '').trim()) throw new Error('Falta el nombre del viaje.');
    if (!(Number(v.limite) > 0)) throw new Error('El límite debe ser mayor que cero.');
    var desde = fechaDe_(v.desde), hasta = fechaDe_(v.hasta);
    if (hasta < desde) throw new Error('La fecha final es antes de la inicial.');
    var fila = v.fila || primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Viaje']);
    var datos = { 'Viaje': String(v.nombre).trim(), 'Desde': desde, 'Hasta': hasta, 'Límite': Number(v.limite), 'Moneda': v.moneda || 'USD',
      'Tarjetas': (v.tarjetas || []).join(', '), 'Subcuenta': v.subcuenta || '', 'Activo': v.activo === false ? 'No' : 'Sí' };
    if (v.reiniciarAvisos) datos['Avisado'] = '';
    // v2.10.0: ID fijo (las compras de antes del viaje se ligan con él) y presupuesto por categoría
    if (!t.cols['ID'] || !t.cols['Presupuesto']) { asegurarColumnas_('Viajes', ['ID', 'Presupuesto']); t = leerTabla_('Viajes', 'Viaje'); }
    var idAct = v.fila ? texto_(t.hoja.getRange(v.fila, t.cols['ID']).getValue()) : '';
    if (!idAct) datos['ID'] = v.id || (v.fila ? 'f' + v.fila : 'v' + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36));
    if (v.presupuesto) datos['Presupuesto'] = JSON.stringify(v.presupuesto);
    escribirFila_(t.hoja, fila, t.cols, datos);
    return fila;
  });
}
function eliminarViaje_(fila) {
  return conBloqueo_(function () { var t = leerTabla_('Viajes', 'Viaje'); t.hoja.deleteRow(fila); return true; });
}

/** Cada revisión: avisos de viaje (80 % y 100 %) y columnas "Salió este mes / Saldo actual" de Sobres. */
function tareasDespuesDeLeer_() {
  var D = JSON.parse(obtenerDatos_());
  try { revisarViajes_(D); } catch (e) { console.log('Viajes: ' + e); }
  try { actualizarHojaSobres_(D); } catch (e) { console.log('Sobres: ' + e); }
}
function revisarViajes_(D) {
  var hoy = new Date();
  (D.viajes || []).forEach(function (v) {
    if (!v.activo || !v.desde || !v.hasta) return;
    var fin = new Date(v.hasta); fin.setDate(fin.getDate() + 3);
    if (hoy < new Date(v.desde) || hoy > fin) return;
    var r = Calc.viaje(D, v, hoy);
    var nivel = r.pct >= 1 ? 100 : r.pct >= 0.8 ? 80 : 0;
    if (!nivel || nivel <= (v.avisado || 0)) return;
    var mon = function (n) { return Calc.dinero(n, r.moneda); };
    MailApp.sendEmail(Session.getEffectiveUser().getEmail(), 'Finanzas: ' + v.nombre + ' llegó al ' + Math.round(r.pct * 100) + '%',
      (nivel === 100 ? '⚠️ Llegaste al límite del presupuesto.' : '🔔 Ya usaste el 80 % del presupuesto.') + '\n\n' +
      'Gastado: ' + mon(r.gastado) + ' de ' + mon(r.limite) + '\nDisponible: ' + mon(r.disponible) +
      (r.diasRestantes ? '\nQuedan ' + r.diasRestantes + ' días: podés gastar ' + mon(r.porDia) + ' por día.' : '') + '\n\n— Finanzas');
    var t = leerTabla_('Viajes', 'Viaje');
    t.hoja.getRange(v.fila, t.cols['Avisado']).setValue(nivel);
  });
}
function actualizarHojaSobres_(D) {
  if (!D.sobresDesde) return;
  var r = Calc.saldosSobres(D, new Date(), new Date());
  var t = leerTabla_('Sobres', 'Sobre');
  var cSal = t.cols['Salió este mes'], cSaldo = t.cols['Saldo actual'], cPct = t.cols['% usado'], cEst = t.cols['Estado'];
  if (!cSal || !cSaldo) return;
  t.filas.forEach(function (fila) {
    var s = r.lista.filter(function (x) { return x.fila === fila._fila; })[0];
    if (!s) return;
    var estado = s.saldo < -0.005 ? 'Negativo' : s.meta && s.saldo >= s.meta ? 'Meta lograda' : s.pct >= 1 ? 'Agotado' : s.pct >= 0.85 ? 'Casi vacío' : 'OK';
    t.hoja.getRange(fila._fila, cSal).setValue(Math.round(s.salidas * 100) / 100);
    t.hoja.getRange(fila._fila, cSaldo).setValue(Math.round(s.saldo * 100) / 100);
    if (cPct) t.hoja.getRange(fila._fila, cPct).setValue(Math.round(s.pct * 1000) / 1000);
    if (cEst) t.hoja.getRange(fila._fila, cEst).setValue(estado);
  });
}

function hojaSobresMov_() {
  var libro = libro_();
  var h = libro.getSheetByName('Movimientos de sobres');
  if (h) return h;
  h = libro.insertSheet('Movimientos de sobres');
  h.getRange('A1').setValue('Movimientos de sobres').setFontSize(14).setFontWeight('bold');
  h.getRange('A2').setValue('Lo anota la app: repartos, asignaciones, pagos de tarjeta y movimientos entre sobres. Monto + entra al sobre, − sale.').setFontColor('#666666');
  h.getRange(4, 1, 1, COLS_SOBRES_MOV.length).setValues([COLS_SOBRES_MOV]).setFontWeight('bold').setBackground('#121417').setFontColor('#F5B82E');
  h.setFrozenRows(4);
  h.getRange('A5:A').setNumberFormat('dd/mm/yyyy');
  h.getRange('C5:C').setNumberFormat('#,##0.00');
  h.setColumnWidth(2, 180); h.setColumnWidth(7, 240);
  return h;
}

function leerSobresMov_() {
  if (!libro_().getSheetByName('Movimientos de sobres')) return [];
  return leerTabla_('Movimientos de sobres', 'Fecha').filas.map(function (r) {
    return {
      fila: r._fila, fecha: iso_(r['Fecha']), sobre: texto_(r['Sobre']), monto: num_(r['Monto']) || 0, tipo: texto_(r['Tipo']),
      movimiento: num_(r['Movimiento']) || null, grupo: texto_(r['Grupo']), nota: texto_(r['Nota'])
    };
  });
}

/** Guarda varias filas juntas. lista = [{ fecha, sobre, monto, tipo, movimiento, grupo, nota }] */
function guardarSobresMov_(lista) {
  return conBloqueo_(function () {
    if (!lista || !lista.length) throw new Error('No hay nada que guardar.');
    hojaSobresMov_();
    var t = leerTabla_('Movimientos de sobres', 'Fecha');
    // 1.8.1: no se puede asignar dos veces el mismo movimiento (p. ej. si el teléfono mostraba datos viejos)
    var nuevos = {};
    lista.forEach(function (x) { if (x.movimiento) nuevos[x.movimiento] = (nuevos[x.movimiento] || 0) + Math.abs(Number(x.monto) || 0); });
    var filasMov = Object.keys(nuevos);
    if (filasMov.length) {
      var mt = leerTabla_('Movimientos', 'Fecha');
      filasMov.forEach(function (f) {
        var ya = 0;
        t.filas.forEach(function (r) { if (String(num_(r['Movimiento'])) === String(f)) ya += Math.abs(num_(r['Monto']) || 0); });
        var mov = mt.filas.filter(function (r) { return String(r._fila) === String(f); })[0];
        if (!mov) throw new Error('No encontré ese movimiento en la hoja. Recargá los datos e intentá de nuevo.');
        var monto = Math.abs(num_(mov['Monto']) || 0);
        if (ya + nuevos[f] > monto + 0.01) {
          throw new Error(ya >= monto - 0.01 ? 'Este movimiento ya estaba asignado. Recargá los datos (Configuración → Recargar datos).'
            : 'Solo faltan ' + (Math.round((monto - ya) * 100) / 100) + ' por asignar en ese movimiento. Recargá los datos.');
        }
      });
    }
    var n = primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Fecha']);
    lista.forEach(function (x, i) {
      if (isNaN(Number(x.monto))) throw new Error('Monto inválido.');
      escribirFila_(t.hoja, n + i, t.cols, {
        'Fecha': fechaDe_(x.fecha), 'Sobre': x.sobre || '', 'Monto': Math.round(Number(x.monto) * 100) / 100, 'Tipo': x.tipo || '',
        'Movimiento': x.movimiento || '', 'Grupo': x.grupo || '', 'Nota': x.nota || ''
      });
    });
    return lista.length;
  });
}

/** Deshace una operación completa (todas las filas de un grupo). */
function eliminarGrupoSobres_(grupo) {
  return conBloqueo_(function () {
    if (!grupo) throw new Error('Falta el grupo.');
    var t = leerTabla_('Movimientos de sobres', 'Fecha');
    var filas = t.filas.filter(function (r) { return texto_(r['Grupo']) === String(grupo); }).map(function (r) { return r._fila; });
    filas.sort(function (a, b) { return b - a; }).forEach(function (f) { t.hoja.deleteRow(f); });
    return filas.length;
  });
}

/** "Recordar": regla para que los próximos correos con ese texto vayan solos a ese sobre (no toca la categoría). */
function guardarReglaSobre_(patron, sobre) {
  return conBloqueo_(function () {
    var t = leerTabla_('Reglas', 'Si el comercio contiene');
    var p = String(patron || '').trim().toUpperCase();
    if (!p) throw new Error('Falta el texto de la regla.');
    var ex = t.filas.filter(function (r) { return texto_(r['Si el comercio contiene']).toUpperCase() === p; })[0];
    var fila = ex ? ex._fila : primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Si el comercio contiene']);
    escribirFila_(t.hoja, fila, t.cols, ex ? { 'Sobre': sobre || '' } : { 'Si el comercio contiene': p, 'Sobre': sobre || '' });
    return true;
  });
}

/** Guarda el "reparto de siempre": montos por sobre y cuál es el sobre de ajuste. */
function guardarReparto_(lista, ajuste) {
  return conBloqueo_(function () {
    asegurarColumnas_('Sobres', ['Saldo inicial', 'Ajuste del reparto', 'Meta']);
    var t = leerTabla_('Sobres', 'Sobre');
    var formulas = t.hoja.getRange(1, t.cols['Asignado por mes'], t.hoja.getLastRow(), 1).getFormulas();
    t.filas.forEach(function (r) {
      var nombre = texto_(r['Sobre']);
      var x = (lista || []).filter(function (y) { return y.nombre === nombre; })[0];
      var datos = { 'Ajuste del reparto': nombre === ajuste ? 'Sí' : '' };
      if (x && !formulas[r._fila - 1][0]) datos['Asignado por mes'] = Number(x.monto) || 0;
      escribirFila_(t.hoja, r._fila, t.cols, datos);
    });
    return true;
  });
}

/**
 * Sobres especiales (los nombres los elegís vos en Configuración):
 *  prestamo → recibe solo los pagos del préstamo · fondos → las inversiones de BCR SAFI · tarjetas → "Todo de Pago tarjetas".
 * Si no elegiste, se busca uno por el nombre.
 */
function sobresEspeciales_(nombres) {
  var p = PropertiesService.getScriptProperties();
  function elegir(clave, porDefecto, patron) {
    var v = p.getProperty('SOBRE_ESP_' + clave);
    if (v === '-') return '';                                   // "ninguno" a propósito
    if (v && nombres.indexOf(v) >= 0) return v;
    if (nombres.indexOf(porDefecto) >= 0) return porDefecto;
    for (var i = 0; i < patron.length; i++) {
      var x = nombres.filter(function (n) { return patron[i].test(n); })[0];
      if (x) return x;
    }
    return '';
  }
  return {
    prestamo: elegir('PRESTAMO', SOBRE_PRESTAMO, [/operaci|pr[eé]stamo|hipotec/i, /cuota.*casa/i]),
    fondos: elegir('FONDOS', SOBRE_FONDOS, [/fondo|inversi/i]),
    tarjetas: elegir('TARJETAS', SOBRE_TARJETAS, [/pago.*tarjeta|tarjetas/i]),
    tasaCero: elegir('TASACERO', SOBRE_TASA_CERO, [/tasa ?cero/i])
  };
}
function sobreEspecial_(clave) {
  var t = leerTabla_('Sobres', 'Sobre');
  return sobresEspeciales_(t.filas.map(function (r) { return texto_(r['Sobre']); }))[clave] || '';
}
/** e = { prestamo, fondos, tarjetas } (nombre del sobre, o '' para ninguno) */
function guardarSobresEspeciales_(e) {
  var p = PropertiesService.getScriptProperties();
  ['prestamo', 'fondos', 'tarjetas'].forEach(function (k) {
    if (e[k] === undefined) return;
    p.setProperty('SOBRE_ESP_' + k.toUpperCase(), e[k] ? String(e[k]) : '-');
  });
  return true;
}

function guardarSobresDesde_(iso) {
  PropertiesService.getScriptProperties().setProperty('SOBRES_DESDE', fechaDe_(iso).toISOString());
  return true;
}

/** Crea o actualiza una cuenta/tarjeta. */
function guardarCuenta_(c) {
  return conBloqueo_(function () {
    var t = leerTabla_('Cuentas', 'Nombre (único)');
    var nombre = String(c.nombre || '').trim();
    if (!nombre) throw new Error('Falta el nombre.');
    var repetida = t.filas.some(function (r) { return texto_(r['Nombre (único)']) === nombre && r._fila !== c.fila; });
    if (repetida) throw new Error('Ya existe una cuenta llamada "' + nombre + '".');
    var fila = c.fila || primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Nombre (único)']);
    var datos = {
      'Nombre (único)': nombre, 'Tipo': c.tipo, 'Banco': c.banco || '', 'Moneda principal': c.moneda || 'CRC',
      'Límite ₡': c.limiteCRC === null ? '' : c.limiteCRC, 'Límite $': c.limiteUSD === null ? '' : c.limiteUSD,
      'Día de corte': c.diaCorte || '', 'Día de pago': c.diaPago || '', 'Activa': c.activa === false ? 'No' : 'Sí',
      'Saldo actual ₡': c.saldoCRC === null ? '' : c.saldoCRC, 'Saldo actual $': c.saldoUSD === null ? '' : c.saldoUSD,
      'Notas': c.notas || ''
    };
    if (c.saldoCambio && t.cols['Fecha del saldo']) datos['Fecha del saldo'] = new Date();
    escribirFila_(t.hoja, fila, t.cols, datos);
    // Últimos 4 como texto (para que "0123" no pierda el cero)
    if (t.cols['Últimos 4']) t.hoja.getRange(fila, t.cols['Últimos 4']).setNumberFormat('@').setValue(c.ultimos4 || '');
    return fila;
  });
}

/** Crea un sobre o cambia su monto asignado. */
function guardarSobre_(s) {
  return conBloqueo_(function () {
    var t = leerTabla_('Sobres', 'Sobre');
    var fila = s.fila || primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Sobre']);
    var datos = { 'Asignado por mes': Number(s.asignado) || 0 };
    if (s.saldoInicial !== undefined && s.saldoInicial !== null) datos['Saldo inicial'] = Number(s.saldoInicial) || 0;
    if (s.meta !== undefined) datos['Meta'] = s.meta ? Number(s.meta) : '';
    if (s.fila && s.tipo) datos['Tipo'] = s.tipo;
    if (!s.fila) {
      datos['Sobre'] = String(s.nombre || '').trim();
      datos['Moneda'] = s.moneda || 'CRC';
      datos['Tipo'] = s.tipo || 'Variable';
      if (!datos['Sobre']) throw new Error('Falta el nombre del sobre.');
    }
    escribirFila_(t.hoja, fila, t.cols, datos);
    return fila;
  });
}

/** Registra a mano un pago del préstamo (o lo usa el lector de correos). */
function registrarPago_(p) {
  return conBloqueo_(function () { return registrarPagoPrestamo_(p); });
}

function registrarPagoPrestamo_(p) {
  if ((Number(p.principal) || 0) + (Number(p.intereses) || 0) <= 0) return 'ignorado';   // no es un pago de cuota
  var t = leerTabla_('Préstamo casa', 'Fecha de pago');
  if (p.comprobante) {
    var ya = t.filas.some(function (r) { return texto_(r['N° comprobante']) === String(p.comprobante); });
    if (ya) return 'duplicado';
  }
  var fila = primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Fecha de pago']);
  var datos = {
    'Fecha de pago': fechaDe_(p.fecha),
    'Abono principal': Number(p.principal) || 0,
    'Intereses': Number(p.intereses) || 0,
    'Pólizas': Number(p.polizas) || 0
  };
  // Con el recibo del BCR: la tasa del pago y un ajuste para que el saldo quede igual al del banco
  if (p.tasa && t.cols['Tasa BCR']) datos['Tasa BCR'] = p.tasa;
  if (p.saldoNuevo && t.cols['Ajuste'] && t.cols['Saldo']) {
    var previas = t.filas.filter(function (r) { return r._fila < fila && typeof r['Saldo'] === 'number'; });
    var prev = previas.length ? previas[previas.length - 1]['Saldo'] : null;
    if (prev !== null) {
      var ajuste = Math.round((prev - (Number(p.principal) || 0) - Number(p.saldoNuevo)) * 100) / 100;
      if (Math.abs(ajuste) >= 0.01) datos['Ajuste'] = ajuste;
    }
  }
  escribirFila_(t.hoja, fila, t.cols, datos);
  if (t.cols['N° comprobante']) {
    t.hoja.getRange(fila, t.cols['N° comprobante']).setNumberFormat('@').setValue(String(p.comprobante || ''));
  }
  try { repararFormulasFila_(t.hoja, fila, t.cols, Object.keys(datos).concat(['N° comprobante'])); } catch (e) { console.log(e); }
  return fila;
}

/** v2.5.5: si una columna con fórmula quedó vacía o con #REF! en la fila nueva, copia la fórmula de la fila de arriba (las referencias se ajustan solas). */
function repararFormulasFila_(h, fila, cols, escritas) {
  if (fila <= 1) return 0;
  var n = h.getLastColumn(), prev = h.getRange(fila - 1, 1, 1, n).getFormulas()[0], cur = h.getRange(fila, 1, 1, n).getFormulas()[0];
  var noTocar = {}; escritas.forEach(function (k) { if (cols[k]) noTocar[cols[k]] = 1; });
  var arregladas = 0;
  for (var c = 0; c < n; c++) {
    if (!prev[c] || noTocar[c + 1] || /#REF!/.test(prev[c])) continue;
    if (!cur[c] || /#REF!/.test(cur[c])) { h.getRange(fila - 1, c + 1).copyTo(h.getRange(fila, c + 1)); arregladas++; }
  }
  return arregladas;
}

/** Anota la TBP del día 7. */
function registrarTBP_(fechaIso, tbp) {
  return conBloqueo_(function () {
    var t = leerTabla_('Tasas BCCR', 'Fecha de la TBP (día 7)');
    var f = fechaDe_(fechaIso);
    var existente = t.filas.filter(function (r) {
      var d = r['Fecha de la TBP (día 7)'];
      return d instanceof Date && d.getFullYear() === f.getFullYear() && d.getMonth() === f.getMonth();
    })[0];
    var fila = existente ? existente._fila : primeraFilaVacia_(t.hoja, t.filaEnc, t.cols['Fecha de la TBP (día 7)']);
    escribirFila_(t.hoja, fila, t.cols, {
      'Fecha de la TBP (día 7)': f, 'TBP': Number(tbp), 'Fuente': 'Anotada desde la app'
    });
    return fila;
  });
}

/** Botón "Revisar correos ahora" de la app. */
function revisarCorreosAhora_() {
  return procesarCorreos();
}

// =====================================================================
// v2.14.0 (#61) · AL ABRIR: TODO AL DÍA SOLO
// =====================================================================
/** Lo que la app solo LEE: no cambia la marca de los datos. */
var LECTURAS_ = { obtenerDatos: 1, casaEstado: 1, obtenerAjustes: 1, resumenAvisos: 1, estadoActualizacion: 1, revisarActualizacion: 1, listas: 1, obtenerLista: 1, fotoLista: 1, probarRecordatorio: 1, probarResumenCorreo: 1 };
/** Marca de "última modificación": cambia cada vez que algo se escribe (app, correos, recurrentes o a mano en la hoja). */
function marcarCambio_() { try { PropertiesService.getScriptProperties().setProperty('DATOS_VER', String(Date.now())); } catch (e) { console.log('Marca: ' + e); } }
function marcaDatos_() { return PropertiesService.getScriptProperties().getProperty('DATOS_VER') || '0'; }
/** Se dispara cuando editás la hoja a mano (activador instalado una sola vez). */
function alEditarHoja(e) { marcarCambio_(); }
function asegurarAvisoEdicion_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('TRIG_EDIT') === 'si') return;
  try {
    var ya = ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === 'alEditarHoja'; });
    if (!ya) ScriptApp.newTrigger('alEditarHoja').forSpreadsheet(libro_()).onEdit().create();
    p.setProperty('TRIG_EDIT', 'si');
  } catch (e) { console.log('Aviso de edición de la hoja: ' + e); }
}

/**
 * Al abrir o volver a la app, en UNA sola llamada: ¿hay PIN? + los datos.
 * Si la app ya tiene la marca actual, responde "sin cambios" (rápido, sin leer la hoja).
 */
function abrirApp_(sesion, marca) {
  var acc = estadoAcceso();
  if (acc.pinActivo && !sesionValida_(sesion)) return { acceso: acc, bloqueado: true };
  asegurarAvisoEdicion_();
  var p = PropertiesService.getScriptProperties(), actual = marcaDatos_();
  var r = { acceso: acc, marca: actual, ultimaRevision: p.getProperty('ULTIMA_REVISION') };
  if (marca && String(marca) === actual) { r.sinCambios = true; r.hoy = new Date().toISOString(); }
  else r.datos = obtenerDatos_();
  return r;
}

/**
 * Revisión rápida de los correos al abrir (solo si pasaron más de 2 minutos desde la última).
 * No devuelve datos, solo cuántos movimientos nuevos entraron (sirve aunque la app esté con PIN).
 */
function revisarAlAbrir_(forzar) {
  var p = PropertiesService.getScriptProperties(), ult = Number(p.getProperty('REVISION_APP') || 0);
  if (!forzar && Date.now() - ult < 2 * 60 * 1000) return { saltada: true, marca: marcaDatos_() };
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(3000)) return { ocupado: true, marca: marcaDatos_() };   // ya hay otra revisión corriendo
  try {
    var inicio = Date.now();
    p.setProperty('REVISION_APP', String(inicio));
    var r = leerCorreos_(true);
    if (r.compras + r.pagos > 0) { try { tareasDespuesDeLeer_(); } catch (e) { console.log('Después de leer: ' + e); } }
    p.setProperty('ULTIMA_REVISION', String(inicio - 10 * 60 * 1000));
    if (r.compras + r.pagos + r.revisar > 0) marcarCambio_();
    return { compras: r.compras, pagos: r.pagos, revisar: r.revisar, marca: marcaDatos_() };
  } finally { lock.releaseLock(); }
}

// =====================================================================
// v2.14.0 (#58d) · BANCOS QUE SE LEEN (pestaña Config, filas 5 a 14)
// =====================================================================
var FILA_BANCO_1_ = 5, FILA_BANCO_N_ = 14;   // la fila 15 es el tipo de cambio
function correoValido_(c) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(c || '').trim()); }
function bancosConfig_() {
  var h = hoja_('Config'), cols = columnas_(h, 4);
  var cb = cols['Banco'], cc = cols['Correo de notificaciones'], ce = cols['Estado'];
  if (!cb || !cc || !ce) return [];
  var n = FILA_BANCO_N_ - FILA_BANCO_1_ + 1, v = h.getRange(FILA_BANCO_1_, 1, n, Math.max(cb, cc, ce)).getValues(), out = [];
  v.forEach(function (r, i) {
    var nom = texto_(r[cb - 1]), cor = texto_(r[cc - 1]), est = texto_(r[ce - 1]);
    if (!nom && !cor) return;
    var ok = correoValido_(cor) && cor.indexOf('PENDIENTE') < 0;
    out.push({ fila: FILA_BANCO_1_ + i, nombre: nom, correo: ok ? cor : '', estado: est, activo: est === 'Activo' && ok, pendiente: !ok });
  });
  return out;
}
/** Agrega o cambia un banco. b = { fila?, nombre, correo, activo } */
function guardarBanco_(b) {
  return conBloqueo_(function () {
    var nom = String(b.nombre || '').trim(), cor = String(b.correo || '').trim();
    if (!nom) throw new Error('Falta el nombre del banco.');
    if (!correoValido_(cor)) throw new Error('El correo no parece válido (ej. alertas@banco.com).');
    var h = hoja_('Config'), cols = columnas_(h, 4), lista = bancosConfig_();
    if (lista.some(function (x) { return x.correo.toLowerCase() === cor.toLowerCase() && x.fila !== b.fila; })) throw new Error('Ese correo ya está en la lista.');
    var fila = b.fila;
    if (fila && (fila < FILA_BANCO_1_ || fila > FILA_BANCO_N_)) throw new Error('Fila de banco no válida.');
    if (!fila) {
      var ocupadas = {}; lista.forEach(function (x) { ocupadas[x.fila] = 1; });
      for (var f = FILA_BANCO_1_; f <= FILA_BANCO_N_; f++) if (!ocupadas[f]) { fila = f; break; }
      if (!fila) throw new Error('Ya no hay espacio para más bancos (son 10). Quitá uno que no uses.');
    }
    escribirFila_(h, fila, cols, { 'Banco': nom, 'Correo de notificaciones': cor, 'Estado': b.activo === false ? 'Inactivo' : 'Activo' });
    return bancosConfig_();
  });
}
function quitarBanco_(fila, ctl) {
  return conBloqueo_(function () {
    var h = hoja_('Config'), cols = columnas_(h, 4), x = bancosConfig_().filter(function (b) { return b.fila === fila; })[0];
    if (!x) throw new Error('No encontré ese banco (¿se cambió la hoja?). Recargá los datos.');
    if (ctl && ctl.nombre && ctl.nombre !== x.nombre) throw new Error('La fila cambió en la hoja. Recargá los datos.');
    escribirFila_(h, fila, cols, { 'Banco': '', 'Correo de notificaciones': '', 'Estado': '' });
    return bancosConfig_();
  });
}

// =====================================================================
// v2.14.0 (#58e) · RECURRENTES DESDE LA APP
// =====================================================================
function leerRecurrentes_() {
  if (!libro_().getSheetByName('Recurrentes')) return [];
  return leerTabla_('Recurrentes', 'Descripción').filas.map(function (r) {
    return { fila: r._fila, descripcion: texto_(r['Descripción']), monto: num_(r['Monto']) || 0, moneda: texto_(r['Moneda']) || 'CRC',
      cuenta: texto_(r['Tarjeta / cuenta']), dia: num_(r['Día del mes']) || 1, categoria: texto_(r['Categoría']), sobre: texto_(r['Sobre']),
      activo: texto_(r['Activo']) !== 'No' };
  });
}
/** r = { fila?, descripcion, monto, moneda, cuenta, dia, categoria, sobre, activo } · las nuevas van al final (la fila es parte de su clave). */
function guardarRecurrente_(r) {
  return conBloqueo_(function () {
    var t = leerTabla_('Recurrentes', 'Descripción'), d = String(r.descripcion || '').trim();
    if (!d) throw new Error('Falta la descripción.');
    var dia = Math.round(Number(r.dia) || 0); if (dia < 1 || dia > 31) throw new Error('El día del mes va de 1 a 31.');
    if (!(Number(r.monto) > 0)) throw new Error('Falta el monto.');
    var fila = r.fila;
    if (fila) { if (!t.filas.some(function (x) { return x._fila === fila; })) throw new Error('No encontré ese recurrente. Recargá los datos.'); }
    else fila = Math.max(t.hoja.getLastRow() + 1, t.filaEnc + 1);
    escribirFila_(t.hoja, fila, t.cols, { 'Descripción': d, 'Monto': Number(r.monto), 'Moneda': r.moneda === 'USD' ? 'USD' : 'CRC', 'Tarjeta / cuenta': r.cuenta || '',
      'Día del mes': dia, 'Categoría': r.categoria || '', 'Sobre': r.sobre || '', 'Activo': r.activo === false ? 'No' : 'Sí' });
    return fila;
  });
}
/** Borra un recurrente: la fila queda vacía (no se elimina, para que las claves de los meses anteriores no se corran). */
function eliminarRecurrente_(fila, ctl) {
  return conBloqueo_(function () {
    var t = leerTabla_('Recurrentes', 'Descripción'), x = t.filas.filter(function (r) { return r._fila === fila; })[0];
    if (!x) throw new Error('No encontré ese recurrente. Recargá los datos.');
    if (ctl && ctl.descripcion && ctl.descripcion !== texto_(x['Descripción'])) throw new Error('La fila cambió en la hoja. Recargá los datos.');
    var o = {}; Object.keys(t.cols).forEach(function (k) { o[k] = ''; });
    escribirFila_(t.hoja, fila, t.cols, o);
    return true;
  });
}

// =====================================================================
// v2.14.0 (#58f, #58g) · ARCHIVAR SOBRES Y SUBCUENTAS (solo con saldo en 0, eso lo revisa la app)
// =====================================================================
function archivarSobre_(fila, si) {
  return conBloqueo_(function () {
    asegurarColumnas_('Sobres', ['Archivado']);
    var t = leerTabla_('Sobres', 'Sobre');
    if (!t.filas.some(function (r) { return r._fila === fila; })) throw new Error('No encontré ese sobre. Recargá los datos.');
    var o = { 'Archivado': si ? 'Sí' : '' };
    if (si) o['Asignado por mes'] = 0;   // archivado: ya no recibe plata en el reparto
    escribirFila_(t.hoja, fila, t.cols, o);
    return true;
  });
}
function archivarFondo_(fila, si) {
  return conBloqueo_(function () {
    asegurarColumnas_('Fondos', ['Archivada']);
    var t = leerTabla_('Fondos', 'Subcuenta');
    if (!t.filas.some(function (r) { return r._fila === fila; })) throw new Error('No encontré esa subcuenta. Recargá los datos.');
    escribirFila_(t.hoja, fila, t.cols, { 'Archivada': si ? 'Sí' : '' });
    return true;
  });
}

// =====================================================================
// v2.14.0 (#59) · TIPO DE CAMBIO DE REFERENCIA (Config B15)
// =====================================================================
function guardarTipoCambio_(n) {
  n = Math.round((Number(n) || 0) * 100) / 100;
  if (n < 100 || n > 2000) throw new Error('El tipo de cambio parece raro (₡' + n + '). Revisalo.');
  return conBloqueo_(function () {
    var c = hoja_('Config').getRange(15, 2);   // B15
    if (c.getFormulas()[0][0]) throw new Error('El tipo de cambio de la hoja es una fórmula; cambialo en la pestaña Config.');
    c.setValue(n); vaciar_();
    return n;
  });
}
