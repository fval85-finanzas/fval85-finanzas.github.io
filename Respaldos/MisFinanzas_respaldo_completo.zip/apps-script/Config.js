/**
 * Config.js — Ajustes del programa.
 *
 * Los correos de los BANCOS (compras con tarjeta) se configuran en la
 * pestaña "Config" de la hoja, no aquí: así los cambiás sin tocar código.
 */

/** Comprobantes de pago del préstamo de casa (llegan con un .txt adjunto). */
var PRESTAMO_CORREO = {
  remitente: 'mensajero@bancobcr.com',
  // Si ese remitente manda otros avisos, poné aquí parte del asunto, ej. 'Comprobante de pago'.
  asunto: ''
};

/** Avisos de SINPE Móvil del BCR (mismo remitente que el préstamo; se distinguen por el asunto). */
var SINPE_CORREO = { remitente: 'mensajero@bancobcr.com', asunto: 'SINPEMOVIL' };

/** La primera vez, cuántos días hacia atrás revisar el correo. */
var DIAS_ATRAS = 30;

/** Etiquetas que se ponen en Gmail para que veas qué se leyó. */
var ETIQUETA_PROCESADO = 'Finanzas/Procesado';
var ETIQUETA_REVISAR = 'Finanzas/Revisar';

/** Sobres especiales que se calculan solos. */
var SOBRE_PRESTAMO = 'Cuota casa';
var SOBRE_TASA_CERO = 'Cuotas tasa cero';
var SOBRE_TARJETAS = 'Pago tarjetas';
var SOBRE_FONDOS = 'Fondos';

/** BCR SAFI (fondos de inversión): se leen las "Solicitud de inversión / de retiro"; las confirmaciones con PDF se ignoran. */
var FONDOS_CORREO = 'mensajerobcrsafi@bancobcr.com';
// v2.10.6: BAC Credomatic (se lee aunque no esté en Config: ahí llegan, reenviadas, las compras de tarjetas de la familia)
var BAC_CORREO = 'NotificacionBAC@baccredomatic.cr';

