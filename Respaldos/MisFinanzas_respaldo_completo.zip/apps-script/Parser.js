/**
 * Parser.js — Extrae los datos de un correo de notificación bancaria.
 *
 * Funciones puras (sin Gmail ni internet) para poder probarlas en la computadora.
 * Si un banco usa un formato distinto, se agrega un patrón nuevo en las listas.
 */

/** Convierte "12,345.67" / "12.345,67" / "12345" / "1 234,50" en número. */
function convertirNumero(texto) {
  var t = String(texto).replace(/\s/g, '');
  var ultimaComa = t.lastIndexOf(',');
  var ultimoPunto = t.lastIndexOf('.');
  var sepDecimal = null;

  if (ultimaComa > -1 && ultimoPunto > -1) {
    sepDecimal = ultimaComa > ultimoPunto ? ',' : '.';
  } else if (ultimaComa > -1 || ultimoPunto > -1) {
    var sep = ultimaComa > -1 ? ',' : '.';
    var decimales = t.length - t.lastIndexOf(sep) - 1;
    var apariciones = t.split(sep).length - 1;
    // "12,50" o "12.5" → decimal; "12,345" o "1.234.567" → miles
    if (apariciones === 1 && decimales !== 3) sepDecimal = sep;
  }

  if (sepDecimal === ',') t = t.replace(/\./g, '').replace(',', '.');
  else if (sepDecimal === '.') t = t.replace(/,/g, '');
  else t = t.replace(/[.,]/g, '');

  var n = parseFloat(t);
  return isNaN(n) ? null : n;
}

/** Identifica la moneda a partir de un símbolo o palabra. */
function identificarMoneda(texto) {
  var t = String(texto).toUpperCase();
  if (/USD|US\$|\$|D[OÓ]LL?AR|US\s+DOLL?AR/.test(t)) return 'USD';   // v2.9.0: el BCR escribe "US DOLLAR"
  if (/CRC|₡|¢|COL[OÓ]N|COLONES/.test(t)) return 'CRC';
  return null;
}

// v2.5.6: "32978.54" (sin separador de miles) se leía como 329: el primer caso ahora exige al menos un grupo de miles
var NUM = '(\\d{1,3}(?:[.,\\s]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?)';
var MON = '(USD|US\\$|CRC|\\$|₡|¢|COLONES|D[OÓ]LARES)';

/** Busca el monto y la moneda. Devuelve { monto, moneda } o null. */
function extraerMonto(texto) {
  var patrones = [
    // "Monto: CRC 12,345.67" / "Monto: $25.00"
    new RegExp('(?:monto|importe|valor|total)[^\\n\\d$₡¢A-Z]{0,20}' + MON + '\\s*' + NUM, 'i'),
    // "Monto: 12,345.67 CRC"
    new RegExp('(?:monto|importe|valor|total)[^\\n\\d$₡¢]{0,20}' + NUM + '\\s*' + MON, 'i'),
    // en cualquier parte: "USD 25.00" / "₡12.345,00"
    new RegExp(MON + '\\s*' + NUM, 'i'),
    // en cualquier parte: "25.00 USD"
    new RegExp(NUM + '\\s*' + MON, 'i')
  ];
  for (var i = 0; i < patrones.length; i++) {
    var m = texto.match(patrones[i]);
    if (!m) continue;
    var a = m[1], b = m[2];
    var esMonedaPrimero = identificarMoneda(a) !== null && /^[^\d]/.test(a);
    var moneda = identificarMoneda(esMonedaPrimero ? a : b);
    var monto = convertirNumero(esMonedaPrimero ? b : a);
    if (moneda && monto !== null && monto > 0) return { monto: monto, moneda: moneda };
  }
  return null;
}

/** Lee el valor que sigue a una etiqueta, ej. "Comercio: AUTOMERCADO" */
function valorDeEtiqueta(texto, etiquetas) {
  for (var i = 0; i < etiquetas.length; i++) {
    var re = new RegExp('(?:^|\\n|\\s)' + etiquetas[i] + '\\s*[:\\-]?\\s*([^\\n]+)', 'i');
    var m = texto.match(re);
    if (m) {
      var v = m[1].trim().replace(/\s{2,}/g, ' ');
      if (v) return v;
    }
  }
  return null;
}

function extraerComercio(texto) {
  var v = valorDeEtiqueta(texto, [
    'comercio', 'establecimiento', 'nombre del comercio', 'lugar de compra', 'merchant'
  ]);
  if (!v) {
    var m = texto.match(/(?:[Cc]ompra|[Tt]ransacci[oó]n|[Cc]argo)\s+(?:[Rr]ealizad[ao]\s+)?[Ee]n\s+([A-Z0-9][A-Z0-9 &*.\-\/]{2,40})/);
    if (m) v = m[1];
  }
  return v ? v.replace(/\s+(el|por|con|monto)\b.*$/i, '').trim().slice(0, 80) : null;
}

function extraerLugar(texto) {
  return valorDeEtiqueta(texto, ['ciudad y pa[ií]s', 'ciudad', 'pa[ií]s', 'ubicaci[oó]n']);
}

function extraerUltimos4(texto) {
  var m = texto.match(/(?:terminad[ao]\s+en|finalizad[ao]\s+en|[*xX•]{2,}[\s-]*|tarjeta[^\n\d]{0,30})(\d{4})\b/i);
  return m ? m[1] : null;
}

function extraerAutorizacion(texto) {
  var m = texto.match(/(?:autorizaci[oó]n|c[oó]digo de autorizaci[oó]n|referencia|n[uú]mero de referencia|comprobante)\s*(?:n[o°º.]*)?\s*[:#\-]?\s*([A-Z0-9]{4,20})/i);
  return m ? m[1] : null;
}

var MESES = {
  ene: 0, jan: 0, feb: 1, mar: 2, abr: 3, apr: 3, may: 4, jun: 5, jul: 6,
  ago: 7, aug: 7, sep: 8, set: 8, oct: 9, nov: 10, dic: 11, dec: 11
};

/** Busca la fecha de la transacción. Si no la encuentra, usa la del correo. */
function extraerFecha(texto, fechaCorreo) {
  var hora = texto.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([ap]\.?\s?m\.?)?/i);
  var h = 0, min = 0;
  if (hora) {
    h = parseInt(hora[1], 10); min = parseInt(hora[2], 10);
    var ampm = hora[4] ? hora[4].toLowerCase().replace(/[.\s]/g, '') : '';
    if (ampm === 'pm' && h < 12) h += 12;
    if (ampm === 'am' && h === 12) h = 0;
  }

  // 27/10/2026 o 27-10-26
  var m = texto.match(/\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\b/);
  if (m) {
    var anio = parseInt(m[3], 10); if (anio < 100) anio += 2000;
    return crearFechaCR(anio, parseInt(m[2], 10) - 1, parseInt(m[1], 10), h, min);
  }
  // 2026-10-27
  m = texto.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (m) return crearFechaCR(+m[1], +m[2] - 1, +m[3], h, min);
  // 27 oct 2026 / 27 de octubre de 2026
  m = texto.match(/\b(\d{1,2})\s+(?:de\s+)?([a-záéíóú]{3})[a-záéíóú]*\.?\s+(?:de\s+)?(\d{4})\b/i);
  if (m && MESES[m[2].toLowerCase()] !== undefined) {
    return crearFechaCR(+m[3], MESES[m[2].toLowerCase()], +m[1], h, min);
  }
  // Oct 27, 2026
  m = texto.match(/\b([a-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\b/i);
  if (m && MESES[m[1].toLowerCase()] !== undefined) {
    return crearFechaCR(+m[3], MESES[m[1].toLowerCase()], +m[2], h, min);
  }
  return fechaCorreo || new Date();
}

/** Crea una fecha en hora de Costa Rica (UTC-6, sin horario de verano). */
function crearFechaCR(anio, mes, dia, h, min) {
  return new Date(Date.UTC(anio, mes, dia, h + 6, min));
}

/** Gasto o ingreso, según palabras del correo. */
function extraerTipo(texto) {
  return /(dep[oó]sito|recibi[oó]|recibiste|acreditad|abono|transferencia recibida|devoluci[oó]n|reembolso)/i.test(texto)
    ? 'ingreso' : 'gasto';
}

/**
 * Función principal: recibe el texto del correo y devuelve la transacción,
 * o null si el correo no parece una transacción.
 */
function parsearCorreo(texto, fechaCorreo, banco) {
  var limpio = String(texto).replace(/\r/g, '').replace(/ /g, ' ');
  var monto = extraerMonto(limpio);
  if (!monto) return null;
  // v2.5.8: si el texto trae una fecha futura (vencimiento) o un día sin hora igual al del correo, vale la fecha del correo
  var f = extraerFecha(limpio, fechaCorreo);
  if (fechaCorreo) {
    var fc = new Date(fechaCorreo);
    if (f - fc > 86400000 || (f.getUTCHours() === 6 && f.getUTCMinutes() === 0 && Math.abs(f - fc) < 86400000)) f = fc;
  }
  return {
    fecha: f.toISOString(),
    comercio: extraerComercio(limpio),
    lugar: extraerLugar(limpio),
    monto: monto.monto,
    moneda: monto.moneda,
    tipo: extraerTipo(limpio),
    ultimos4: extraerUltimos4(limpio),
    autorizacion: extraerAutorizacion(limpio),
    banco: banco || null,
    origen: 'correo'
  };
}


// =====================================================================
// FORMATOS REALES DE LOS BANCOS (v1.5)
// =====================================================================

/** Quita etiquetas HTML y traduce los &códigos; más comunes. */
function textoDeHtml_(h) {
  var ent = { nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', aacute: 'á', eacute: 'é', iacute: 'í', oacute: 'ó', uacute: 'ú',
    Aacute: 'Á', Eacute: 'É', Iacute: 'Í', Oacute: 'Ó', Uacute: 'Ú', ntilde: 'ñ', Ntilde: 'Ñ', uuml: 'ü', iexcl: '¡', iquest: '¿', colon: '₡' };
  return String(h || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ' ')
    .replace(/&#(\d+);/g, function (m, n) { return String.fromCharCode(+n); })
    .replace(/&#x([0-9a-f]+);/gi, function (m, n) { return String.fromCharCode(parseInt(n, 16)); })
    .replace(/&([a-zA-Z]+);?/g, function (m, n) { return ent[n] !== undefined ? ent[n] : m; });
}
/** Filas de las tablas de un correo HTML: [[celda, celda, …], …] */
function filasTablaHtml_(html) {
  var filas = [], mf, re = /<tr[\s\S]*?<\/tr>/gi;
  while ((mf = re.exec(String(html || ''))) !== null) {
    var celdas = [], mc, rc = /<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi;
    while ((mc = rc.exec(mf[0])) !== null) celdas.push(textoDeHtml_(mc[1]).replace(/\s+/g, ' ').trim());
    if (celdas.length) filas.push(celdas);
  }
  return filas;
}
function sinTildes_(t) { return String(t).normalize ? String(t).normalize('NFD').replace(/[̀-ͯ]/g, '') : String(t); }
function nombrePropio_(t) {
  return String(t || '').toLowerCase().replace(/(^|[\s(\-\/])([a-záéíóúñ])/g, function (m, a, b) { return a + b.toUpperCase(); });
}

// Lugares de Costa Rica que suelen venir pegados al final del nombre del comercio
var LUGARES_CR = ['SAN JOSE', 'ALAJUELA', 'HEREDIA', 'CARTAGO', 'PUNTARENAS', 'LIMON', 'LIBERIA', 'ESCAZU', 'SANTA ANA', 'CURRIDABAT',
  'MONTES DE OCA', 'SAN PEDRO', 'DESAMPARADOS', 'TIBAS', 'MORAVIA', 'GOICOECHEA', 'GUADALUPE', 'BELEN', 'SANTO DOMINGO', 'GRECIA',
  'NARANJO', 'PALMARES', 'SAN RAMON', 'ATENAS', 'POAS', 'SARCHI', 'ZARCERO', 'SAN CARLOS', 'CIUDAD QUESADA', 'NICOYA', 'SANTA CRUZ',
  'TILARAN', 'CANAS', 'TURRIALBA', 'PARAISO', 'LA UNION', 'TRES RIOS', 'OREAMUNO', 'PEREZ ZELEDON', 'SAN ISIDRO', 'QUEPOS', 'JACO',
  'GARABITO', 'OROTINA', 'SAN RAFAEL', 'FLORES', 'BARVA', 'SAN PABLO', 'ASERRI', 'ALAJUELITA', 'COLON', 'CIUDAD COLON', 'MORA',
  'PURISCAL', 'UPALA', 'GUACIMO', 'POCOCI', 'GUAPILES', 'SIQUIRRES', 'HATILLO', 'PAVAS', 'ROHRMOSER', 'LINDORA', 'URUCA', 'ZAPOTE',
  'SABANILLA', 'VALVERDE VEGA', 'POAS', 'SAN ANTONIO', 'BELEN HEREDIA', 'SAN FRANCISCO', 'SANTA BARBARA', 'SAN JUAN', 'COYOL', 'TACARES'];
var PAISES = { CRI: 'Costa Rica', CR: 'Costa Rica', USA: 'Estados Unidos', US: 'Estados Unidos', PAN: 'Panamá', MEX: 'México', ESP: 'España',
  NIC: 'Nicaragua', COL: 'Colombia', GBR: 'Reino Unido', IRL: 'Irlanda', NLD: 'Países Bajos', CAN: 'Canadá', CHN: 'China', SGP: 'Singapur', LUX: 'Luxemburgo' };

/** "TIENDA DE MASCOTAS SAN ALAJUELA CRI" → { comercio: 'TIENDA DE MASCOTAS SAN', lugar: 'Alajuela' } */
function separarComercio_(t) {
  var s = String(t || '').trim();
  var pais = null, m = s.match(/\s([A-Z]{2,3})$/);
  if (m && PAISES[m[1]]) { pais = m[1]; s = s.slice(0, -m[0].length).trim(); }
  var partes = s.split(/\s{2,}/);
  var comercio = s.replace(/\s+/g, ' '), ciudad = null;
  if (partes.length > 1) { ciudad = partes.pop(); comercio = partes.join(' ').replace(/\s+/g, ' '); }
  else {
    var plano = sinTildes_(comercio).toUpperCase();
    LUGARES_CR.slice().sort(function (a, b) { return b.length - a.length; }).some(function (l) {
      if (plano.length > l.length + 2 && plano.slice(-l.length - 1) === ' ' + l) { ciudad = comercio.slice(-l.length); comercio = comercio.slice(0, -l.length - 1).trim(); return true; }
      return false;
    });
  }
  var lugar = ciudad ? nombrePropio_(ciudad) : '';
  if (pais && pais !== 'CRI' && pais !== 'CR') lugar = (lugar ? lugar + ', ' : '') + PAISES[pais];
  return { comercio: comercio, lugar: lugar };
}

/** BCR Tarjetas: tabla "Detalle de Transacciones" (puede traer varias). Devuelve [tx] (vacío si todas rechazadas) o null. */
function parsearBCRTabla(texto, html) {
  if (!/Detalle de Transacciones/i.test(texto + ' ' + textoDeHtml_(html)) && !/Autorizaci/i.test(texto)) return null;
  var ultimos4 = ((texto + ' ' + textoDeHtml_(html)).match(/\*{4}[-\s]*\*{4}[-\s]*\*{4}[-\s]*(\d{4})/) || [])[1] || extraerUltimos4(texto);
  var crudas = [];
  var filas = filasTablaHtml_(html), enc = null;
  filas.forEach(function (f) {
    var u = sinTildes_(f.join('|')).toUpperCase();
    if (!enc && /AUTORIZACION/.test(u) && /MONTO/.test(u)) {
      enc = {}; f.forEach(function (c, i) { enc[sinTildes_(c).toUpperCase().replace(/[^A-Z]/g, '')] = i; }); return;
    }
    if (enc && f.length >= 5 && /\d{1,2}\/\d{1,2}\/\d{4}/.test(f[enc.FECHA !== undefined ? enc.FECHA : 0])) {
      var g = function (k, d) { return enc[k] !== undefined ? f[enc[k]] : d; };
      crudas.push({ fecha: g('FECHA', ''), aut: g('AUTORIZACION', ''), ref: g('NOREFERENCIA', ''), monto: g('MONTO', ''), moneda: g('MONEDA', ''), comercio: g('COMERCIO', ''), estado: g('ESTADO', 'Aprobada') });
    }
  });
  if (!crudas.length) {   // sin HTML: se lee del texto plano
    var t = String(texto).replace(/[ \t ]+/g, ' ');
    var re = /(\d{1,2}\/\d{1,2}\/\d{4})\s+(\d{1,2}:\d{2}(?::\d{2})?)\s+(\S+)\s+(\S+)\s+([\d.,]+)\s+(COLON(?:ES)? COSTA RICA|COLONES|COLON|D[OÓ]LAR(?:ES)? (?:ESTADOUNIDENSES?|AMERICANOS?|USA|EEUU)|D[OÓ]LAR(?:ES)?|US DOLLARS?|DOLLARS?|USD|CRC)\s+([\s\S]+?)\s+(Aprobad[ao]|Rechazad[ao]|Declinad[ao]|Reversad[ao]|Anulad[ao])\b/gi, m;
    while ((m = re.exec(t)) !== null) crudas.push({ fecha: m[1] + ' ' + m[2], aut: m[3], ref: m[4], monto: m[5], moneda: m[6], comercio: m[7].replace(/\s*\n\s*/g, ' '), estado: m[8] });
  }
  if (!crudas.length) return null;
  return crudas.filter(function (c) { return /aprobad/i.test(c.estado || 'Aprobada'); }).map(function (c) {
    var f = c.fecha.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/);
    var sep = separarComercio_(c.comercio);
    return {
      fecha: crearFechaCR(+f[3], +f[2] - 1, +f[1], +(f[4] || 0), +(f[5] || 0)).toISOString(),
      comercio: sep.comercio, lugar: sep.lugar, monto: convertirNumero(c.monto), moneda: identificarMoneda(c.moneda) || 'CRC',
      tipo: 'gasto', ultimos4: ultimos4, autorizacion: String(c.aut || c.ref).trim(), banco: 'BCR', origen: 'correo'
    };
  });
}

/** Davibank: compra con tarjeta (texto corrido). */
function parsearDavibankCompra(texto) {
  var t = String(texto).replace(/&nbsp;?/g, ' ').replace(/\s+/g, ' ');
  var m = t.match(/transacci[oó]n realizada en (.+?),\s*el d[ií]a (\d{1,2})\/(\d{1,2})\/(\d{4}) a las (\d{1,2}):(\d{2})\s*([AP]\.?\s?M\.?)?.*?terminada en (\d{4}).*?autorizaci[oó]n\s+(\w+).*?por\s+(USD|CRC|US\$|\$|₡|¢|COLONES|D[OÓ]LARES)\s*([\d.,]*\d),?\s*fue\s+(aprobada|rechazada|declinada|denegada)/i);
  if (!m) return null;
  if (!/aprobada/i.test(m[12])) return [];
  var h = +m[5]; var ap = (m[7] || '').toUpperCase().replace(/[.\s]/g, '');
  if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0;
  var lugar = '', comercio = m[1].trim();
  var l = comercio.match(/^(.*\S)\s+([A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s(?:de\s)?[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)*)$/);
  if (l) { comercio = l[1]; lugar = l[2]; }
  return [{
    fecha: crearFechaCR(+m[4], +m[3] - 1, +m[2], h, +m[6]).toISOString(), comercio: comercio, lugar: lugar,
    monto: convertirNumero(m[11]), moneda: identificarMoneda(m[10]) || 'CRC', tipo: 'gasto', ultimos4: m[8],
    autorizacion: m[9], banco: 'Davibank', origen: 'correo'
  }];
}

/** v2.5.10: texto de Gmail "limpio": sin los * de negrita del texto plano, sin &nbsp, espacios juntos y sin espacio antes de , . ; : */
function limpioDavi_(texto) {
  return String(texto || '').replace(/\*/g, '').replace(/&nbsp;?/g, ' ').replace(/\s+/g, ' ').replace(/\s+([,.;:])/g, '$1').trim();
}
/** v2.5.6 · Davibank: "se recibió el pago a su tarjeta de crédito, terminada en 1234, por CRC 32978.54, el día 02/11/26" → Pago de tarjeta. */
function parsearDavibankPagoTarjeta(texto, fechaCorreo) {
  var t = limpioDavi_(texto);
  var m = t.match(/recibi[oó] el pago a su tarjeta de cr[eé]dito\s*,?\s*terminada en (\d{4})\s*,?\s*por\s+(USD|CRC|US\$|\$|₡|¢)\s*([\d.,]*\d)\s*,?\s*el d[ií]a (\d{1,2})\/(\d{1,2})\/(\d{2,4})/i);
  if (!m) return null;
  var anio = +m[6]; if (anio < 100) anio += 2000;
  var dia = crearFechaCR(anio, +m[5] - 1, +m[4], 12, 0), fc = fechaCorreo ? new Date(fechaCorreo) : null;
  // la hora viene del correo (el texto solo trae el día)
  var fecha = fc && Math.abs(fc - dia) < 36 * 3600000 ? fc : dia;
  var monto = convertirNumero(m[3]);
  return [{
    fecha: fecha.toISOString(), comercio: 'Pago de tarjeta', lugar: '', monto: monto, moneda: identificarMoneda(m[2]) || 'CRC',
    tipo: 'gasto', tipoMov: 'Pago de tarjeta', ultimos4: m[1],
    autorizacion: 'dvpago-' + m[1] + '-' + anio + ('0' + m[5]).slice(-2) + ('0' + m[4]).slice(-2) + '-' + Math.round(monto * 100),
    banco: 'Davibank', origen: 'correo'
  }];
}
/**
 * v2.5.6 · Davibank: "Se realizó un crédito/débito a la cuenta bancaria en CRC terminada en ****1234, por un monto de CRC 32,978.54.
 * La transacción se realizó el día 02-11-2026 20:07:42" → Transferencia (no es gasto ni ingreso: es plata tuya que pasa por esa cuenta;
 * el pago de la tarjeta o la compra llegan en su propio correo).
 */
function parsearDavibankCuenta(texto) {
  var t = limpioDavi_(texto);
  var m = t.match(/Se realiz[oó] un (cr[eé]dito|d[eé]bito) a la cuenta bancaria en (CRC|USD) terminada en \**\s*(\d{4})\s*,?\s*por un monto de\s*(USD|CRC|US\$|\$|₡|¢)\s*([\d.,]*\d)\.?\s*La transacci[oó]n se realiz[oó] el d[ií]a (\d{1,2})-(\d{1,2})-(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/i);
  if (!m) return null;
  var entra = /^cr/i.test(m[1]), monto = convertirNumero(m[5]);
  return [{
    fecha: crearFechaCR(+m[8], +m[7] - 1, +m[6], +m[9], +m[10]).toISOString(),
    comercio: (entra ? 'Entró a ' : 'Salió de ') + 'cuenta Davibank ••' + m[3], lugar: '', monto: monto, moneda: identificarMoneda(m[4]) || m[2],
    tipo: entra ? 'ingreso' : 'gasto', tipoMov: 'Transferencia', cuenta4: m[3],
    autorizacion: 'dvcta-' + m[3] + '-' + m[8] + m[7] + m[6] + m[9] + m[10] + (m[11] || '') + '-' + (entra ? 'c' : 'd') + Math.round(monto * 100),
    nota: 'Movimiento de tu cuenta Davibank: no cuenta como gasto ni ingreso. Si fue plata que te pagaron, cambiá el tipo a Ingreso.',
    banco: 'Davibank', origen: 'correo'
  }];
}

/** Davibank: pago de servicios (se paga con la tarjeta Davibank). */
function parsearDavibankServicio(texto, fechaCorreo) {
  var t = String(texto).replace(/&nbsp;?/g, ' ').replace(/\r/g, '');
  if (!/pago de servicios/i.test(t)) return null;
  var m = t.match(/caracter[ií]sticas:\s*\n?\s*([^\n]+?)\s*\n[\s\S]*?(\d{4,})\s+(\d{1,2}\/\d{1,2}\/\d{4})\s+(₡|¢|\$|USD|CRC)\s*([\d.,]+)/i);
  if (!m) {   // v2.5.8: el mismo correo cuando llega todo en una línea o con la tabla en otro orden: cada dato por separado
    var u = limpioDavi_(t), ini = u.search(/caracter[ií]sticas:/i);
    if (ini >= 0) {
      var resto = u.slice(ini).replace(/^caracter[ií]sticas:\s*/i, '');
      var nom = resto.match(/^(.+?)\s+Nombre\b/i), id = resto.match(/Identificador\s+(\d[\d-]{4,}\d)/i) || resto.match(/\b(\d{5,}(?:-\d+)?)\b/), fv = resto.match(/\b(\d{1,2}\/\d{1,2}\/\d{4})\b/), mo = resto.match(/(₡|¢|\$|USD|CRC)\s*([\d.,]*\d)/i);
      if (nom && id && mo) m = [null, nom[1], id[1], fv ? fv[1] : '', mo[1], mo[2]];
    }
  }
  if (!m) return null;
  var servicio = m[1].replace(/\s+/g, ' ').trim();
  var monto = convertirNumero(m[5]), moneda = identificarMoneda(m[4]) || 'CRC';
  return [{
    fecha: (fechaCorreo || new Date()).toISOString(), comercio: servicio, lugar: '', monto: monto, moneda: moneda, tipo: 'gasto',
    ultimos4: null, autorizacion: 'serv-' + m[2] + '-' + m[3].replace(/\//g, '') + '-' + Math.round(monto * 100),
    banco: 'Davibank', origen: 'correo', esServicio: true, categoria: 'Servicios', nota: 'Pago de servicio · identificador ' + m[2]
  }];
}

/** ¿Las palabras de dos nombres son las mismas (sin importar el orden)? */
function mismoNombre_(a, b) {
  var p = function (x) { return sinTildes_(x).toUpperCase().replace(/[^A-Z ]/g, ' ').split(/\s+/).filter(function (w) { return w.length > 1; }); };
  var A = p(a), B = p(b);
  if (A.length < 2 || B.length < 2) return false;
  var comunes = A.filter(function (w) { return B.indexOf(w) >= 0; }).length;
  return comunes >= 2 && comunes === Math.min(A.length, B.length);   // un pariente con los mismos apellidos no cuenta
}

/** BCR SINPE Móvil: enviado (gasto o transferencia a tu nombre) o recibido (ingreso). */
function parsearSINPE(texto) {
  var t = String(texto).replace(/\r/g, '').replace(/ /g, ' ');
  var debito = /se le ha debitado/i.test(t), credito = /se le ha acreditado/i.test(t);
  if (!debito && !credito) return null;
  var g = function (re) { var m = t.match(re); return m ? m[1].trim() : ''; };
  var monto = convertirNumero(g(/Monto:\s*([\d.,]+)/i));
  if (!monto) return null;
  var nombre = g(/Nombre cliente (?:destino|origen):\s*([^\n]+)/i).replace(/_+/g, ' ').replace(/[\s*]+$/, '').replace(/\s+/g, ' ').trim();
  var titular = g(/Estimado \(a\):\s*([^\n]+)/i);
  var tel = g(/Tel[eé]fono (?:destino|origen):\s*(\d+)/i);
  var entidad = g(/Entidad (?:destino|origen):\s*([^\n]+)/i);
  var motivo = g(/Motivo:\s*([^\n]+)/i).replace(/[_*]+/g, ' ').replace(/\s+/g, ' ').trim();
  var f = t.match(/realizada el (\d{1,2})\/(\d{1,2})\/(\d{4}) a las (\d{1,2}):(\d{2})(?::\d{2})?\s*([AP]\.?\s?M\.?)?/i);
  var fecha = null;
  if (f) {
    var h = +f[4], ap = (f[6] || '').toUpperCase().replace(/[.\s]/g, '');
    if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0;
    fecha = crearFechaCR(+f[3], +f[2] - 1, +f[1], h, +f[5]);
  }
  var propia = debito && mismoNombre_(nombre, titular);
  var nota = [motivo ? 'Motivo: ' + motivo : '', tel && tel !== '0' ? 'Tel ' + tel : '', entidad].filter(String).join(' · ');
  return {
    fecha: fecha ? fecha.toISOString() : null, monto: monto, moneda: 'CRC',
    comercio: (/tiempo real/i.test(t) ? (debito ? 'Débito en tiempo real · ' : 'Crédito en tiempo real · ') : debito ? 'SINPE a ' : 'SINPE de ') + (nombre || 'desconocido'),
    tipoMov: credito ? 'Ingreso' : propia ? 'Transferencia' : 'Gasto', tipo: credito ? 'ingreso' : 'gasto',
    autorizacion: g(/N[uú]mero de referencia:\s*(\d+)/i), nota: nota, banco: 'BCR', origen: 'correo', esSINPE: true
  };
}

/** BCR SAFI: "Solicitud de inversión" o "Solicitud de retiro" (llegan en el momento). */
function parsearSAFI(texto, fechaCorreo) {
  var t = String(texto).replace(/\r/g, '').replace(/ /g, ' ').replace(/\s+/g, ' ');
  var m = t.match(/realiz[oó] una inversi[oó]n en el fondo (.+?)\s*,?\s*con el n[uú]mero de orden (\d+) por un monto de\s*(¢|₡|US\$|\$)\s*([\d.,]*\d).*?en firme el d[ií]a (\d{1,2})\/(\d{1,2})\/(\d{4})/i);
  var tipo = 'Inversión';
  if (!m) { m = t.match(/realiz[oó] un retiro del fondo (.+?)\s*,?\s*con el n[uú]mero de retiro (\d+) por un monto de\s*(¢|₡|US\$|\$)\s*([\d.,]*\d).*?acreditada en la cuenta seleccionada el d[ií]a (\d{1,2})\/(\d{1,2})\/(\d{4})/i); tipo = 'Retiro de fondo'; }
  if (!m) return null;
  var fondo = m[1].replace(/\s+/g, ' ').trim();
  var fFirme = new Date(Date.UTC(+m[7], +m[6] - 1, +m[5], 18, 0));
  return {
    tipoMov: tipo, fondo: fondo, numero: m[2], monto: convertirNumero(m[4]), moneda: identificarMoneda(m[3]) || 'CRC',
    fecha: (tipo === 'Inversión' ? (fechaCorreo || fFirme) : fFirme).toISOString(),
    comercio: (tipo === 'Inversión' ? 'Inversión · ' : 'Retiro · ') + fondo,
    autorizacion: 'SAFI-' + (tipo === 'Inversión' ? 'I-' : 'R-') + m[2],
    nota: (tipo === 'Inversión' ? 'Orden ' + m[2] + ' · en firme ' : 'Retiro ' + m[2] + ' · se acredita ') + m[5] + '/' + m[6] + '/' + m[7],
    banco: 'BCR SAFI', origen: 'correo'
  };
}

/**
 * v2.10.6 · BAC Credomatic: "Notificación de transacción". Campos en líneas:
 *   Comercio: … · Ciudad y país: … · Fecha: Nov 1, 2026, 11:55 · VISA: ************1234 · Autorización: … · Referencia: … · Tipo de Transacción: COMPRA · Monto: CRC 1,234.56
 */
var MESES_BAC_ = { ene: 0, jan: 0, feb: 1, mar: 2, abr: 3, apr: 3, may: 4, jun: 5, jul: 6, ago: 7, aug: 7, sep: 8, set: 8, oct: 9, nov: 10, dic: 11, dec: 11 };
function parsearBACNotificacion(texto) {
  var t = limpioDavi_(texto);
  if (!/Tipo de Transacci[oó]n/i.test(t) || !/Monto/i.test(t)) return null;
  var ET = '(?=\\s+(?:Comercio|Ciudad y pa[ií]s|Fecha|VISA|MASTER\\s?CARD|AMEX|AMERICAN EXPRESS|Tarjeta|Autorizaci[oó]n|Referencia|Tipo de Transacci[oó]n|Monto|¿Tiene dudas)\\s*:?|\\s*$)';
  function campo(nombre) { var m = t.match(new RegExp(nombre + '\\s*:\\s*(.+?)' + ET, 'i')); return m ? m[1].trim() : ''; }
  var comercio = campo('Comercio'), lugar = campo('Ciudad y pa[ií]s'), fecha = campo('Fecha'), tipo = campo('Tipo de Transacci[oó]n');
  var mt = t.match(/Monto\s*:\s*(USD|CRC|US\$|\$|₡|¢|EUR)\s*([\d.,]*\d)/i);
  var u4 = t.match(/(?:VISA|MASTER\s?CARD|AMEX|AMERICAN EXPRESS|Tarjeta)\s*:\s*[*•xX\s]*(\d{4})\b/i);
  if (!comercio || !mt || !u4) return null;
  if (/declin|rechaz|denegad/i.test(tipo)) return [];
  var f = null, a;
  if ((a = fecha.match(/([A-Za-zé]{3})[a-zé]*\.?\s+(\d{1,2}),?\s+(\d{4}),?\s+(\d{1,2}):(\d{2})\s*([AaPp]\.?\s?[Mm]\.?)?/)) && MESES_BAC_[a[1].toLowerCase().slice(0, 3)] !== undefined) {
    f = [+a[3], MESES_BAC_[a[1].toLowerCase().slice(0, 3)], +a[2], +a[4], +a[5], a[6]];
  } else if ((a = fecha.match(/(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4}),?\s+(\d{1,2}):(\d{2})\s*([AaPp]\.?\s?[Mm]\.?)?/))) {
    f = [a[3].length === 2 ? 2000 + +a[3] : +a[3], +a[2] - 1, +a[1], +a[4], +a[5], a[6]];
  }
  if (!f) return null;
  var ap = (f[5] || '').toUpperCase().replace(/[.\s]/g, ''), h = f[3];
  if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0;
  var devol = /devoluci|reversi|anulaci|cr[eé]dito|reembolso/i.test(tipo);
  lugar = lugar.replace(/,\s*Costa Rica$/i, '').replace(/\s+/g, ' ');
  lugar = lugar.toLowerCase().replace(/(^|\s)\S/g, function (x) { return x.toUpperCase(); });
  return [{
    fecha: crearFechaCR(f[0], f[1], f[2], h, f[4]).toISOString(), comercio: comercio, lugar: lugar,
    monto: convertirNumero(mt[2]), moneda: identificarMoneda(mt[1]) || (/EUR/i.test(mt[1]) ? 'USD' : 'CRC'), tipo: devol ? 'ingreso' : 'gasto',
    ultimos4: u4[1], autorizacion: 'BAC-' + (campo('Autorizaci[oó]n') || campo('Referencia')).replace(/\s/g, ''), banco: 'BAC', origen: 'correo'
  }];
}

/**
 * Despacha el correo de un banco al lector que corresponde.
 * Devuelve una lista de transacciones (vacía = correo entendido pero sin nada que anotar) o null si no se pudo leer.
 */
function parsearCorreoBanco(texto, html, fechaCorreo, banco) {
  var todo = String(texto || '') + '\n' + textoDeHtml_(html);
  if (/Tipo de Transacci[oó]n/i.test(todo) && /Comercio/i.test(todo)) { var bac = parsearBACNotificacion(texto) || parsearBACNotificacion(textoDeHtml_(html)); if (bac) return bac; }   // v2.10.6
  if (/Detalle de Transacciones/i.test(todo)) { var r = parsearBCRTabla(texto, html); if (r) return r; }
  if (/pago de servicios/i.test(todo)) { var s = parsearDavibankServicio(texto, fechaCorreo) || parsearDavibankServicio(textoDeHtml_(html), fechaCorreo); if (s) return s; }
  if (/transacci[oó]n realizada en/i.test(todo)) { var d = parsearDavibankCompra(texto) || parsearDavibankCompra(textoDeHtml_(html)); if (d) return d; }
  if (/recibi[oó] el pago a su tarjeta de cr[eé]dito/i.test(todo)) { var pt = parsearDavibankPagoTarjeta(texto, fechaCorreo) || parsearDavibankPagoTarjeta(textoDeHtml_(html), fechaCorreo); if (pt) return pt; }
  if (/a la cuenta bancaria en (CRC|USD) terminada en/i.test(todo)) { var dc = parsearDavibankCuenta(texto) || parsearDavibankCuenta(textoDeHtml_(html)); if (dc) return dc; }
  if (/env[ií]o exitoso de d[eé]bito en tiempo real/i.test(todo)) return [];   // aviso repetido del mismo SINPE (ya llega el del banco y el de la cuenta)
  if (/SINPE|tiempo real/i.test(todo)) { var x = parsearSINPE(texto) || parsearSINPE(textoDeHtml_(html)); if (x) return [x]; }
  var tx = parsearCorreo(texto, fechaCorreo, banco);
  return tx ? [tx] : null;
}

// Permite usar este archivo en las pruebas (Node). Apps Script lo ignora.
if (typeof module !== 'undefined') {
  module.exports = { parsearCorreo: parsearCorreo, convertirNumero: convertirNumero, extraerMonto: extraerMonto };
}
