/**
 * Ajustes.js — Configuración, clave de acceso (PIN) y recordatorios por correo.
 *
 * Toda la app habla con el servidor por medio de api(). Si tenés un PIN
 * activado, api() no responde nada sin una sesión válida.
 */

var VERSION_APP = '2.18.0';
var MINUTOS_SESION = 12 * 60;      // una sesión con PIN dura hasta 12 horas
var INTENTOS_MAX = 5;               // después de 5 intentos fallidos, espera 5 minutos

/** Funciones que la app puede pedir. */
var API = {
  obtenerDatos: function () { return obtenerDatos_(); },
  guardarMovimiento: function (m) { return guardarMovimiento_(m); },
  eliminarMovimiento: function (f, c) { return eliminarMovimiento_(f, c); },
  pasarATasaCero: function (f, c, n, d) { return pasarATasaCero_(f, c, n, d); },
  guardarAbonoTC: function (a) { return guardarAbonoTC_(a); },
  guardarRepartoTC: function (r) { return guardarRepartoTC_(r); },
  guardarSobresMov: function (l) { return guardarSobresMov_(l); },
  eliminarGrupoSobres: function (g) { return eliminarGrupoSobres_(g); },
  guardarReglaSobre: function (p, s) { return guardarReglaSobre_(p, s); },
  guardarReparto: function (l, a) { return guardarReparto_(l, a); },
  guardarSobresDesde: function (f) { return guardarSobresDesde_(f); },
  guardarSobresEspeciales: function (e) { return guardarSobresEspeciales_(e); },
  guardarFondo: function (f) { return guardarFondo_(f); },
  actualizarSaldoFondo: function (f, s, i) { return actualizarSaldoFondo_(f, s, i); },
  marcarMovimiento: function (f, c, v, k) { return marcarMovimiento_(f, c, v, k); },
  actualizarSaldoCuenta: function (f, c, u, d) { return actualizarSaldoCuenta_(f, c, u, d); },
  guardarViaje: function (v) { return guardarViaje_(v); },
  eliminarViaje: function (f) { return eliminarViaje_(f); },
  eliminarAbonoTC: function (f, c) { return eliminarAbonoTC_(f, c); },
  // v2.13.0 (#58): todo desde la app
  guardarCategorias: function (l) { return guardarCategorias_(l); },
  renombrarCategoria: function (v, n, mover) { return renombrarCategoria_(v, n, mover); },
  guardarRegla: function (p, c, s) { return conBloqueo_(function () { guardarRegla_(p, c, s); return true; }); },
  editarRegla: function (f, r, ctl) { return editarRegla_(f, r, ctl); },
  eliminarRegla: function (f, ctl) { return eliminarRegla_(f, ctl); },
  editarTasaCero: function (f, d, antes) { return editarTasaCero_(f, d, antes); },
  quitarTasaCero: function (f, antes) { return quitarTasaCero_(f, antes); },
  guardarCuenta: function (c) { return guardarCuenta_(c); },
  guardarSobre: function (s) { return guardarSobre_(s); },
  registrarPagoPrestamo: function (p) { return registrarPago_(p); },
  registrarTBP: function (f, t) { return registrarTBP_(f, t); },
  revisarCorreosAhora: function () { return revisarCorreosAhora_(); },
  // v2.14.0 (#58d–g, #59): más cosas desde la app
  guardarBanco: function (b) { return guardarBanco_(b); },
  quitarBanco: function (f, ctl) { return quitarBanco_(f, ctl); },
  guardarRecurrente: function (r) { return guardarRecurrente_(r); },
  eliminarRecurrente: function (f, ctl) { return eliminarRecurrente_(f, ctl); },
  archivarSobre: function (f, si) { return archivarSobre_(f, si); },
  archivarFondo: function (f, si) { return archivarFondo_(f, si); },
  guardarTipoCambio: function (n) { return guardarTipoCambio_(n); },
  obtenerAjustes: function () { return obtenerAjustes_(); },
  guardarPIN: function (nuevo, actual) { return guardarPIN_(nuevo, actual); },
  quitarPIN: function (actual) { return quitarPIN_(actual); },
  quitarHuella: function (id) { return quitarHuella_(id); },
  guardarRecordatorios: function (activo) { return guardarRecordatorios_(activo); },
  probarRecordatorio: function () { return enviarRecordatorios_(true); },
  // v2.5
  guardarPreferencias: function (p) { return guardarPreferencias_(p); },
  activarAvisosTelefono: function () { return activarAvisosTelefono_(); },
  resumenAvisos: function () { return resumenAvisos_(); },
  probarResumenCorreo: function () { return enviarResumenCorreo_(true); },
  estadoActualizacion: function () { return estadoActualizacion_(); },
  fijarUrlActualizacion: function (u) { return fijarUrlActualizacion_(u); },
  revisarActualizacion: function () { return revisarActualizacion_(); },
  actualizarServidor: function () { return actualizarServidor_(); },
  volverVersionAnterior: function () { return volverVersionAnterior_(); },
  listas: function () { return listasResumen_(); },
  crearLista: function (n, i, it, opc) { return crearLista_(n, i, it, opc); },
  obtenerLista: function (id, v) { return obtenerLista_(id, v); },
  cambiarLista: function (id, op, quien) { return cambiarLista_(id, op, quien, false); },
  eliminarLista: function (id) { return eliminarLista_(id); },
  linkLista: function (id, nuevo) { return linkLista_(id, nuevo); },
  casaEstado: function (cuenta) { return casaEstado_(cuenta); },
  casaLink: function (cuenta, opc) { return casaLink_(cuenta, opc); },
  casaPermisos: function (cuenta, p) { return casaPermisos_(cuenta, p); },
  casaApagar: function (cuenta) { return casaApagar_(cuenta); },
  quitarLinkLista: function (id) { return quitarLinkLista_(id); },
  subirFotoLista: function (id, datos) { return guardarFoto_(id, datos); },
  fotoLista: function (id) { return leerFoto_(id); }
};

/**
 * Única puerta de entrada desde la app (GitHub Pages).
 * La app manda { clave, sesion, accion, args } como texto JSON.
 */
function doPost(e) {
  var r;
  try {
    var d = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    // v2.5: quien abre el link de una lista solo puede tocar esa lista; el aviso del teléfono solo pide el resumen
    // v2.18: la app de la casa solo ve y anota el presupuesto por corte de su tarjeta
    if (d.casa) return ContentService.createTextOutput(JSON.stringify((function () { try { return { ok: true, resultado: apiCasa_(d.casa, d.accion, d.args) }; } catch (e4) { return { ok: false, error: String(e4 && e4.message ? e4.message : e4) }; } })())).setMimeType(ContentService.MimeType.JSON);
    if (d.lista) return ContentService.createTextOutput(JSON.stringify((function () { try { return { ok: true, resultado: apiListaLink_(d.lista, d.accion, d.args) }; } catch (e3) { return { ok: false, error: String(e3 && e3.message ? e3.message : e3) }; } })())).setMimeType(ContentService.MimeType.JSON);
    if (d.avisos) {
      if (!llaveAvisosValida_(d.avisos)) throw new Error('LLAVE_AVISOS');
      return ContentService.createTextOutput(JSON.stringify({ ok: true, resultado: resumenAvisos_() })).setMimeType(ContentService.MimeType.JSON);
    }
    if (!claveValida_(d.clave)) throw new Error('CLAVE_INVALIDA');
    if (d.accion === 'ping') r = { ok: true, resultado: 'Conectado a ' + libro_().getName() };
    else if (d.accion === 'estadoAcceso') r = { ok: true, resultado: estadoAcceso() };
    else if (d.accion === 'abrirApp') r = { ok: true, resultado: abrirApp_(d.sesion, (d.args || [])[0]) };            // v2.14 (#61)
    else if (d.accion === 'revisarAlAbrir') r = { ok: true, resultado: revisarAlAbrir_(!!(d.args || [])[0]) };
    else if (d.accion === 'verificarPIN') r = { ok: true, resultado: verificarPIN((d.args || [])[0]) };
    else if (d.accion === 'activarHuella') r = { ok: true, resultado: activarHuella_((d.args || [])[0], (d.args || [])[1]) };
    else if (d.accion === 'entrarConHuella') r = { ok: true, resultado: entrarConHuella_((d.args || [])[0], (d.args || [])[1]) };
    else {
      // v2.3.1: lo que manda la cola del teléfono trae un id; si llega repetido (se cortó la respuesta), no se vuelve a hacer
      var cacheId = d.id ? CacheService.getScriptCache() : null, previo = cacheId ? cacheId.get('idem_' + d.id) : null;
      if (previo) r = JSON.parse(previo);
      else {
        try { r = { ok: true, resultado: api(d.sesion, d.accion, d.args) }; }
        catch (e1) { r = { ok: false, error: String(e1 && e1.message ? e1.message : e1) }; }
        if (cacheId && !/PIN_REQUERIDO|CLAVE_INVALIDA/.test(r.error || '')) { try { cacheId.put('idem_' + d.id, JSON.stringify(r), 21600); } catch (e2) { /* muy grande: no se guarda */ } }
      }
    }
  } catch (err) {
    r = { ok: false, error: String(err && err.message ? err.message : err) };
  }
  return ContentService.createTextOutput(JSON.stringify(r)).setMimeType(ContentService.MimeType.JSON);
}

/** Compara la clave de la app. Tras 10 intentos fallidos, se bloquea 10 minutos. */
function claveValida_(clave) {
  var cache = CacheService.getScriptCache();
  var fallos = Number(cache.get('clave_fallos') || 0);
  if (fallos >= 10) throw new Error('Demasiados intentos con una clave incorrecta. Esperá 10 minutos.');
  var buena = props_().getProperty('CLAVE_APP');
  if (buena && clave === buena) return true;
  cache.put('clave_fallos', String(fallos + 1), 600);
  return false;
}

function api(sesion, nombre, args) {
  if (!API[nombre]) throw new Error('Acción desconocida: ' + nombre);
  if (!sesionValida_(sesion)) throw new Error('PIN_REQUERIDO');
  var res = API[nombre].apply(null, args || []);
  if (!LECTURAS_[nombre]) marcarCambio_();   // v2.14: algo cambió → la próxima apertura trae los datos completos
  return res;
}

/** ¿Hay PIN? (no devuelve datos) */
function estadoAcceso() {
  var p = props_();
  return { pinActivo: !!p.getProperty('PIN_HASH'), pinLargo: Number(p.getProperty('PIN_LARGO')) || null };
}

function props_() { return PropertiesService.getScriptProperties(); }

function hash_(pin, sal) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, sal + ':' + pin, Utilities.Charset.UTF_8);
  return Utilities.base64Encode(bytes);
}

function pinCorrecto_(pin) {
  var h = props_().getProperty('PIN_HASH');
  if (!h) return true;
  return hash_(String(pin || ''), props_().getProperty('PIN_SAL')) === h;
}

function sesionValida_(token) {
  if (!props_().getProperty('PIN_HASH')) return true;
  return !!token && CacheService.getScriptCache().get('ses_' + token) === '1';
}

/** Verifica el PIN y devuelve una sesión. Bloquea 5 minutos tras varios intentos fallidos. */
function verificarPIN(pin) {
  var cache = CacheService.getScriptCache();
  var fallos = Number(cache.get('pin_fallos') || 0);
  if (fallos >= INTENTOS_MAX) throw new Error('Demasiados intentos. Esperá 5 minutos.');
  if (!pinCorrecto_(pin)) {
    cache.put('pin_fallos', String(fallos + 1), 300);
    throw new Error('PIN incorrecto' + (fallos + 1 >= INTENTOS_MAX ? '. Esperá 5 minutos.' : ''));
  }
  cache.remove('pin_fallos');
  if (props_().getProperty('PIN_HASH') && !props_().getProperty('PIN_LARGO')) props_().setProperty('PIN_LARGO', String(String(pin).length));
  return nuevaSesion_();
}

function nuevaSesion_() {
  var token = Utilities.getUuid();
  CacheService.getScriptCache().put('ses_' + token, '1', MINUTOS_SESION * 60);
  return token;
}

// ---------------------------------------------------------------------
// HUELLA: el teléfono verifica la huella; aquí solo se guarda una llave
// por teléfono (guardada como hash). Cambiar o quitar el PIN las borra todas.
// ---------------------------------------------------------------------
function huellas_() { try { return JSON.parse(props_().getProperty('HUELLAS') || '[]'); } catch (e) { return []; } }
function guardarHuellas_(l) { if (l.length) props_().setProperty('HUELLAS', JSON.stringify(l)); else props_().deleteProperty('HUELLAS'); }

/** Con el PIN correcto, registra este teléfono. Devuelve { id, llave, sesion }. */
function activarHuella_(pin, nombre) {
  if (!props_().getProperty('PIN_HASH')) throw new Error('Primero creá un PIN.');
  var sesion = verificarPIN(pin);
  var id = Utilities.getUuid().slice(0, 8), llave = Utilities.getUuid() + Utilities.getUuid(), sal = Utilities.getUuid();
  var l = huellas_().filter(function (x) { return x.id !== id; });
  l.push({ id: id, sal: sal, h: hash_(llave, sal), n: String(nombre || 'Teléfono').slice(0, 40), c: new Date().toISOString() });
  guardarHuellas_(l.slice(-5));   // máximo 5 teléfonos
  return { id: id, llave: llave, sesion: sesion };
}

/** El teléfono ya verificó la huella: con su llave recibe una sesión. */
function entrarConHuella_(id, llave) {
  var cache = CacheService.getScriptCache();
  var fallos = Number(cache.get('pin_fallos') || 0);
  if (fallos >= INTENTOS_MAX) throw new Error('Demasiados intentos. Esperá 5 minutos.');
  var x = huellas_().filter(function (h) { return h.id === id; })[0];
  if (!x || hash_(String(llave || ''), x.sal) !== x.h) {
    cache.put('pin_fallos', String(fallos + 1), 300);
    throw new Error('HUELLA_INVALIDA');
  }
  return nuevaSesion_();
}

function quitarHuella_(id) { guardarHuellas_(huellas_().filter(function (h) { return h.id !== id; })); return true; }

function guardarPIN_(nuevo, actual) {
  nuevo = String(nuevo || '');
  if (!/^\d{4,6}$/.test(nuevo)) throw new Error('El PIN debe tener de 4 a 6 números.');
  if (!pinCorrecto_(actual)) throw new Error('El PIN actual no es correcto.');
  var sal = Utilities.getUuid();
  props_().setProperties({ PIN_SAL: sal, PIN_HASH: hash_(nuevo, sal), PIN_LARGO: String(nuevo.length) });
  props_().deleteProperty('HUELLAS');   // las huellas se activan otra vez con el PIN nuevo
  return verificarPIN(nuevo);   // devuelve una sesión nueva para seguir usando la app
}

function quitarPIN_(actual) {
  if (!pinCorrecto_(actual)) throw new Error('El PIN no es correcto.');
  ['PIN_HASH', 'PIN_SAL', 'PIN_LARGO', 'HUELLAS'].forEach(function (k) { props_().deleteProperty(k); });
  return true;
}

/**
 * ¿Olvidaste el PIN? Abrí Apps Script y ejecutá esta función: borra el PIN.
 * (Solo vos podés hacerlo, porque solo vos tenés acceso al proyecto.)
 */
function borrarPINOlvidado() {
  ['PIN_HASH', 'PIN_SAL', 'PIN_LARGO', 'HUELLAS'].forEach(function (k) { props_().deleteProperty(k); });
  console.log('✅ PIN borrado. Ya podés entrar a la app sin PIN y crear uno nuevo.');
}

function obtenerAjustes_() {
  var p = props_();
  var libro = libro_();
  return {
    pinActivo: !!p.getProperty('PIN_HASH'),
    pinLargo: Number(p.getProperty('PIN_LARGO')) || null,
    huellas: huellas_().map(function (h) { return { id: h.id, nombre: h.n, creado: h.c }; }),
    recordatorios: p.getProperty('RECORDATORIOS') === 'si',
    correo: Session.getEffectiveUser().getEmail(),
    ultimaRevision: p.getProperty('ULTIMA_REVISION'),
    urlHoja: libro.getUrl(),
    nombreHoja: libro.getName(),
    bancos: bancosActivos_().map(function (b) { return b.nombre; }),
    bancosCfg: (function () { try { return bancosConfig_(); } catch (e) { return null; } })(),   // v2.14 (#58d)
    version: VERSION_APP,
    prefs: prefs_(),
    ajenasSaltadas: ajenasSaltadas_(),
    actualizacion: estadoActualizacion_()
  };
}

function guardarRecordatorios_(activo) {
  props_().setProperty('RECORDATORIOS', activo ? 'si' : 'no');
  return true;
}

// ---------------------------------------------------------------------
// RECORDATORIOS POR CORREO (corren una vez al día con procesarDiario)
// ---------------------------------------------------------------------

/** Lo que corre solo cada mañana. */
function procesarDiario() {
  procesarRecurrentes();
  if (props_().getProperty('RECORDATORIOS') === 'si') enviarRecordatorios_(false);
  try { tareasDespuesDeLeer_(); } catch (e) { console.log(e); }
  marcarCambio_();   // v2.14: la app trae todo de nuevo la próxima vez que abra
}

function diasHasta_(fecha) {
  var hoy = new Date(); hoy.setHours(0, 0, 0, 0);
  var f = new Date(fecha); f.setHours(0, 0, 0, 0);
  return Math.round((f - hoy) / 86400000);
}

function proximoDia_(dia) {
  var h = new Date(); h.setHours(0, 0, 0, 0);
  var y = h.getFullYear(), m = h.getMonth();
  var ultimo = function (yy, mm) { return new Date(yy, mm + 1, 0).getDate(); };
  if (h.getDate() > Math.min(dia, ultimo(y, m))) { m++; if (m > 11) { m = 0; y++; } }
  return new Date(y, m, Math.min(dia, ultimo(y, m)));
}

/**
 * Arma el correo de recordatorios. Solo lo envía si hay algo que avisar
 * (o siempre, si `prueba` es true).
 */
function enviarRecordatorios_(prueba) {
  var avisos = avisosRecordatorio_();
  if (!avisos.length && !prueba) return 'Nada que avisar hoy.';
  var cuerpo = (avisos.length ? avisos.join('\n') : 'Todo al día. Así se ven los recordatorios cuando hay algo que avisar.') +
    '\n\n— Finanzas';
  MailApp.sendEmail(Session.getEffectiveUser().getEmail(), (prueba ? '[Prueba] ' : '') + 'Finanzas: recordatorios', cuerpo);
  return prueba ? 'Te envié un correo de prueba.' : 'Recordatorios enviados.';
}

function avisosRecordatorio_() {
  var avisos = [];

  leerTabla_('Cuentas', 'Nombre (único)').filas.forEach(function (c) {
    var dia = num_(c['Día de pago']);
    if (texto_(c['Tipo']) !== 'Tarjeta de crédito' || texto_(c['Activa']) === 'No' || !dia) return;
    var d = diasHasta_(proximoDia_(dia));
    if (d === 3 || d === 1 || d === 0) {
      avisos.push('💳 Pago de ' + texto_(c['Nombre (único)']) + (d === 0 ? ' es HOY' : ' en ' + d + ' día' + (d === 1 ? '' : 's')) + '.');
    }
  });

  var p = hoja_('Préstamo casa');
  var venc = p.getRange('G9').getValue();
  var estimado = num_(p.getRange('K8').getValue());
  if (venc instanceof Date) {
    var dv = diasHasta_(venc);
    if (dv >= 0 && dv <= 5) {
      avisos.push('🏠 La cuota del préstamo vence el ' + Utilities.formatDate(venc, 'America/Costa_Rica', 'dd/MM') +
        ' (en ' + dv + ' día' + (dv === 1 ? '' : 's') + '). Estimado: ₡' + Math.round(estimado || 0).toLocaleString('es-CR') + '.');
    }
  }

  var hoy = new Date();
  if (hoy.getDate() >= 7 && hoy.getDate() <= 9) {
    var tasas = leerTabla_('Tasas BCCR', 'Fecha de la TBP (día 7)').filas;
    var tiene = tasas.some(function (r) {
      var f = r['Fecha de la TBP (día 7)'];
      return f instanceof Date && f.getMonth() === hoy.getMonth() && f.getFullYear() === hoy.getFullYear() && num_(r['TBP']) !== null;
    });
    if (!tiene) avisos.push('📈 Falta anotar la TBP del 7 de este mes (en la app: Préstamo → Anotar TBP).');
  }

  var desde = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
  var sinCategoria = leerTabla_('Movimientos', 'Fecha').filas.filter(function (r) {
    return r['Fecha'] instanceof Date && r['Fecha'] >= desde && texto_(r['Tipo']) === 'Gasto' && !texto_(r['Categoría']);
  }).length;
  if (sinCategoria >= 3) avisos.push('🔎 Tenés ' + sinCategoria + ' gastos de este mes sin categoría.');
  return avisos;
}
