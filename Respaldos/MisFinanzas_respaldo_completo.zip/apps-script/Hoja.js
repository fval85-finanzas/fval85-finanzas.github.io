/**
 * Hoja.js — Lectura y escritura en la Google Sheet.
 *
 * Las columnas se buscan por el NOMBRE del encabezado, así que podés
 * reordenarlas o agregar columnas nuevas. Lo que no se puede es cambiar
 * el texto de los encabezados ni el nombre de las pestañas.
 */

var FILA_ENCABEZADO = {
  'Movimientos': 4,
  'Cuentas': 4,
  'Tasa Cero': 6,
  'Sobres': 4,
  'Préstamo casa': 15,
  'Tasas BCCR': 4,
  'Reglas': 4,
  'Recurrentes': 4,
  'Config': 4,
  'Abonos tasa cero': 4,
  'Movimientos de sobres': 4,
  'Fondos': 4,
  'Viajes': 4
};

function libro_() {
  var id = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActive();
}

function hoja_(nombre) {
  var h = libro_().getSheetByName(nombre);
  if (!h) throw new Error('No encuentro la pestaña "' + nombre + '". No le cambiés el nombre.');
  return h;
}

/** { 'Encabezado': númeroDeColumna } */
function columnas_(h, filaEnc) {
  var enc = h.getRange(filaEnc, 1, 1, h.getLastColumn()).getDisplayValues()[0];
  var m = {};
  enc.forEach(function (t, i) { t = String(t).trim(); if (t && !m[t]) m[t] = i + 1; });
  return m;
}

function exigir_(cols, nombres, pestaña) {
  nombres.forEach(function (n) {
    if (!cols[n]) throw new Error('Falta la columna "' + n + '" en la pestaña ' + pestaña + '.');
  });
}

/**
 * Lee una tabla y devuelve las filas donde la columna `clave` tiene algo.
 * Cada fila es un objeto { _fila: número, 'Encabezado': valor, ... }.
 */
function leerTabla_(nombre, clave) {
  var h = hoja_(nombre);
  var f0 = FILA_ENCABEZADO[nombre];
  var cols = columnas_(h, f0);
  exigir_(cols, [clave], nombre);
  var n = h.getLastRow() - f0;
  var filas = [];
  if (n > 0) {
    var datos = h.getRange(f0 + 1, 1, n, h.getLastColumn()).getValues();
    var ci = cols[clave] - 1;
    datos.forEach(function (r, i) {
      if (r[ci] === '' || r[ci] === null) return;
      var o = { _fila: f0 + 1 + i };
      for (var k in cols) o[k] = r[cols[k] - 1];
      filas.push(o);
    });
  }
  return { hoja: h, cols: cols, filas: filas, filaEnc: f0 };
}

/** Agrega al final del encabezado las columnas que falten (para versiones nuevas sin tocar la hoja a mano). */
function asegurarColumnas_(nombre, columnas) {
  var h = hoja_(nombre), f0 = FILA_ENCABEZADO[nombre];
  var cols = columnas_(h, f0), ultima = h.getLastColumn();
  columnas.forEach(function (c) {
    if (cols[c]) return;
    ultima++;
    h.getRange(f0, ultima).setValue(c);
    cols[c] = ultima;
  });
  columnas.forEach(function (c) { formatoEncabezado_(h, f0, cols[c]); });
  return cols;
}

/** Copia el formato del título de la izquierda (color, letra, alto) y deja la columna con buen ancho. */
function formatoEncabezado_(h, f0, col) {
  if (col <= 1) return;
  var tipo = SpreadsheetApp.CopyPasteType ? SpreadsheetApp.CopyPasteType.PASTE_FORMAT : null;
  if (tipo) h.getRange(f0, col - 1).copyTo(h.getRange(f0, col), tipo, false);
  h.getRange(f0, col).setWrap(true);
  h.setColumnWidth(col, 130);
}

/** Primera fila vacía en la columna `col` (debajo del encabezado). Agrega filas si hace falta. */
function primeraFilaVacia_(h, filaEnc, col) {
  var max = h.getMaxRows();
  var n = Math.max(max - filaEnc, 1);
  var v = h.getRange(filaEnc + 1, col, n, 1).getValues();
  for (var i = 0; i < v.length; i++) {
    if (v[i][0] === '' || v[i][0] === null) return filaEnc + 1 + i;
  }
  h.insertRowsAfter(max, 200);
  return max + 1;
}

/**
 * Escribe los valores de `obj` ({ 'Encabezado': valor }) en la fila indicada.
 * Nunca sobrescribe una celda que tenga fórmula.
 */
function escribirFila_(h, fila, cols, obj) {
  var ultimaCol = h.getLastColumn();
  var rango = h.getRange(fila, 1, 1, ultimaCol);
  var formulas = rango.getFormulas()[0];
  var valores = rango.getValues()[0];
  var cambio = false;
  for (var k in obj) {
    var c = cols[k];
    if (!c || formulas[c - 1]) continue;
    valores[c - 1] = obj[k] === undefined ? '' : obj[k];
    cambio = true;
  }
  if (!cambio) return;
  // Se escriben solo las celdas sin fórmula, en bloques contiguos
  var inicio = null;
  for (var i = 0; i <= ultimaCol; i++) {
    var libre = i < ultimaCol && !formulas[i];
    if (libre && inicio === null) inicio = i;
    if (!libre && inicio !== null) {
      var bloque = valores.slice(inicio, i);
      if (algunoFueraDeLista_(h, fila, inicio + 1, bloque)) permitirFueraDeLista_(h, fila, inicio + 1, i - inicio);   // v2.10.10: antes de escribir
      // v2.10.10: Google junta las escrituras y el error de validación sale después (fuera del try): flush() lo trae acá
      try { h.getRange(fila, inicio + 1, 1, i - inicio).setValues([bloque]); vaciar_(); }
      catch (e) {
        // v2.10.8: una columna con lista desplegable que rechaza otros valores (ej. "Cuenta / tarjeta" con Efectivo o Familia ••1234):
        // se le permite aceptar otros valores (queda solo el aviso de la hoja) y se vuelve a escribir
        if (!permitirFueraDeLista_(h, fila, inicio + 1, i - inicio)) throw e;
        h.getRange(fila, inicio + 1, 1, i - inicio).setValues([bloque]); vaciar_();
      }
      inicio = null;
    }
  }
}

/** ¿Algún valor nuevo no está en la lista desplegable (que rechaza) de su celda? */
function algunoFueraDeLista_(h, fila, col0, bloque) {
  try {
    var reglas = h.getRange(fila, col0, 1, bloque.length).getDataValidations()[0];
    return reglas.some(function (r, i) {
      var v = bloque[i];
      if (!r || r.getAllowInvalid() || v === '' || v === null || v === undefined) return false;
      var tipo = String(r.getCriteriaType()), cv = r.getCriteriaValues() || [];
      var lista = /VALUE_IN_LIST/.test(tipo) ? (cv[0] || []) : /VALUE_IN_RANGE/.test(tipo) && cv[0] && cv[0].getValues ? [].concat.apply([], cv[0].getValues()) : null;
      if (!lista) return false;
      return !lista.some(function (x) { return String(x).trim() === String(v).trim(); });
    });
  } catch (e) { console.log('algunoFueraDeLista_: ' + e); return false; }
}

/** Aplica ya las escrituras pendientes (para que un error salga en el momento) */
function vaciar_() { if (typeof SpreadsheetApp !== 'undefined' && SpreadsheetApp.flush) SpreadsheetApp.flush(); }

/** Cambia las validaciones de lista "rechazar entrada" de esas columnas a "mostrar advertencia". Devuelve true si cambió alguna. */
function permitirFueraDeLista_(h, fila, col0, n) {
  var cambio = false;
  try {
    var reglas = h.getRange(fila, col0, 1, n).getDataValidations()[0];
    reglas.forEach(function (r, i) {
      if (!r || r.getAllowInvalid()) return;
      var col = col0 + i, total = h.getMaxRows(), rango = h.getRange(1, col, total, 1), todas = rango.getDataValidations();
      rango.setDataValidations(todas.map(function (fila1) { var x = fila1[0]; return [x && !x.getAllowInvalid() ? x.copy().setAllowInvalid(true).build() : x]; }));
      cambio = true;
    });
  } catch (e) { console.log('permitirFueraDeLista_: ' + e); }
  return cambio;
}

/** Fecha → texto ISO (google.script.run no acepta objetos Date). */
function iso_(v) {
  if (v instanceof Date) return v.toISOString();
  if (v === '' || v === null || v === undefined) return null;
  var m = String(v).trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);   // fecha escrita como texto: 31/10/2026
  if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), 12).toISOString();
  return v;
}

function num_(v) {
  if (typeof v === 'number') return v;
  if (v === '' || v === null || v === undefined) return null;
  // v2.2.1: números escritos como texto en la hoja ("₡32 978,54", "$1 245,00", con espacios normales o duros)
  var t = String(v).replace(/[^\d,.\-]/g, '');
  if (!t || !/\d/.test(t)) return null;
  var n = convertirNumero(t);
  return n === null ? null : n;
}

function texto_(v) {
  return v === null || v === undefined ? '' : String(v).trim();
}

/** Lee una lista de la pestaña Config por el título de su columna (ej. "Categorías"). */
function listaConfig_(titulo) {
  var h = hoja_('Config');
  var cols = columnas_(h, 4);
  if (!cols[titulo]) return [];
  var v = h.getRange(5, cols[titulo], Math.max(30, Math.min(300, h.getLastRow() - 4)), 1).getValues();   // v2.13.0: más de 30
  return v.map(function (r) { return texto_(r[0]); }).filter(String);
}
