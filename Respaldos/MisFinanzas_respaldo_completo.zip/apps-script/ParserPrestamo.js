/**
 * ParserPrestamo.js — Lee el comprobante de pago del préstamo (adjunto .txt del BCR).
 *
 * Formato real del BCR: "RECIBO POR PAGO DE PRESTAMOS" (RECIBOPAGOPRESTAMO.TXT).
 * Si llega otro formato, se intenta con el lector general de más abajo.
 *
 * Usa convertirNumero() de Parser.js.
 */

var ETIQUETAS_PRESTAMO = {
  comprobante: /(n[uú]mero\s+de\s+)?(comprobante|transacci[oó]n|referencia|documento|recibo)\b/i,
  principal: /(amortizaci[oó]n|principal|capital|abono\s+a\s+principal)/i,
  intereses: /inter[eé]s(es)?/i,
  polizas: /(p[oó]liza|seguro|desgravamen|incendio)/i,
  total: /(total|monto\s+pagado|monto\s+del\s+pago|monto\s+total)/i,
  fecha: /fecha/i
};

/** Montos que aparecen en una línea (ignora porcentajes y números largos tipo cuenta). */
function montosEnLinea_(linea) {
  var sinPct = linea.replace(/\d+(?:[.,]\d+)?\s*%/g, ' ');
  var re = /(?:₡|¢|CRC|\$|USD)?\s*(\d{1,3}(?:[.,\s]\d{3})+(?:[.,]\d{1,2})?|\d+[.,]\d{1,2})(?!\d)/g;
  var out = [], m;
  while ((m = re.exec(sinPct)) !== null) {
    var n = convertirNumero(m[1]);
    if (n !== null) out.push(n);
  }
  return out;
}

function fechaEnTexto_(texto) {
  var m = texto.match(/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/);
  if (m) {
    var a = +m[3]; if (a < 100) a += 2000;
    return new Date(Date.UTC(a, +m[2] - 1, +m[1], 12, 0));
  }
  m = texto.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (m) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 12, 0));
  return null;
}


/** Recibo real del BCR (RECIBOPAGOPRESTAMO.TXT). Devuelve null si no es ese formato. */
function parsearReciboBCR(texto) {
  var t = String(texto).replace(/\r/g, '');
  if (!/RECIBO POR PAGO DE PRESTAMOS/i.test(t)) return null;
  var n = function (re) { var m = t.match(re); return m ? convertirNumero(m[1]) || 0 : 0; };
  var s = function (re) { var m = t.match(re); return m ? m[1].trim() : ''; };
  var f = t.match(/Fecha\/Hora:\s*(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})(?:\s+(\d{1,2}):(\d{2}))?/i);
  if (!f) return null;
  var polizasOtros = 0, re = /^\s*POL[^\n]*?\s([\d,]+\.\d{2})\s*$/gim, m;
  while ((m = re.exec(t)) !== null) polizasOtros += convertirNumero(m[1]) || 0;
  var capital = n(/Capital Cuota\s+([\d,]+\.\d{2})/i), extra = n(/Abono Extraord\.?\s+([\d,]+\.\d{2})/i);
  var intereses = n(/^\s*Intereses\s+([\d,]+\.\d{2})/im) + n(/Ints Moratorio\s+([\d,]+\.\d{2})/i) +
    n(/Comis\.Atraso\s+([\d,]+\.\d{2})/i) + n(/Comis\.Pag\.Ant\.?\s+([\d,]+\.\d{2})/i);
  var polizas = n(/^\s*Polizas\s+([\d,]+\.\d{2})/im) + polizasOtros;
  var r = {
    fecha: new Date(Date.UTC(+f[3], +f[2] - 1, +f[1], +(f[4] || 12) + 6, +(f[5] || 0))),
    comprobante: s(/Numero de Recibo:\s*(\d+)/i), cuota: Number(s(/Numero de Cuota:\s*(\d+)/i)) || null,
    principal: capital + extra, abonoExtra: extra, intereses: intereses, polizas: polizas,
    total: n(/Total al Cobro\s*:\s*([\d,]+\.\d{2})/i), saldoAnterior: n(/SALDO ANTERIOR\s*:\s*([\d,]+\.\d{2})/i),
    saldoNuevo: n(/NUEVO SALDO\s*:\s*([\d,]+\.\d{2})/i), tasa: (parseFloat(s(/Tasa de interes\s*:\s*([\d.]+)/i)) || 0) / 100,
    cuotasPendientes: Number(s(/Cuotas Pend\.Pago:\s*(\d+)/i)) || null, proximoVenc: null
  };
  var px = t.match(/F-Vence Prox Cuota[;:]\s*(\d{1,2})-(\d{1,2})-(\d{4})/i);
  if (px) r.proximoVenc = new Date(Date.UTC(+px[3], +px[2] - 1, +px[1], 12, 0));
  ['principal', 'abonoExtra', 'intereses', 'polizas', 'total'].forEach(function (k) { r[k] = Math.round(r[k] * 100) / 100; });
  if (!r.total) r.total = Math.round((r.principal + r.intereses + r.polizas) * 100) / 100;
  return r.principal || r.intereses ? r : null;
}

/** ¿Es el estado de cuenta mensual (OP_….TXT)? Ese no se anota. */
function esEstadoCuentaPrestamo(texto) { return /ESTADO DE CUENTA DETALLADO DEL CREDITO/i.test(String(texto)); }

/**
 * Devuelve { fecha, comprobante, principal, intereses, polizas, total } o null.
 * `fechaCorreo` se usa si el texto no trae fecha.
 */
function parsearComprobantePrestamo(texto, fechaCorreo) {
  var recibo = parsearReciboBCR(texto);
  if (recibo) return recibo;
  var lineas = String(texto).replace(/\r/g, '').replace(/ /g, ' ').split('\n');
  var r = { fecha: null, comprobante: null, principal: 0, intereses: 0, polizas: 0, total: null };
  var vistos = { principal: false, intereses: false, polizas: false };

  lineas.forEach(function (l) {
    var linea = l.trim();
    if (!linea) return;
    var low = linea.toLowerCase();

    if (!r.fecha && ETIQUETAS_PRESTAMO.fecha.test(linea)) r.fecha = fechaEnTexto_(linea);

    if (!r.comprobante && ETIQUETAS_PRESTAMO.comprobante.test(linea)) {
      var c = linea.match(/[:#\-]?\s*([A-Z0-9]{5,20})\s*$/i);
      if (c && /\d/.test(c[1])) r.comprobante = c[1];
    }

    var montos = montosEnLinea_(linea);
    if (montos.length === 0) return;
    var valor = montos[montos.length - 1];          // el monto suele ir al final de la línea

    if (/tasa/.test(low)) return;                    // "Tasa de interés 6,56%"
    if (/saldo/.test(low)) return;                   // "Saldo anterior / nuevo saldo"
    if (ETIQUETAS_PRESTAMO.total.test(linea) && !ETIQUETAS_PRESTAMO.intereses.test(linea)) {
      r.total = valor; return;
    }
    if (ETIQUETAS_PRESTAMO.intereses.test(linea)) { r.intereses += valor; vistos.intereses = true; return; }
    if (ETIQUETAS_PRESTAMO.polizas.test(linea)) { r.polizas += valor; vistos.polizas = true; return; }
    if (ETIQUETAS_PRESTAMO.principal.test(linea)) { r.principal += valor; vistos.principal = true; return; }
  });

  if (!vistos.principal && r.total !== null) {
    r.principal = Math.round((r.total - r.intereses - r.polizas) * 100) / 100;
    vistos.principal = r.principal > 0;
  }
  if (!vistos.principal || !vistos.intereses) return null;
  if (r.principal + r.intereses <= 0) return null;   // sin capital ni intereses no es un pago (ej. estado de cuenta)
  r.fecha = r.fecha || fechaCorreo || new Date();
  if (r.total === null) r.total = r.principal + r.intereses + r.polizas;
  ['principal', 'intereses', 'polizas', 'total'].forEach(function (k) { r[k] = Math.round(r[k] * 100) / 100; });
  return r;
}

if (typeof module !== 'undefined') {
  module.exports = { parsearComprobantePrestamo: parsearComprobantePrestamo, parsearReciboBCR: parsearReciboBCR, esEstadoCuentaPrestamo: esEstadoCuentaPrestamo };
}
