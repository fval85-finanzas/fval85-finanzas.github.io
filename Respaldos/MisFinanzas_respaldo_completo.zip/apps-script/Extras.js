/**
 * Extras.js (v2.5) — preferencias, avisos (resumen por correo y llave del teléfono),
 * actualización automática del servidor y listas "Super y Otros" (compartibles por link).
 */

// ---------------------------------------------------------------------
// PREFERENCIAS (salario, avisos…) guardadas en Propiedades del script
// ---------------------------------------------------------------------
function prefs_() { try { return JSON.parse(props_().getProperty('PREFS') || '{}'); } catch (e) { return {}; } }

function guardarPreferencias_(parcial) {
  var p = prefs_();
  Object.keys(parcial || {}).forEach(function (k) { p[k] = parcial[k]; });
  props_().setProperty('PREFS', JSON.stringify(p));
  if (parcial && parcial.avisos) configurarAvisoCorreo_(p.avisos);
  return p;
}

// ---------------------------------------------------------------------
// AVISOS
// ---------------------------------------------------------------------
/** Lo que hay que avisar hoy (solo conteos y nombres; lo usa el teléfono y el correo). */
function resumenAvisos_() {
  var d = JSON.parse(obtenerDatos_()), hoy = new Date(), mes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
  var r = { porAsignar: 0, porRevisar: 0, pagos: [], negativos: [], salarioHoy: false, consultas: 0 };
  try { r.porRevisar = Calc.resumenMes(d, mes).porRevisar || 0; } catch (e) { /* sin datos */ }
  if (d.sobresDesde) {
    try {
      var sb = Calc.saldosSobres(d, mes, hoy);
      r.porAsignar = sb.pendientes.length;
      r.negativos = sb.lista.filter(function (s) { return s.saldo < -0.005; }).map(function (s) { return s.nombre; });
    } catch (e2) { /* sin sobres */ }
  }
  // v2.9.0: pagos de los próximos 7 días con monto; "avisar" solo los días elegidos (3, 1 y el día) y si no se ha pagado
  var pf = prefs_(), diasAv = (pf.avisos && pf.avisos.diasPago) || [3, 1, 0];
  try {
    var hoy0p = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
    r.semana = Calc.pagosProximos(d, hoy0p, diasAv, 7);
    r.pagos = r.semana.filter(function (p) { return p.avisar; });
  } catch (e4) {
    (d.cuentas || []).forEach(function (c) {
      if (!c.activa || c.tipo !== 'Tarjeta de crédito' || !c.diaPago) return;
      var dias = diasHasta_(proximoDia_(c.diaPago));
      if (diasAv.indexOf(dias) >= 0) r.pagos.push({ nombre: c.nombre, dias: dias, avisar: true });
    });
  }
  // v2.10.0: viaje en curso → resumen diario (ayer gastaste, quedan, por día, categorías pasadas)
  try {
    var hoyV = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate(), 12);
    r.viajes = (d.viajes || []).filter(function (v) { return v.activo && v.desde && v.hasta; }).map(function (v) {
      var x = Calc.viaje(d, v, hoyV);
      if (x.estado !== 'En curso') return null;
      var pasadas = x.presupuesto ? Object.keys(x.presupuesto).filter(function (c) { return x.presupuesto[c].gastado > x.presupuesto[c].limite + 0.004; }).map(function (c) { return { cat: c, exceso: Math.round((x.presupuesto[c].gastado - x.presupuesto[c].limite) * 100) / 100 }; }) : [];
      return { nombre: v.nombre, dia: x.diaActual, dias: x.diasTotal, ayer: Math.round(x.ayer * 100) / 100, porCatAyer: x.porCatAyer, quedan: Math.round(x.disponible * 100) / 100,
        porDia: Math.round(x.porDia * 100) / 100, restantes: x.diasRestantes, moneda: x.moneda, pasadas: pasadas };
    }).filter(Boolean);
  } catch (e5) { r.viajes = []; r.errViajes = String(e5); }
  // v2.12.0 (#53): presupuesto → categorías al 80% o pasadas
  try {
    var dP = Object.assign({}, d, { presupuesto: pf.presupuesto || {}, familia: pf.familia || {} });
    var pr = Calc.presupuesto(dP, new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate(), 12), { salario: pf.salario });
    r.presupuesto = pr.cats.filter(function (c) { return c.pct >= 0.8; }).map(function (c) {
      return { cat: c.cat, nivel: c.pct > 1.0001 ? 100 : 80, pct: Math.round(c.pct * 100), gastado: Math.round(c.gastado), limite: Math.round(c.limite), quedan: Math.round(c.quedan), faltan: pr.periodo.faltan, periodo: pr.periodo.ini.getFullYear() + '-' + (pr.periodo.ini.getMonth() + 1) + '-' + pr.periodo.ini.getDate() };
    });
  } catch (e6) { r.presupuesto = []; r.errPresupuesto = String(e6); }
  var sal = pf.salario || null;
  if (sal && sal.activo) {
    var hoy0 = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
    r.salarioHoy = Calc.fechasSalario(sal, hoy0, hoy0).length > 0;
  }
  try { listasDatos_().forEach(function (l) { (l.datos.items || []).forEach(function (it) { if (it.consulta && !it.consulta.resp) r.consultas++; }); }); } catch (e3) { /* sin listas */ }
  return r;
}

/** El teléfono guarda una llave que solo sirve para pedir resumenAvisos (funciona aunque haya PIN). */
function activarAvisosTelefono_() {
  var llave = Utilities.getUuid() + Utilities.getUuid(), sal = Utilities.getUuid();
  var l = llavesAvisos_(); l.push({ s: sal, h: hash_(llave, sal), c: new Date().toISOString() });
  props_().setProperty('AVISOS_LLAVES', JSON.stringify(l.slice(-5)));
  return llave;
}
function llavesAvisos_() { try { return JSON.parse(props_().getProperty('AVISOS_LLAVES') || '[]'); } catch (e) { return []; } }
function llaveAvisosValida_(llave) { return !!llave && llavesAvisos_().some(function (x) { return hash_(String(llave), x.s) === x.h; }); }

/** Instala (o quita) el activador cada hora que manda el resumen a la hora elegida. */
function configurarAvisoCorreo_(av) {
  var activo = !!(av && av.correo && av.correo.activo);
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'avisoCorreoHora') ScriptApp.deleteTrigger(t); });
  if (activo) { ScriptApp.newTrigger('avisoCorreoHora').timeBased().everyHours(1).create(); props_().setProperty('RECORDATORIOS', 'no'); }
}

/** Corre cada hora: si es la hora elegida y hoy no se mandó, manda el resumen. */
function avisoCorreoHora() {
  var av = prefs_().avisos || {}, c = av.correo || {};
  if (!c.activo) return;
  var tz = 'America/Costa_Rica', ahora = new Date();
  var horaCR = Number(Utilities.formatDate(ahora, tz, 'H')), hoyTxt = Utilities.formatDate(ahora, tz, 'yyyy-MM-dd');
  if (horaCR !== Number(c.hora === undefined ? 20 : c.hora) || props_().getProperty('AVISO_ENVIADO') === hoyTxt) return;
  props_().setProperty('AVISO_ENVIADO', hoyTxt);
  enviarResumenCorreo_(false);
}

var DIAS_C_ = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
function dinCorreo_(n, mon) {
  var v = Math.abs(Number(n) || 0), ent = Math.floor(v), dec = Math.round((v - ent) * 100);
  if (dec === 100) { ent++; dec = 0; }
  return (mon === 'USD' ? '$' : '₡') + String(ent).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + (dec || mon === 'USD' ? ',' + ('0' + dec).slice(-2) : '');
}
function enviarResumenCorreo_(prueba) {
  var av = prefs_().avisos || {}, tipos = av.tipos || {}, c = av.correo || {};
  var r = resumenAvisos_(), lineas = [];
  var si = function (k) { return tipos[k] !== false; };
  if (si('asignar') && r.porAsignar) lineas.push('✉ ' + r.porAsignar + ' movimiento' + (r.porAsignar === 1 ? '' : 's') + ' por asignar a sobres');
  if (si('revisar') && r.porRevisar) lineas.push('⚠ ' + r.porRevisar + ' por revisar (sin categoría)');
  if (si('salario') && r.salarioHoy) lineas.push('💰 Hoy es día de salario: confirmalo en la app y repartilo');
  var semana = si('tarjeta') ? (r.semana || r.pagos) : [];
  if (si('negativo') && r.negativos.length) lineas.push('🔴 Sobre en negativo: ' + r.negativos.join(', '));
  if (si('viaje')) (r.viajes || []).forEach(function (v) {
    var cats = Object.keys(v.porCatAyer || {}).map(function (c) { return c + ' ' + dinCorreo_(v.porCatAyer[c], v.moneda); }).join(' · ');
    lineas.push('✈ ' + v.nombre + ' · día ' + v.dia + ' de ' + v.dias + ': ayer ' + dinCorreo_(v.ayer, v.moneda) + (cats ? ' (' + cats + ')' : '') + '. Quedan ' + dinCorreo_(v.quedan, v.moneda) + (v.restantes ? ' · ' + dinCorreo_(v.porDia, v.moneda) + ' por día' : '') +
      (v.pasadas.length ? '. Se pasó: ' + v.pasadas.map(function (p) { return p.cat + ' ' + dinCorreo_(p.exceso, v.moneda); }).join(', ') : ''));
  });
  if (si('presupuesto')) (r.presupuesto || []).forEach(function (b) {
    lineas.push('📊 Presupuesto · ' + b.cat + (b.nivel === 100 ? ': te pasaste por ' + dinCorreo_(-b.quedan, 'CRC') : ' al ' + b.pct + '%: quedan ' + dinCorreo_(b.quedan, 'CRC') + ' para ' + b.faltan + ' día' + (b.faltan === 1 ? '' : 's')) + ' (' + dinCorreo_(b.gastado, 'CRC') + ' de ' + dinCorreo_(b.limite, 'CRC') + ')');
  });
  if (si('super') && r.consultas) lineas.push('🛒 ' + r.consultas + ' pregunta' + (r.consultas === 1 ? '' : 's') + ' “¿este sirve?” sin responder');
  try { var viejos = avisosRecordatorio_(); lineas = lineas.concat(viejos.filter(function (x) { return !/^💳/.test(x); })); } catch (e) { /* sin préstamo */ }
  var porPagar = semana.filter(function (p) { return p.debe !== false && !p.pagado; });
  if (!lineas.length && !porPagar.length && !prueba && !c.siempre) return 'Nada que avisar.';
  // v2.9.0: tabla de pagos de los próximos 7 días con su monto
  var tPagos = semana.map(function (p) {
    var f = p.fecha ? new Date(p.fecha) : null, cuando = p.dias === 0 ? 'HOY' : p.dias === 1 ? 'mañana' : f ? DIAS_C_[f.getDay()] + ' ' + f.getDate() : 'en ' + p.dias + ' días';
    var monto = p.CRC === undefined ? '' : !p.debe ? (p.CRC < -0.004 ? 'a favor ' + dinCorreo_(p.CRC, 'CRC') : p.USD < -0.004 ? 'a favor ' + dinCorreo_(p.USD, 'USD') : p.pagado ? 'ya pagado ✓' : 'nada por pagar')
      : [p.CRC > 0.004 ? dinCorreo_(p.CRC, 'CRC') : '', p.USD > 0.004 ? dinCorreo_(p.USD, 'USD') : ''].filter(String).join(' + ');
    return { nombre: p.nombre, cuando: cuando, monto: monto, urg: p.dias <= 1 && p.debe !== false && !p.pagado };
  });
  var titulo = porPagar.length ? 'Pagos de esta semana · ' + porPagar.length + ' tarjeta' + (porPagar.length === 1 ? '' : 's') : 'Finanzas · resumen del día';
  var texto = (tPagos.length ? 'Pagos de los próximos 7 días:\n' + tPagos.map(function (x) { return '• ' + x.nombre + ' · ' + x.cuando + ' · ' + x.monto; }).join('\n') + '\n\n' : '') +
    (lineas.length ? lineas.join('\n') : (tPagos.length ? '' : 'Todo al día ✓')) + '\n\nAbrí la app para verlo: ' + (av.urlApp || '') + '\n— Finanzas';
  var e = function (x) { return String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
  var html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#222;max-width:520px">' +
    (tPagos.length ? '<div style="font-weight:bold;font-size:16px;margin:0 0 8px">' + e(porPagar.length ? titulo : 'Pagos de los próximos 7 días') + '</div><table style="width:100%;border-collapse:collapse;font-size:14px">' + tPagos.map(function (x) {
      return '<tr><td style="padding:6px 0;border-bottom:1px solid #eee">' + e(x.nombre) + '</td><td style="padding:6px 8px;border-bottom:1px solid #eee;color:' + (x.urg ? '#c0392b;font-weight:bold' : '#777') + '">' + e(x.cuando) + '</td><td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;font-weight:bold">' + e(x.monto) + '</td></tr>';
    }).join('') + '</table>' : '') +
    (lineas.length ? '<div style="margin-top:12px;color:#555;font-size:13px">' + (tPagos.length ? 'También:<br>' : '') + lineas.map(e).join('<br>') + '</div>' : (tPagos.length ? '' : '<div>Todo al día ✓</div>')) +
    (av.urlApp ? '<div style="margin-top:14px"><a href="' + e(av.urlApp) + '" style="display:inline-block;background:#F5B82E;color:#111;text-decoration:none;font-weight:bold;padding:10px 18px;border-radius:10px">Abrir la app</a></div>' : '') + '</div>';
  MailApp.sendEmail({ to: Session.getEffectiveUser().getEmail(), subject: (prueba ? '[Prueba] ' : '') + titulo, body: texto, htmlBody: html });
  return prueba ? 'Te envié un resumen de prueba.' : 'Resumen enviado.';
}

// ---------------------------------------------------------------------
// ACTUALIZACIÓN AUTOMÁTICA DEL SERVIDOR (API de Apps Script)
// La URL de donde se baja el código se guarda UNA vez (no se puede cambiar desde la app).
// ---------------------------------------------------------------------
function estadoActualizacion_() {
  var p = props_();
  return { base: p.getProperty('URL_ACTUALIZACION') || '', anterior: Number(p.getProperty('VERSION_ANTERIOR')) || null, version: VERSION_APP };
}

function fijarUrlActualizacion_(base) {
  var p = props_(), actual = p.getProperty('URL_ACTUALIZACION');
  base = String(base || '').replace(/[#?].*$/, '').replace(/[^/]*$/, '');
  if (!/^https:\/\/[a-z0-9-]+\.github\.io\//i.test(base)) throw new Error('La dirección de la app debe ser una página de GitHub (https://…github.io/…).');
  if (actual && actual !== base) throw new Error('Ya hay otra dirección guardada. Para cambiarla, en Apps Script ejecutá borrarUrlActualizacion.');
  p.setProperty('URL_ACTUALIZACION', base);
  return base;
}

/**
 * v2.5.5: ejecutar UNA vez desde el editor (▶ Ejecutar) para dar los permisos que usa "Actualizar servidor":
 * conectarse a internet (UrlFetchApp) y manejar las implementaciones. En la ventana de Google marcá "Seleccionar todo".
 */
function autorizarActualizaciones() {
  UrlFetchApp.fetch('https://www.google.com/generate_204', { muteHttpExceptions: true });
  var token = ScriptApp.getOAuthToken();
  var r = UrlFetchApp.fetch('https://script.googleapis.com/v1/projects/' + ScriptApp.getScriptId() + '/deployments', { muteHttpExceptions: true, headers: { Authorization: 'Bearer ' + token } });
  console.log(r.getResponseCode() < 300 ? '✅ Listo: permisos dados. Volvé a la app → Ajustes → Actualizaciones → Buscar actualizaciones.'
    : 'Permisos dados, pero Google respondió: ' + r.getContentText().slice(0, 300) + ' (si dice que la API está desactivada, encendela en script.google.com/home/usersettings)');
}

/** Para cambiar de dónde se actualiza (solo desde el editor de Apps Script). */
function borrarUrlActualizacion() { props_().deleteProperty('URL_ACTUALIZACION'); console.log('Listo: la próxima actualización desde la app guarda la dirección de nuevo.'); }

function apiScript_(metodo, ruta, cuerpo) {
  var r = UrlFetchApp.fetch('https://script.googleapis.com/v1/' + ruta, {
    method: metodo, contentType: 'application/json', muteHttpExceptions: true,
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, payload: cuerpo ? JSON.stringify(cuerpo) : undefined
  });
  var t = r.getContentText(), j = {};
  try { j = JSON.parse(t || '{}'); } catch (e) { j = {}; }
  if (r.getResponseCode() >= 300) {
    var m = (j.error && j.error.message) || t.slice(0, 200);
    if (/has not been used|is disabled|User has not enabled the Apps Script API/i.test(m)) throw new Error('API_DESACTIVADA');
    if (r.getResponseCode() === 403 || /insufficient|scope/i.test(m)) throw new Error('PERMISO_FALTA: ' + m);
    throw new Error(m);
  }
  return j;
}

function idImplementacion_() {
  var u = ScriptApp.getService().getUrl() || '';
  var m = u.match(/\/macros\/s\/([^/]+)\//);
  return m ? m[1] : '';
}

/** Revisa si hay versión nueva publicada (no instala nada). */
function revisarActualizacion_() {
  var base = props_().getProperty('URL_ACTUALIZACION');
  if (!base) return { configurado: false, version: VERSION_APP };
  var v = JSON.parse(UrlFetchApp.fetch(base + 'version.json?t=' + Date.now(), { muteHttpExceptions: true }).getContentText() || '{}');
  return { configurado: true, version: VERSION_APP, nueva: v.servidor || null, hay: !!v.servidor && compararVersion_(v.servidor, VERSION_APP) > 0, novedades: v.novedades || '' };
}

function compararVersion_(a, b) {
  var x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (var i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); }
  return 0;
}

/** Baja el código nuevo, lo verifica, guarda cuál versión estaba y actualiza la MISMA implementación (la URL /exec no cambia). */
function actualizarServidor_() {
  return conBloqueo_(function () {
    var base = props_().getProperty('URL_ACTUALIZACION');
    if (!base) throw new Error('SIN_URL');
    var v = JSON.parse(UrlFetchApp.fetch(base + 'version.json?t=' + Date.now()).getContentText());
    if (!v.servidor || compararVersion_(v.servidor, VERSION_APP) <= 0) return { ok: true, version: VERSION_APP, nada: true };
    var codigo = UrlFetchApp.fetch(base + 'servidor/Codigo.gs?t=' + Date.now()).getContentText('UTF-8');
    var sha = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, codigo, Utilities.Charset.UTF_8)
      .map(function (b) { return ('0' + (b & 255).toString(16)).slice(-2); }).join('');
    if (v.sha256 && sha !== v.sha256) throw new Error('El código descargado no coincide con la versión publicada. No se instaló nada.');
    if (codigo.indexOf("VERSION_APP = '" + v.servidor + "'") < 0) throw new Error('El código descargado no es la versión ' + v.servidor + '. No se instaló nada.');
    var id = ScriptApp.getScriptId(), dep = idImplementacion_();
    if (!dep) throw new Error('No encuentro la implementación (¿la app se abre con la URL /exec?).');
    var contenido = apiScript_('get', 'projects/' + id + '/content');
    var archivos = (contenido.files || []).map(function (f) { return { name: f.name, type: f.type, source: f.source }; }), puesto = false;
    archivos.forEach(function (f) { if (f.type === 'SERVER_JS' && !puesto && f.source.indexOf('VERSION_APP') >= 0) { f.source = codigo; puesto = true; } });
    if (!puesto) archivos.forEach(function (f) { if (f.type === 'SERVER_JS' && !puesto) { f.source = codigo; puesto = true; } });
    if (v.manifiesto) archivos.forEach(function (f) { if (f.name === 'appsscript' && f.type === 'JSON') f.source = JSON.stringify(v.manifiesto, null, 2); });
    var actual = apiScript_('get', 'projects/' + id + '/deployments/' + dep);
    var anterior = actual.deploymentConfig && actual.deploymentConfig.versionNumber;
    apiScript_('put', 'projects/' + id + '/content', { files: archivos });
    var nueva = apiScript_('post', 'projects/' + id + '/versions', { description: 'Finanzas ' + v.servidor + ' (desde la app)' });
    apiScript_('put', 'projects/' + id + '/deployments/' + dep, { deploymentConfig: {
      scriptId: id, versionNumber: nueva.versionNumber, manifestFileName: 'appsscript', description: 'Finanzas ' + v.servidor } });
    if (anterior) props_().setProperty('VERSION_ANTERIOR', String(anterior));
    return { ok: true, version: v.servidor, anterior: anterior || null };
  });
}

/** Vuelve la implementación a la versión que estaba antes de la última actualización. */
function volverVersionAnterior_() {
  var ant = Number(props_().getProperty('VERSION_ANTERIOR'));
  if (!ant) throw new Error('No hay una versión anterior guardada.');
  var id = ScriptApp.getScriptId(), dep = idImplementacion_();
  apiScript_('put', 'projects/' + id + '/deployments/' + dep, { deploymentConfig: { scriptId: id, versionNumber: ant, manifestFileName: 'appsscript', description: 'Finanzas (versión anterior)' } });
  props_().deleteProperty('VERSION_ANTERIOR');
  return { ok: true, versionNumber: ant };
}

// ---------------------------------------------------------------------
// SUPER Y OTROS: listas con cantidades, compartibles por link (token propio por lista)
// ---------------------------------------------------------------------
var ENC_LISTAS = ['ID', 'Nombre', 'Ícono', 'Token', 'Editable', 'Versión', 'Datos', 'Actualizado'];
var ENC_FOTOS = ['ID', 'Lista', 'Datos', 'Creada'];

function hojaSimple_(nombre, enc) {
  var l = libro_(), h = l.getSheetByName(nombre);
  if (!h) {
    h = l.insertSheet(nombre);
    h.getRange(1, 1, 1, enc.length).setValues([enc]).setFontWeight('bold');
    h.setFrozenRows(1);
  }
  return h;
}

function listasDatos_() {
  var h = hojaSimple_('Listas', ENC_LISTAS), n = h.getLastRow() - 1;
  if (n < 1) return [];
  return h.getRange(2, 1, n, ENC_LISTAS.length).getValues().map(function (r, i) {
    if (!r[0]) return null;
    var datos = {}; try { datos = JSON.parse(r[6] || '{}'); } catch (e) { datos = {}; }
    return { fila: i + 2, id: String(r[0]), nombre: String(r[1]), icono: String(r[2] || '🛒'), token: String(r[3] || ''), editable: r[4] !== 'No', v: Number(r[5]) || 0, datos: datos };
  }).filter(Boolean);
}

function listaPor_(campo, valor) {
  return listasDatos_().filter(function (l) { return valor && l[campo] === String(valor); })[0] || null;
}

function guardarListaFila_(l) {
  var h = hojaSimple_('Listas', ENC_LISTAS);
  l.v = (l.v || 0) + 1;
  var fila = [l.id, l.nombre, l.icono, l.token || '', l.editable === false ? 'No' : 'Sí', l.v, JSON.stringify(l.datos || { items: [] }), new Date()];
  if (l.fila) h.getRange(l.fila, 1, 1, fila.length).setValues([fila]);
  else { h.appendRow(fila); l.fila = h.getLastRow(); }
  CacheService.getScriptCache().put('lista_v_' + l.id, String(l.v), 21600);
  return l;
}

/** Lo que ve el teléfono (sin el token si viene por link). */
function vistaLista_(l, conToken) {
  return { id: l.id, nombre: l.nombre, icono: l.icono, editable: l.editable, v: l.v, items: (l.datos.items || []), cambio: l.datos.cambio || null,
    tipo: l.datos.tipo || 'super', personas: l.datos.personas || [], encargantes: l.datos.encargantes || [],
    token: conToken ? (l.token || '') : undefined };
}

function listasResumen_() {
  return listasDatos_().map(function (l) {
    var it = l.datos.items || [];
    return { id: l.id, nombre: l.nombre, icono: l.icono, compartida: !!l.token, total: it.length, marcados: it.filter(function (x) { return x.on; }).length, tipo: l.datos.tipo || 'super',
      consultas: it.filter(function (x) { return x.consulta && !x.consulta.resp; }).length, v: l.v };
  });
}

function crearLista_(nombre, icono, items, opc) {
  return conBloqueo_(function () {
    opc = opc || {};
    var l = { id: Utilities.getUuid().slice(0, 8), nombre: String(nombre || 'Lista').slice(0, 60), icono: String(icono || '🛒').slice(0, 4), token: '', editable: true, v: 0,
      datos: { items: (items || []).map(limpiarItem_).filter(Boolean), tipo: opc.tipo === 'tiendas' ? 'tiendas' : 'super', personas: limpiarPersonas_(opc.personas) } };
    return vistaLista_(guardarListaFila_(l), true);
  });
}

function limpiarItem_(it) {
  if (!it || !String(it.n || '').trim()) return null;
  return { id: String(it.id || Utilities.getUuid().slice(0, 8)), n: String(it.n).trim().slice(0, 80), q: it.q === '' || it.q === undefined || it.q === null ? '' : Number(it.q) || '',
    u: String(it.u || '').slice(0, 10), p: String(it.p || '').slice(0, 30), nota: String(it.nota || '').slice(0, 140), foto: it.foto ? String(it.foto) : '',
    on: !!it.on, por: it.por ? String(it.por).slice(0, 30) : '', estado: it.estado === 'nohay' ? 'nohay' : '', consulta: it.consulta || null,
    // v2.10.4: listas de tiendas
    para: String(it.para || '').slice(0, 30), talla: String(it.talla || '').slice(0, 12), color: String(it.color || '').slice(0, 20), tienda: String(it.tienda || '').slice(0, 40),
    max: Number(it.max) > 0 ? Math.round(Number(it.max) * 100) / 100 : '', pagado: Number(it.pagado) > 0 ? Math.round(Number(it.pagado) * 100) / 100 : '',
    // v2.10.5: encargos (de parte de quién, con qué se pagó, movimiento ligado)
    enc: String(it.enc || '').slice(0, 40), medio: String(it.medio || '').slice(0, 60), mov: Number(it.mov) > 0 ? Number(it.mov) : '' };
}
function limpiarPersonas_(l) { return (Array.isArray(l) ? l : []).map(function (x) { return String(x || '').trim().slice(0, 30); }).filter(String).slice(0, 10); }

function obtenerLista_(id, vConocida) {
  var vc = CacheService.getScriptCache().get('lista_v_' + id);
  if (vConocida && vc && Number(vc) === Number(vConocida)) return { sinCambios: true, v: Number(vc) };
  var l = listaPor_('id', id);
  if (!l) throw new Error('Esa lista ya no existe.');
  return vistaLista_(l, true);
}

/** Cambios en una lista. Cada cambio se aplica sobre la versión más nueva (varias personas a la vez). */
function cambiarLista_(id, op, quien, porLink) {
  return conBloqueo_(function () {
    var l = listaPor_('id', id);
    if (!l) throw new Error('Esa lista ya no existe.');
    var items = l.datos.items || [], it = op.item ? items.filter(function (x) { return x.id === op.item; })[0] : null;
    var nombre = String(quien || '').slice(0, 30) || 'Alguien';
    var soloMarcar = { marcar: 1, nohay: 1, consulta: 1, responder: 1, pagado: 1, ligar: 1 };
    if (porLink && !l.editable && !soloMarcar[op.t]) throw new Error('En esta lista solo podés marcar.');
    var cambio = '';
    if (op.t === 'marcar' && it) { it.on = !!op.on; it.por = op.on ? nombre : ''; if (op.on) it.estado = ''; if (!op.on) it.pagado = ''; cambio = nombre + (op.on ? ' marcó ' : ' desmarcó ') + it.n; }
    else if (op.t === 'pagado' && it) { it.pagado = Number(op.monto) > 0 ? Math.round(Number(op.monto) * 100) / 100 : ''; if (op.medio !== undefined) it.medio = String(op.medio || '').slice(0, 60); if (it.pagado && !it.on) { it.on = true; it.por = nombre; } cambio = nombre + ' pagó ' + it.n; }
    else if (op.t === 'encargante' && op.datos && String(op.datos.n || '').trim()) {
      var lst = l.datos.encargantes || [], nn = String(op.datos.n).trim().slice(0, 40), e0 = lst.filter(function (e) { return e.n === (op.antes || nn); })[0];
      var d0 = { n: nn, adelanto: Number(op.datos.adelanto) > 0 ? Math.round(Number(op.datos.adelanto) * 100) / 100 : 0, moneda: op.datos.moneda === 'CRC' ? 'CRC' : 'USD', estado: ['', 'entregado', 'cobrado', 'medeben'].indexOf(op.datos.estado) >= 0 ? op.datos.estado : '' };
      if (e0) { if (op.antes && op.antes !== nn) items.forEach(function (x) { if (x.enc === op.antes) x.enc = nn; }); lst[lst.indexOf(e0)] = Object.assign({}, e0, d0); } else lst.push(d0);
      l.datos.encargantes = lst.slice(0, 30); cambio = nombre + ': encargos de ' + nn;
    }
    else if (op.t === 'quitarEncargante' && op.n) { l.datos.encargantes = (l.datos.encargantes || []).filter(function (e) { return e.n !== op.n; }); items = items.filter(function (x) { return x.enc !== op.n; }); cambio = nombre + ' quitó los encargos de ' + op.n; }
    else if (op.t === 'personas') { l.datos.personas = limpiarPersonas_(op.personas); }
    else if (op.t === 'nohay' && it) { it.estado = 'nohay'; it.on = false; it.por = nombre; cambio = nombre + ': no hay ' + it.n; }
    else if (op.t === 'agregar') { var nuevo = limpiarItem_(op.datos); if (nuevo) { items.push(nuevo); cambio = nombre + ' agregó ' + nuevo.n; } }
    else if (op.t === 'editar' && it) {
      var d = limpiarItem_(Object.assign({}, it, op.datos, { id: it.id }));
      if (it.foto && d.foto !== it.foto) borrarFoto_(it.foto);
      items[items.indexOf(it)] = d; cambio = nombre + ' cambió ' + d.n;
    }
    else if (op.t === 'quitar' && it) { if (it.foto) borrarFoto_(it.foto); if (it.consulta && it.consulta.foto) borrarFoto_(it.consulta.foto); items.splice(items.indexOf(it), 1); cambio = nombre + ' quitó ' + it.n; }
    else if (op.t === 'consulta' && it) { it.consulta = { foto: String(op.foto || ''), msg: String(op.msg || '').slice(0, 140), por: nombre, cuando: new Date().toISOString(), resp: null }; cambio = nombre + ' pregunta: ¿este sirve? (' + it.n + ')'; }
    else if (op.t === 'responder' && it && it.consulta) {
      it.consulta.resp = { si: !!op.si, msg: String(op.msg || '').slice(0, 140), por: nombre };
      if (op.si) { it.on = true; it.por = it.consulta.por; it.estado = ''; }
      cambio = nombre + (op.si ? ': sí, llevalo (' : ': no, dejalo (') + it.n + ')';
    }
    else if (op.t === 'terminar') {
      items.forEach(function (x) { if (x.consulta && x.consulta.foto) borrarFoto_(x.consulta.foto); x.consulta = null; });
      var pend = items.filter(function (x) { return !x.on && !x.enc; });
      if (op.pendientes === 'borrar') { pend.forEach(function (x) { if (x.foto) borrarFoto_(x.foto); }); items = items.filter(function (x) { return x.on || x.enc; }); }
      else if (op.pendientes === 'mover' && op.destino) {
        var dest = listaPor_('id', op.destino);
        if (dest && dest.id !== l.id) { dest.datos.items = (dest.datos.items || []).concat(pend.map(function (x) { return limpiarItem_(Object.assign({}, x, { on: false, estado: '', por: '' })); })); guardarListaFila_(dest); items = items.filter(function (x) { return x.on || x.enc; }); }
      }
      items.forEach(function (x) { if (x.enc) return; x.on = false; x.por = ''; x.estado = ''; x.pagado = ''; });   // los encargos se quedan hasta cerrar su cuenta
      cambio = nombre + ' terminó la compra';
    }
    else if (op.t === 'orden' && op.ids) { items.sort(function (a, b) { return op.ids.indexOf(a.id) - op.ids.indexOf(b.id); }); }
    else if (op.t === 'renombrar') { if (op.nombre) l.nombre = String(op.nombre).slice(0, 60); if (op.icono) l.icono = String(op.icono).slice(0, 4); }
    else if (op.t === 'editable' && !porLink) { l.editable = !!op.on; }
    l.datos.items = items;
    if (cambio) l.datos.cambio = { txt: cambio, cuando: new Date().toISOString() };
    return vistaLista_(guardarListaFila_(l), !porLink);
  });
}

function eliminarLista_(id) {
  return conBloqueo_(function () {
    var l = listaPor_('id', id); if (!l) return true;
    (l.datos.items || []).forEach(function (x) { if (x.foto) borrarFoto_(x.foto); if (x.consulta && x.consulta.foto) borrarFoto_(x.consulta.foto); });
    hojaSimple_('Listas', ENC_LISTAS).deleteRow(l.fila);
    return true;
  });
}

/** Crea o cambia el link de una lista (el viejo deja de servir). */
function linkLista_(id, nuevo) {
  return conBloqueo_(function () {
    var l = listaPor_('id', id); if (!l) throw new Error('Esa lista ya no existe.');
    if (!l.token || nuevo) l.token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().slice(0, 8);
    guardarListaFila_(l);
    return { token: l.token, implementacion: idImplementacion_() };
  });
}

function quitarLinkLista_(id) {
  return conBloqueo_(function () { var l = listaPor_('id', id); if (l) { l.token = ''; guardarListaFila_(l); } return true; });
}

// Fotos pequeñas (≈ 25 KB) guardadas como texto en la pestaña "Fotos listas"
function guardarFoto_(listaId, datos) {
  datos = String(datos || '');
  if (!/^data:image\/(jpeg|webp|png);base64,/.test(datos)) throw new Error('Foto no válida.');
  if (datos.length > 48000) throw new Error('La foto es muy grande.');
  var h = hojaSimple_('Fotos listas', ENC_FOTOS), id = 'f' + Utilities.getUuid().slice(0, 10);
  h.appendRow([id, listaId, datos, new Date()]);
  return id;
}
function leerFoto_(id) {
  var cache = CacheService.getScriptCache(), c = cache.get('foto_' + id);
  if (c) return c;
  var h = hojaSimple_('Fotos listas', ENC_FOTOS), f = h.getRange('A:A').createTextFinder(String(id)).matchEntireCell(true).findNext();
  if (!f) return '';
  var d = String(h.getRange(f.getRow(), 3).getValue() || '');
  try { cache.put('foto_' + id, d, 21600); } catch (e) { /* grande */ }
  return d;
}
function borrarFoto_(id) {
  if (!id) return;
  var h = hojaSimple_('Fotos listas', ENC_FOTOS), f = h.getRange('A:A').createTextFinder(String(id)).matchEntireCell(true).findNext();
  if (f && f.getRow() > 1) h.deleteRow(f.getRow());
  CacheService.getScriptCache().remove('foto_' + id);
}

/** Entrada para quien abre el link de una lista (sin la clave de la app). */
function apiListaLink_(token, accion, args) {
  var cache = CacheService.getScriptCache(), fallos = Number(cache.get('link_fallos') || 0);
  if (fallos >= 30) throw new Error('Demasiados intentos. Esperá unos minutos.');
  var l = listaPor_('token', token);
  if (!l || !token || String(token).length < 20) { cache.put('link_fallos', String(fallos + 1), 600); throw new Error('Este link ya no sirve. Pedí uno nuevo.'); }
  args = args || [];
  if (accion === 'ver') { var vc = cache.get('lista_v_' + l.id); if (args[0] && vc && Number(vc) === Number(args[0])) return { sinCambios: true, v: Number(vc) }; return vistaLista_(l, false); }
  if (accion === 'cambiar') return cambiarLista_(l.id, args[0] || {}, args[1], true);
  if (accion === 'foto') {
    var fid = String(args[0] || ''), usada = (l.datos.items || []).some(function (x) { return x.foto === fid || (x.consulta && x.consulta.foto === fid); });
    if (!usada) throw new Error('Foto no encontrada.');
    return leerFoto_(fid);
  }
  if (accion === 'subirFoto') return guardarFoto_(l.id, args[0]);
  throw new Error('Acción no permitida.');
}

// =====================================================================
// v2.18 · App de la casa: un link privado para que otra persona vea (y anote) SOLO el presupuesto por corte
// de una tarjeta (ej. el súper de la casa). Nada más de la app sale por aquí.
// Se guarda en la propiedad CASA: { "<cuenta>": { token, persona, anotar, corregir, creado, ultima } }
// =====================================================================
function casaTodo_() { try { return JSON.parse(props_().getProperty('CASA') || '{}'); } catch (e) { return {}; } }
function casaGuardarTodo_(o) { props_().setProperty('CASA', JSON.stringify(o)); }
function casaCorte_(cuenta) {
  var l = (prefs_().cortes || []).filter(function (c) { return c && c.cuenta === cuenta && c.on !== false; });
  return l[0] || null;
}
function casaEstado_(cuenta) {
  var x = casaTodo_()[cuenta];
  if (!x || !x.token) return { activo: false };
  return { activo: true, token: x.token, persona: x.persona || '', anotar: x.anotar !== false, corregir: x.corregir !== false, creado: x.creado || '', ultima: x.ultima || '', implementacion: idImplementacion_() };
}
/** Crea el link (o uno nuevo: el anterior deja de servir) */
function casaLink_(cuenta, opc) {
  opc = opc || {};
  if (!casaCorte_(cuenta)) throw new Error('Primero activá el presupuesto por corte de esa tarjeta.');
  return conBloqueo_(function () {
    var o = casaTodo_(), x = o[cuenta] || { anotar: true, corregir: true };
    if (!x.token || opc.nuevo) { x.token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().slice(0, 8); x.creado = new Date().toISOString(); x.ultima = ''; }
    if (opc.persona !== undefined) x.persona = String(opc.persona || '').trim().slice(0, 30);
    o[cuenta] = x; casaGuardarTodo_(o);
    return casaEstado_(cuenta);
  });
}
function casaPermisos_(cuenta, p) {
  return conBloqueo_(function () {
    var o = casaTodo_(), x = o[cuenta]; if (!x) throw new Error('No hay link para esa tarjeta.');
    if (p && p.anotar !== undefined) x.anotar = !!p.anotar;
    if (p && p.corregir !== undefined) x.corregir = !!p.corregir;
    if (p && p.persona !== undefined) x.persona = String(p.persona || '').trim().slice(0, 30);
    o[cuenta] = x; casaGuardarTodo_(o);
    return casaEstado_(cuenta);
  });
}
function casaApagar_(cuenta) { return conBloqueo_(function () { var o = casaTodo_(); delete o[cuenta]; casaGuardarTodo_(o); return true; }); }

/** Entrada para quien abre el link de la casa (sin la clave de la app). */
function apiCasa_(token, accion, args) {
  var cache = CacheService.getScriptCache(), fallos = Number(cache.get('casa_fallos') || 0);
  if (fallos >= 30) throw new Error('Demasiados intentos. Esperá unos minutos.');
  var o = casaTodo_(), cuenta = null;
  Object.keys(o).forEach(function (k) { if (token && String(token).length >= 20 && o[k].token === token) cuenta = k; });
  if (!cuenta) { cache.put('casa_fallos', String(fallos + 1), 600); throw new Error('Este link ya no sirve. Pedí uno nuevo.'); }
  var x = o[cuenta], cfg = casaCorte_(cuenta);
  if (!cfg) throw new Error('El presupuesto del súper está apagado por ahora.');
  args = args || [];
  // última vez que entró (como mucho una escritura cada 10 minutos)
  if (!x.ultima || Date.now() - new Date(x.ultima).getTime() > 600000) { try { var o2 = casaTodo_(); if (o2[cuenta]) { o2[cuenta].ultima = new Date().toISOString(); casaGuardarTodo_(o2); } } catch (e) { console.log(e); } }
  var persona = x.persona || 'ella';
  var esDeLaCuenta = function (r) { return texto_(r['Cuenta / tarjeta']).toLowerCase() === cuenta.toLowerCase(); };
  var filaPropia = function (fila) {
    var t = leerTabla_('Movimientos', 'Fecha'), r = t.filas.filter(function (z) { return z._fila === Number(fila); })[0];
    if (!r || !esDeLaCuenta(r) || !/app de la casa/i.test(texto_(r['Nota']))) throw new Error('Solo podés cambiar lo que anotaste vos desde esta app.');
    return r;
  };
  if (accion === 'ver') {
    var marca = marcaDatos_();
    if (args[0] && String(args[0]) === String(marca)) return { sinCambios: true, marca: marca };
    var desde = Calc.periodoCorte(Number(cfg.dia) || 1, new Date(), 6).ini;
    var movs = leerTabla_('Movimientos', 'Fecha').filas.filter(function (r) {
      var tp = texto_(r['Tipo']);
      return (tp === 'Gasto' || tp === 'Ingreso') && esDeLaCuenta(r) && r['Fecha'] && new Date(r['Fecha']) >= desde;
    }).map(function (r) {
      return { fila: r._fila, fecha: iso_(r['Fecha']), comercio: texto_(r['Comercio / descripción']), monto: num_(r['Monto']) || 0, moneda: texto_(r['Moneda']) || 'CRC',
        tipo: texto_(r['Tipo']), cuenta: cuenta, categoria: texto_(r['Categoría']), origen: texto_(r['Origen']), nota: texto_(r['Nota']), autorizacion: /^IVA-/.test(texto_(r['Autorización'])) ? 'IVA-' : '' };
    });
    return {
      marca: marca, cfg: { nombre: cfg.nombre || 'Súper de la casa', monto: Number(cfg.monto) || 0, dia: Number(cfg.dia) || 1, cuenta: cuenta },
      persona: persona, anotar: x.anotar !== false, corregir: x.corregir !== false,
      tipoCambio: num_(hoja_('Config').getRange(15, 2).getValue()) || 0, movimientos: movs
    };
  }
  if (accion === 'guardar') {
    var m = args[0] || {};
    if (x.anotar === false) throw new Error('Esta app solo deja ver.');
    var monto = Number(m.monto), tipo = m.tipo === 'Ingreso' ? 'Ingreso' : 'Gasto';
    if (!(monto > 0) || monto > 10000000) throw new Error('Monto no válido.');
    var mov = {
      fecha: m.fecha || new Date().toISOString(), monto: Math.round(monto * 100) / 100, moneda: m.moneda === 'USD' ? 'USD' : 'CRC', tipo: tipo,
      comercio: String(m.comercio || '').trim().slice(0, 80) || (tipo === 'Ingreso' ? 'Devolución' : 'Compra'), lugar: '', cuenta: cuenta,
      categoria: tipo === 'Gasto' ? String(m.categoria || 'Supermercado').slice(0, 40) : '', sobre: '', origen: 'Manual', autorizacion: '',
      nota: (tipo === 'Ingreso' ? 'Devolución / crédito · ' : '') + 'app de la casa · ' + persona
    };
    if (m.fila) {
      if (x.corregir === false) throw new Error('Esta app no deja corregir.');
      var r0 = filaPropia(m.fila); mov.fila = r0._fila; mov.control = { monto: num_(r0['Monto']) };
    }
    var fila = guardarMovimiento_(mov);
    marcarCambio_();
    return { fila: fila };
  }
  if (accion === 'borrar') {
    if (x.corregir === false) throw new Error('Esta app no deja borrar.');
    var r1 = filaPropia(args[0]);
    eliminarMovimiento_(r1._fila, { monto: num_(r1['Monto']) });
    marcarCambio_();
    return true;
  }
  throw new Error('Acción no permitida.');
}
