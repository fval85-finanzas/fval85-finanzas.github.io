/**
 * Gmail.js — Lee los correos de los bancos y los guarda en la hoja.
 *
 *  - Compras con tarjeta: correos de los bancos de la pestaña Config.
 *  - Pagos del préstamo: correo de PRESTAMO_CORREO con el .txt adjunto.
 *  - Recurrentes: cobros fijos que no llegan por correo.
 *
 * Nada se duplica: compras por número de autorización y pagos por número
 * de comprobante. Si llegan 2 o 3 correos iguales, se guarda una vez.
 *
 * Funciones para ejecutar desde el editor:
 *   probarCorreos()      → muestra lo que leería, SIN guardar nada
 *   procesarCorreos()    → lee y guarda (lo que corre solo cada 15 min)
 *   activarAutomatico() / desactivarAutomatico()
 */

function bancosActivos_() {
  var t = leerTabla_('Config', 'Banco');
  return t.filas
    .filter(function (r) {
      var correo = texto_(r['Correo de notificaciones']);
      return texto_(r['Estado']) === 'Activo' && correo && correo.indexOf('@') > 0 && correo.indexOf('PENDIENTE') < 0;
    })
    .map(function (r) { return { nombre: texto_(r['Banco']), correo: texto_(r['Correo de notificaciones']) }; });
}

function etiqueta_(nombre) {
  return GmailApp.getUserLabelByName(nombre) || GmailApp.createLabel(nombre);
}

function desdeCuando_() {
  var g = PropertiesService.getScriptProperties().getProperty('ULTIMA_REVISION');
  return g ? new Date(Number(g)) : new Date(Date.now() - DIAS_ATRAS * 86400000);
}

/**
 * Busca correos (uno por uno, no por hilo) recibidos después de `desde`.
 * También vuelve a intentar los que quedaron con la etiqueta Finanzas/Revisar
 * (no se duplican: cada movimiento tiene su número de autorización o referencia).
 */
function buscarMensajes_(consulta, desde) {
  var out = [], vistos = {};
  function agregar(q, filtrarFecha) {
    GmailApp.search(q, 0, 100).forEach(function (hilo) {
      hilo.getMessages().forEach(function (msg) {
        if (vistos[msg.getId()] || (filtrarFecha && msg.getDate() <= desde)) return;
        vistos[msg.getId()] = true;
        out.push({ hilo: hilo, msg: msg });
      });
    });
  }
  agregar(consulta + ' after:' + Math.floor(desde.getTime() / 1000), true);
  agregar(consulta + ' label:' + ETIQUETA_REVISAR.toLowerCase().replace(/[\/ ]/g, '-'), false);
  return out;
}

/** Cuenta para los SINPE: la cuenta BCR (no tarjeta ni préstamo) en colones. */
function cuentaSINPE_(cuentas) {
  var c = cuentas.filter(function (x) {
    var tipo = texto_(x['Tipo']);
    return /bcr/i.test(texto_(x['Banco'])) && texto_(x['Activa']) !== 'No' && !/tarjeta|pr[eé]stamo|inversi/i.test(tipo) &&
      (texto_(x['Moneda principal']) || 'CRC') === 'CRC';
  });
  c.sort(function (a, b) { return (/ahorro|corriente/i.test(texto_(b['Tipo'])) ? 1 : 0) - (/ahorro|corriente/i.test(texto_(a['Tipo'])) ? 1 : 0); });
  return c.length ? texto_(c[0]['Nombre (único)']) : '';
}
/** Tarjeta de crédito activa de un banco (para pagos de servicio que no traen los últimos 4). */
function tarjetaDeBanco_(cuentas, banco) {
  var c = cuentas.filter(function (x) {
    return sinTildes_(texto_(x['Banco'])).toLowerCase() === sinTildes_(banco).toLowerCase() && /tarjeta/i.test(texto_(x['Tipo'])) && texto_(x['Activa']) !== 'No';
  })[0];
  return c ? texto_(c['Nombre (único)']) : '';
}

/** Aplica cuenta (por últimos 4), categoría y sobre (por reglas). */
function completarCompra_(tx, cuentas, reglas) {
  var cuenta = tx.cuentaNombre || '';
  if (!cuenta && tx.cuenta4) {   // v2.5.6: cuenta bancaria (no tarjeta) por sus últimos 4, si está en Cuentas
    var cb = cuentas.filter(function (x) { return texto_(x['Últimos 4']) === tx.cuenta4; })[0];
    if (cb) cuenta = texto_(cb['Nombre (único)']);
  }
  if (!cuenta && tx.ultimos4) {
    var c = cuentas.filter(function (x) { return texto_(x['Últimos 4']) === tx.ultimos4; })[0];
    if (c) cuenta = texto_(c['Nombre (único)']);
  }
  var categoria = '', sobre = '';
  var comercio = String(tx.comercio || '').toUpperCase();
  var mejor = '';
  reglas.forEach(function (r) {
    var p = texto_(r['Si el comercio contiene']).toUpperCase();
    if (p && comercio.indexOf(p) >= 0 && p.length > mejor.length) {
      mejor = p; categoria = texto_(r['Categoría']); sobre = texto_(r['Sobre']);
    }
  });
  if (!categoria && tx.categoria) categoria = tx.categoria;
  var nota = [];
  if (tx.nota) nota.push(tx.nota);
  // v2.7.0: tarjeta que cobra todo en colones (tiene límite en ₡ y no en $): el cobro en dólares se pasa a colones (monto estimado)
  if (cuenta && tx.moneda === 'USD') {
    var cc = cuentas.filter(function (x) { return texto_(x['Nombre (único)']) === cuenta; })[0];
    if (cc && /tarjeta/i.test(texto_(cc['Tipo'])) && num_(cc['Límite ₡']) > 0 && !(num_(cc['Límite $']) > 0)) {
      var tc = 0; try { tc = num_(hoja_('Config').getRange('B15').getValue()) || 0; } catch (e) { tc = 0; }
      if (tc > 0) {
        nota.push('Cobro original $' + String(tx.monto).replace('.', ',') + ' · TC ' + tc + ' · monto estimado');
        tx.monto = Math.round(tx.monto * tc * 100) / 100; tx.moneda = 'CRC';
      }
    }
  }
  if (tx.ultimos4 && !cuenta) nota.push('Tarjeta ••' + tx.ultimos4 + ' no está en Cuentas');
  return {
    'Fecha': new Date(tx.fecha),
    'Comercio / descripción': tx.comercio || '',
    'Lugar': tx.lugar || '',
    'Monto': tx.monto,
    'Moneda': tx.moneda,
    'Tipo': tx.tipoMov || (tx.tipo === 'ingreso' ? 'Ingreso' : 'Gasto'),
    'Cuenta / tarjeta': cuenta,
    'Categoría': categoria,
    'Sobre': tx.sobre || sobre,
    'Origen': 'Correo',
    'Autorización': tx.autorizacion,
    'Nota': nota.join('. ')
  };
}

/** Clave para evitar duplicados cuando el correo no trae autorización. */
function claveAuto_(tx, banco) {
  var base = [banco, tx.fecha, tx.monto, tx.moneda, tx.comercio].join('|');
  return 'auto-' + Utilities.base64EncodeWebSafe(
    Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, base)).slice(0, 12);
}

/** Texto de los adjuntos .txt de un correo. */
function textoAdjuntos_(msg) {
  return msg.getAttachments().filter(function (a) {
    return /\.txt$/i.test(a.getName()) || a.getContentType() === 'text/plain';
  }).map(function (a) {
    var t = a.getDataAsString('UTF-8');
    if (t.indexOf('�') >= 0) t = a.getDataAsString('ISO-8859-1');   // archivos con tildes "viejas"
    return t;
  }).join('\n');
}

/**
 * Lee todo y devuelve lo que guardaría. Si `guardar` es true, lo guarda.
 */
function leerCorreos_(guardar) {
  var desde = desdeCuando_();
  var resumen = { compras: 0, pagos: 0, duplicados: 0, revisar: 0, detalle: [] };

  var mov = leerTabla_('Movimientos', 'Fecha');
  var autorizaciones = {};
  mov.filas.forEach(function (r) { var a = texto_(r['Autorización']); if (a) autorizaciones[a] = true; });
  var unidas = {};   // v2.17 (#67): filas manuales ya unidas en esta vuelta
  var cuentas = leerTabla_('Cuentas', 'Nombre (único)').filas;
  var reglas = leerTabla_('Reglas', 'Si el comercio contiene').filas;
  var procesado = guardar ? etiqueta_(ETIQUETA_PROCESADO) : null;
  var revisar = guardar ? etiqueta_(ETIQUETA_REVISAR) : null;

  var ajenas = (prefs_().ajenas) || {}, saltadas = guardar ? ajenasSaltadas_() : {};
  var esMia4 = function (u4) { return cuentas.some(function (x) { return texto_(x['Últimos 4']) === u4; }); };
  var familia = (prefs_().familia) || {};
  var esFamilia4 = function (u4) { return !!(u4 && familia[u4] && !esMia4(u4)); };
  /** v2.10.6: correo de otra persona (reenviado): solo se anotan las compras de las tarjetas de la familia */
  function anotarAjeno(tx, etiquetaBanco) {
    if (!esFamilia4(tx.ultimos4) || /pago de tarjeta/i.test(tx.tipoMov || '')) {
      resumen.detalle.push('↪️ [' + etiquetaBanco + '] reenviado, no es compra de una tarjeta de la familia · no se anota');
      return false;
    }
    anotar(tx, etiquetaBanco);
    return true;
  }
  function anotar(tx, etiquetaBanco) {
    tx.autorizacion = tx.autorizacion || claveAuto_(tx, etiquetaBanco);
    // v2.10.6: tarjetas de la familia (Ajustes → Tarjetas de la familia): se anotan como "Familia ••1234" y solo cuentan en viajes
    if (esFamilia4(tx.ultimos4) && !tx.cuentaNombre) {
      if (familia[tx.ultimos4].pausada) {   // v2.13.0 (#57): tarjeta de la familia pausada → no se anota ni se pregunta
        resumen.detalle.push('⏸ [' + etiquetaBanco + '] tarjeta de la familia ••' + tx.ultimos4 + ' (pausada) · ' + (tx.comercio || '') + ' · no se anota');
        if (guardar && !autorizaciones[tx.autorizacion]) { saltadas['f' + tx.ultimos4] = (saltadas['f' + tx.ultimos4] || 0) + 1; props_().setProperty('AJENAS_SALTADAS', JSON.stringify(saltadas)); }
        autorizaciones[tx.autorizacion] = true;
        return;
      }
      if (/pago de tarjeta/i.test(tx.tipoMov || '')) { resumen.detalle.push('👪 [' + etiquetaBanco + '] pago de la tarjeta de la familia ••' + tx.ultimos4 + ' · no se anota'); return; }
      tx.cuentaNombre = 'Familia ••' + tx.ultimos4; tx.esFamilia = true;
      tx.nota = (tx.nota ? tx.nota + '. ' : '') + 'Tarjeta de la familia (solo viajes)';
    }
    // v2.9.0: tarjetas que no son mías (Ajustes → Cuentas): el correo se marca como leído y no se anota
    if (tx.ultimos4 && !tx.cuentaNombre && ajenas[tx.ultimos4] && !ajenas[tx.ultimos4].off && !esMia4(tx.ultimos4)) {   // v2.13.0: .off = sin ignorar (vuelve a preguntar)
      resumen.ajenas = (resumen.ajenas || 0) + 1;
      resumen.detalle.push('🚫 [' + etiquetaBanco + '] tarjeta ••' + tx.ultimos4 + ' (no es mía) · ' + (tx.comercio || '') + ' · no se anota');
      if (guardar && !autorizaciones[tx.autorizacion]) { saltadas[tx.ultimos4] = (saltadas[tx.ultimos4] || 0) + 1; props_().setProperty('AJENAS_SALTADAS', JSON.stringify(saltadas)); }
      autorizaciones[tx.autorizacion] = true;
      return;
    }
    if (autorizaciones[tx.autorizacion]) { resumen.duplicados++; return; }
    autorizaciones[tx.autorizacion] = true;
    var fila = completarCompra_(tx, cuentas, reglas);
    if (tx.esFamilia) { fila['Sobre'] = ''; resumen.familia = (resumen.familia || 0) + 1; }
    // v2.17 (#67): si ya la anotaste a mano (no llegaba el correo), se une con la tuya en vez de anotarla dos veces
    // v2.18: el cobro real del IVA de un servicio (Google One, Netflix…) confirma el IVA que la app anotó estimado
    var est = buscarIVAEstimado_(mov, fila, unidas);
    if (est) {
      unidas[est._fila] = true; resumen.unidas = (resumen.unidas || 0) + 1;
      resumen.detalle.push('🧾 [' + etiquetaBanco + '] ' + fila['Comercio / descripción'] + ' · ' + fila['Monto'] + ' ' + fila['Moneda'] + ' · confirma el IVA estimado (fila ' + est._fila + ')');
      if (guardar) escribirFila_(mov.hoja, est._fila, mov.cols, {
        'Monto': Number(fila['Monto']), 'Autorización': fila['Autorización'], 'Origen': 'Correo', 'Fecha': fila['Fecha'],
        'Nota': 'IVA confirmado con el correo del banco (estimado ' + (num_(est['Monto']) || 0) + ')'
      });
      return;
    }
    var manual = buscarManualIgual_(mov, fila, unidas);
    if (manual) {
      unidas[manual._fila] = true; resumen.unidas = (resumen.unidas || 0) + 1;
      resumen.detalle.push('🔗 [' + etiquetaBanco + '] ' + fila['Comercio / descripción'] + ' · ' + fila['Monto'] + ' ' + fila['Moneda'] + ' · ya estaba anotada a mano (fila ' + manual._fila + ') · se une');
      if (guardar) {
        var cambios = { 'Autorización': fila['Autorización'], 'Origen': 'Correo', 'Fecha': fila['Fecha'] };
        if (!texto_(manual['Comercio / descripción'])) cambios['Comercio / descripción'] = fila['Comercio / descripción'];
        if (!texto_(manual['Lugar']) && fila['Lugar']) cambios['Lugar'] = fila['Lugar'];
        if (!texto_(manual['Categoría']) && fila['Categoría']) cambios['Categoría'] = fila['Categoría'];
        cambios['Nota'] = (texto_(manual['Nota']) ? texto_(manual['Nota']) + '. ' : '') + 'Unida con el correo del banco (' + (fila['Comercio / descripción'] || '') + ')';
        escribirFila_(mov.hoja, manual._fila, mov.cols, cambios);
      }
      return;
    }
    resumen.compras++;
    resumen.detalle.push('🧾 [' + etiquetaBanco + '] ' + fila['Tipo'] + ' · ' + fila['Comercio / descripción'] + ' · ' +
      fila['Monto'] + ' ' + fila['Moneda'] + ' · ' + (fila['Cuenta / tarjeta'] || 'sin cuenta') + ' · ' + (fila['Categoría'] || 'sin categoría'));
    if (guardar) {
      var n = primeraFilaVacia_(mov.hoja, mov.filaEnc, mov.cols['Fecha']);
      escribirFila_(mov.hoja, n, mov.cols, fila);
    }
  }
  var hilosOk = {}, hilosMal = {};
  /** v2.10.2: estados de cuenta → la app no los toca (se quedan en la bandeja como recordatorio); solo les quita "Revisar" si lo tenían */
  function dejarEnBandeja(x, quien) {
    resumen.detalle.push('📄 [' + quien + '] Estado de cuenta: se queda en la bandeja (no se anota): ' + x.msg.getSubject());
    if (!guardar) return;
    try { revisar.removeFromThread(x.hilo); } catch (e) { /* nada */ }
    var id = x.hilo.getId ? x.hilo.getId() : null; if (id) hilosMal[id] = true;   // nunca se archiva
  }
  function marcar(x, ok) {
    if (!guardar) return;
    var id = x.hilo.getId ? x.hilo.getId() : null;
    if (ok) { procesado.addToThread(x.hilo); revisar.removeFromThread(x.hilo); if (id) hilosOk[id] = x.hilo; }
    else { revisar.addToThread(x.hilo); if (id) hilosMal[id] = true; }
  }

  // ---- Bancos de la pestaña Config (compras con tarjeta, pagos de servicio…) ----
  var bancos = bancosActivos_(), vistosMsg = {};
  if (!bancos.some(function (b) { return b.correo.toLowerCase() === BAC_CORREO.toLowerCase(); })) bancos.push({ nombre: 'BAC', correo: BAC_CORREO, soloFamilia: true });
  /** v2.10.6: reenviado automático (Gmail deja el remitente del banco y agrega X-Forwarded-For) → es de otra persona */
  function esReenviado(msg) { try { return !!(msg.getHeader && (msg.getHeader('X-Forwarded-For') || msg.getHeader('X-Forwarded-To'))); } catch (e) { return false; } }
  bancos.forEach(function (banco) {
    buscarMensajes_('from:' + banco.correo, desde).forEach(function (x) {
      vistosMsg[x.msg.getId()] = true;
      var texto = x.msg.getSubject() + '\n' + x.msg.getPlainBody();
      var lista = parsearCorreoBanco(texto, x.msg.getBody(), x.msg.getDate(), banco.nombre);
      if (banco.soloFamilia || esReenviado(x.msg)) {   // correos de otra persona: solo compras de tarjetas de la familia; lo demás no se toca
        if (!lista || !lista.length) { if (esEstadoDeCuenta_(x.msg.getSubject())) return; resumen.detalle.push('↪️ [' + banco.nombre + '] reenviado sin compra · no se anota: ' + x.msg.getSubject()); return marcar(x, true); }
        var ajeno = esReenviado(x.msg);
        lista.forEach(function (tx) {
          if (!tx.fecha) tx.fecha = x.msg.getDate().toISOString();
          if (!ajeno && tx.ultimos4 && esMia4(tx.ultimos4)) anotar(tx, banco.nombre);   // una tarjeta BAC propia (si algún día la agregás a Cuentas)
          else anotarAjeno(tx, banco.nombre);
        });
        return marcar(x, true);
      }
      if ((!lista || !lista.length) && esEstadoDeCuenta_(x.msg.getSubject())) return dejarEnBandeja(x, banco.nombre);
      if (!lista) {
        resumen.revisar++;
        resumen.detalle.push('⚠️ [' + banco.nombre + '] No pude leer: ' + x.msg.getSubject());
        marcar(x, false);
        return;
      }
      lista.forEach(function (tx) {
        if (tx.esServicio && !tx.cuentaNombre) tx.cuentaNombre = tarjetaDeBanco_(cuentas, banco.nombre);
        if (tx.esSINPE) tx.cuentaNombre = cuentaSINPE_(cuentas);
        if (!tx.fecha) tx.fecha = x.msg.getDate().toISOString();
        anotar(tx, banco.nombre);
      });
      marcar(x, true);
    });
  });

  // ---- v2.10.6: reenviados a mano (el remitente es la persona, el correo del banco va en el texto) → solo tarjetas de la familia ----
  if (Object.keys(familia).length) {
    bancos.forEach(function (banco) {
      buscarMensajes_('"' + banco.correo + '" -from:' + banco.correo, desde).forEach(function (x) {
        if (vistosMsg[x.msg.getId()]) return;
        vistosMsg[x.msg.getId()] = true;
        var lista = parsearCorreoBanco(x.msg.getSubject() + '\n' + x.msg.getPlainBody(), x.msg.getBody(), x.msg.getDate(), banco.nombre);
        var deFamilia = (lista || []).filter(function (tx) { return esFamilia4(tx.ultimos4) && !/pago de tarjeta/i.test(tx.tipoMov || ''); });
        if (!deFamilia.length) return;   // no es de la familia: no se toca
        deFamilia.forEach(function (tx) { if (!tx.fecha) tx.fecha = x.msg.getDate().toISOString(); anotar(tx, banco.nombre + ' (reenviado)'); });
        marcar(x, true);
      });
    });
  }

  // ---- SINPE Móvil del BCR ----
  buscarMensajes_('from:' + SINPE_CORREO.remitente + ' subject:' + SINPE_CORREO.asunto, desde).forEach(function (x) {
    var tx = parsearSINPE(x.msg.getPlainBody()) || parsearSINPE(textoDeHtml_(x.msg.getBody()));
    if (!tx) {
      resumen.revisar++;
      resumen.detalle.push('⚠️ [SINPE] No pude leer: ' + x.msg.getSubject());
      marcar(x, false);
      return;
    }
    tx.cuentaNombre = cuentaSINPE_(cuentas);
    if (!tx.fecha) tx.fecha = x.msg.getDate().toISOString();
    anotar(tx, 'SINPE');
    marcar(x, true);
  });

  // ---- BCR SAFI: solicitudes de inversión y de retiro (las confirmaciones con PDF y el estado de cuenta se ignoran) ----
  buscarMensajes_('from:' + FONDOS_CORREO, desde).forEach(function (x) {
    var asunto = x.msg.getSubject();
    if (esEstadoDeCuenta_(asunto)) return dejarEnBandeja(x, 'Fondos');
    if (!/solicitud de (inversi|retiro)/i.test(asunto)) {
      resumen.detalle.push('📄 [Fondos] Confirmación o estado de cuenta (no se anota): ' + asunto);
      marcar(x, true);
      return;
    }
    var tx = parsearSAFI(x.msg.getPlainBody(), x.msg.getDate()) || parsearSAFI(textoDeHtml_(x.msg.getBody()), x.msg.getDate());
    if (!tx) {
      resumen.revisar++;
      resumen.detalle.push('⚠️ [Fondos] No pude leer: ' + asunto);
      marcar(x, false);
      return;
    }
    tx.cuentaNombre = cuentaSINPE_(cuentas);
    if (tx.tipoMov === 'Inversión') { try { tx.sobre = sobreEspecial_('fondos'); } catch (e) { tx.sobre = SOBRE_FONDOS; } }
    anotar(tx, 'Fondos');
    marcar(x, true);
  });

  // ---- Préstamo: recibos de pago (y el estado de cuenta mensual, que no se anota) ----
  var q = 'from:' + PRESTAMO_CORREO.remitente + ' has:attachment -subject:' + SINPE_CORREO.asunto +
          (PRESTAMO_CORREO.asunto ? ' subject:(' + PRESTAMO_CORREO.asunto + ')' : '');
  buscarMensajes_(q, desde).forEach(function (x) {
    var txt = textoAdjuntos_(x.msg);
    if (/estado de cuenta/i.test(x.msg.getSubject()) || esEstadoCuentaPrestamo(txt)) return dejarEnBandeja(x, 'Préstamo');
    var p = txt ? parsearComprobantePrestamo(txt, x.msg.getDate()) : null;
    if (!p) {
      resumen.revisar++;
      resumen.detalle.push('⚠️ [Préstamo] No pude leer el comprobante: ' + x.msg.getSubject());
      marcar(x, false);
      return;
    }
    p.fecha = p.fecha.toISOString();
    if (!p.comprobante) p.comprobante = claveAuto_({ fecha: p.fecha.slice(0, 10), monto: p.total, moneda: 'CRC', comercio: 'prestamo' }, 'BCR');
    resumen.detalle.push('🏠 [Préstamo] ' + p.fecha.slice(0, 10) + ' · recibo ' + p.comprobante +
      ' · capital ' + p.principal + ' · intereses ' + p.intereses + ' · pólizas ' + p.polizas + (p.saldoNuevo ? ' · nuevo saldo ' + p.saldoNuevo : ''));
    if (guardar) {
      var res = registrarPagoPrestamo_(p);
      if (res === 'duplicado') resumen.duplicados++;
      else if (res === 'ignorado') resumen.detalle.push('📄 [Préstamo] Sin capital ni intereses: no se anota.');
      else resumen.pagos++;
    } else {
      resumen.pagos++;
    }
    marcar(x, true);
  });

  // v2.10.1: bandeja limpia → lo leído sale de la bandeja de entrada y queda leído (lo que no entendió se queda)
  if (guardar && (prefs_().bandejaLimpia !== false)) {
    Object.keys(hilosOk).forEach(function (id) {
      if (hilosMal[id]) return;
      try { hilosOk[id].markRead(); hilosOk[id].moveToArchive(); resumen.archivados = (resumen.archivados || 0) + 1; } catch (e) { console.log('Archivar: ' + e); }
    });
  }
  return resumen;
}

/** Lo que corre solo cada 15 minutos. */
function procesarCorreos() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return 'Ocupado, intentá en un momento.';
  try {
    var inicio = Date.now();
    var r = leerCorreos_(true);
    // avisos de viaje y columnas de Sobres: solo si entró algo nuevo (así el botón "Correos" responde rápido)
    if (r.compras + r.pagos > 0) { try { tareasDespuesDeLeer_(); } catch (e) { console.log('Después de leer: ' + e); } }
    if (r.compras + r.pagos + r.revisar + (r.unidas || 0) > 0) marcarCambio_();   // v2.14 · v2.17: también si se unió una manual
    PropertiesService.getScriptProperties().setProperty('REVISION_APP', String(inicio));
    // La próxima vez revisa desde 10 min antes (por si un correo llegó tarde; no se duplica)
    PropertiesService.getScriptProperties().setProperty('ULTIMA_REVISION', String(inicio - 10 * 60 * 1000));
    try { devolverEstadosDeCuenta_(); } catch (e) { console.log('Estados de cuenta: ' + e); }
    try { limpiarBandejaVieja_(); } catch (e) { console.log('Bandeja: ' + e); }
    var msg = 'Movimientos nuevos: ' + r.compras + ' · Pagos del préstamo: ' + r.pagos +
              ' · Repetidos ignorados: ' + r.duplicados + (r.unidas ? ' · Unidas con las anotadas a mano: ' + r.unidas : '') + ' · Para revisar: ' + r.revisar;
    console.log(msg);
    return msg;
  } finally {
    lock.releaseLock();
  }
}

/** Muestra en el registro lo que leería, sin guardar ni etiquetar nada. */
function probarCorreos() {
  var bancos = bancosActivos_();
  console.log('Bancos activos: ' + (bancos.map(function (b) { return b.nombre + ' (' + b.correo + ')'; }).join(', ') || 'ninguno'));
  var r = leerCorreos_(false);
  if (r.detalle.length === 0) console.log('No encontré correos nuevos en los últimos ' + DIAS_ATRAS + ' días.');
  r.detalle.forEach(function (l) { console.log(l); });
  console.log('Repetidos (ya estaban en la hoja): ' + r.duplicados);
}

// ---------------------------------------------------------------------
// RECURRENTES: cobros fijos que no llegan por correo
// ---------------------------------------------------------------------
function procesarRecurrentes() {
  var hoy = new Date();
  var ultimoDia = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0).getDate();
  var rec = leerTabla_('Recurrentes', 'Descripción').filas;
  var mov = leerTabla_('Movimientos', 'Fecha');
  var ya = {};
  mov.filas.forEach(function (r) { ya[texto_(r['Autorización'])] = true; });
  var mesClave = Utilities.formatDate(hoy, 'America/Costa_Rica', 'yyyy-MM');
  var agregados = 0;

  rec.forEach(function (r) {
    if (texto_(r['Activo']) === 'No') return;
    var dia = Math.min(num_(r['Día del mes']) || 1, ultimoDia);
    if (hoy.getDate() < dia) return;
    var clave = 'REC-' + mesClave + '-' + r._fila;
    if (ya[clave]) return;
    var n = primeraFilaVacia_(mov.hoja, mov.filaEnc, mov.cols['Fecha']);
    escribirFila_(mov.hoja, n, mov.cols, {
      'Fecha': new Date(hoy.getFullYear(), hoy.getMonth(), dia, 12, 0),
      'Comercio / descripción': texto_(r['Descripción']),
      'Monto': num_(r['Monto']) || 0,
      'Moneda': texto_(r['Moneda']) || 'CRC',
      'Tipo': 'Gasto',
      'Cuenta / tarjeta': texto_(r['Tarjeta / cuenta']),
      'Categoría': texto_(r['Categoría']),
      'Sobre': texto_(r['Sobre']),
      'Origen': 'Recurrente',
      'Autorización': clave
    });
    ya[clave] = true;
    agregados++;
  });
  if (agregados) marcarCambio_();   // v2.14
  console.log('Recurrentes agregados: ' + agregados);
}

// ---------------------------------------------------------------------
// AUTOMÁTICO
// ---------------------------------------------------------------------
function activarAutomatico() {
  desactivarAutomatico();
  ScriptApp.newTrigger('procesarCorreos').timeBased().everyMinutes(15).create();
  ScriptApp.newTrigger('procesarDiario').timeBased().everyDays(1).atHour(6).create();
  console.log('✅ Correos cada 15 minutos; recurrentes y recordatorios todos los días a las 6 a.m.');
}

function desactivarAutomatico() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    var f = t.getHandlerFunction();
    if (f === 'procesarCorreos' || f === 'procesarRecurrentes' || f === 'procesarDiario') ScriptApp.deleteTrigger(t);
  });
}

/** v2.9.0: cuántos correos se saltaron por tarjeta "que no es mía" ({ '1234': 3 }) */
function ajenasSaltadas_() { try { return JSON.parse(props_().getProperty('AJENAS_SALTADAS') || '{}'); } catch (e) { return {}; } }

/** v2.10.1 · Una sola vez (y hasta terminar): los correos ya procesados que siguen en la bandeja se archivan y quedan leídos. */
function esEstadoDeCuenta_(asunto) { return /estado\s+de\s+cuenta/i.test(String(asunto || '')); }
/** v2.10.2 · Una sola vez: los estados de cuenta que 2.10.1 sacó de la bandeja vuelven a la bandeja (sin "Procesado"). */
function devolverEstadosDeCuenta_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('ESTADOS_BANDEJA_V2') === 'si') return 0;
  var et = GmailApp.getUserLabelByName(ETIQUETA_PROCESADO), rev = GmailApp.getUserLabelByName(ETIQUETA_REVISAR), n = 0;
  if (et) {
    var hilos = GmailApp.search('-in:inbox label:' + ETIQUETA_PROCESADO.toLowerCase().replace(/[\/ ]/g, '-') + ' subject:"estado de cuenta"', 0, 100);
    if (hilos.length) { GmailApp.moveThreadsToInbox(hilos); et.removeFromThreads(hilos); n += hilos.length; }
  }
  if (rev) { var r2 = GmailApp.search('label:' + ETIQUETA_REVISAR.toLowerCase().replace(/[\/ ]/g, '-') + ' subject:"estado de cuenta"', 0, 100); if (r2.length) rev.removeFromThreads(r2); }
  p.setProperty('ESTADOS_BANDEJA_V2', 'si');
  return n;
}
function limpiarBandejaVieja_() {
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('BANDEJA_LIMPIA_V1') === 'si' || prefs_().bandejaLimpia === false) return 0;
  var q = 'in:inbox label:' + ETIQUETA_PROCESADO.toLowerCase().replace(/[\/ ]/g, '-') + ' -label:' + ETIQUETA_REVISAR.toLowerCase().replace(/[\/ ]/g, '-') + ' -subject:"estado de cuenta"';
  var total = 0;
  for (var vuelta = 0; vuelta < 5; vuelta++) {
    var hilos = GmailApp.search(q, 0, 100);
    if (!hilos.length) break;
    GmailApp.markThreadsRead(hilos); GmailApp.moveThreadsToArchive(hilos);
    total += hilos.length;
    if (hilos.length < 100) break;
  }
  if (GmailApp.search(q, 0, 1).length === 0) p.setProperty('BANDEJA_LIMPIA_V1', 'si');
  return total;
}


/**
 * v2.17 (#67): compra anotada a mano que es la misma del correo: misma cuenta, tipo, moneda y monto,
 * del mismo día o con un día de diferencia, sin autorización (la del correo todavía no la tenía). La más cercana en fecha.
 */
function buscarManualIgual_(mov, fila, unidas) {
  var dia = function (d) { d = d && d.getFullYear ? d : new Date(d); return isNaN(d) ? null : Math.round(new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 86400000); };
  var d0 = dia(fila['Fecha']), cta = texto_(fila['Cuenta / tarjeta']).toLowerCase(), mejor = null, dm = 9;
  if (d0 === null || !(Number(fila['Monto']) > 0)) return null;
  mov.filas.forEach(function (r) {
    if (unidas[r._fila] || texto_(r['Origen']) !== 'Manual' || texto_(r['Autorización'])) return;
    if (texto_(r['Tipo']) !== texto_(fila['Tipo']) || texto_(r['Cuenta / tarjeta']).toLowerCase() !== cta) return;
    if ((texto_(r['Moneda']) || 'CRC') !== (fila['Moneda'] || 'CRC') || Math.abs((num_(r['Monto']) || 0) - Number(fila['Monto'])) > 0.5) return;
    var d = dia(r['Fecha']); if (d === null) return;
    var dd = Math.abs(d - d0); if (dd <= 1 && dd < dm) { dm = dd; mejor = r; }
  });
  return mejor;
}

/**
 * v2.18: ¿este cobro del correo es el IVA de un servicio que la app ya anotó como "IVA estimado"?
 * Misma tarjeta y moneda, el texto del cobro habla de IVA o impuesto, de 2 días antes a 20 días después del estimado,
 * y el monto se parece (±25 % o ₡300). El más cercano en monto.
 */
function buscarIVAEstimado_(mov, fila, unidas) {
  if (texto_(fila['Tipo']) !== 'Gasto' || !/\biva\b|i\.v\.a|impuesto|valor agregado/i.test(String(fila['Comercio / descripción'] || '') + ' ' + String(fila['Nota'] || ''))) return null;
  var f0 = new Date(fila['Fecha']).getTime(), cta = texto_(fila['Cuenta / tarjeta']).toLowerCase(), v0 = Number(fila['Monto']) || 0, mejor = null, dm = Infinity;
  mov.filas.forEach(function (r) {
    if (unidas[r._fila] || !/^IVA-/.test(texto_(r['Autorización'])) || !/IVA estimado/i.test(texto_(r['Nota']))) return;
    if (texto_(r['Cuenta / tarjeta']).toLowerCase() !== cta || (texto_(r['Moneda']) || 'CRC') !== (fila['Moneda'] || 'CRC')) return;
    var fr = new Date(r['Fecha'] && r['Fecha'].getTime ? r['Fecha'].getTime() : r['Fecha']).getTime(), dias = (f0 - fr) / 86400000;
    if (isNaN(dias) || dias < -2 || dias > 20) return;
    var v = num_(r['Monto']) || 0, d = Math.abs(v - v0);
    if (d > Math.max(300, v * 0.25)) return;
    if (d < dm) { dm = d; mejor = r; }
  });
  return mejor;
}
