"""Junta los archivos de apps-script/ en un solo apps-script-simple/Codigo.gs (el que se pega en Apps Script).
Uso: python3 herramientas/armar_codigo.py"""
import pathlib
raiz = pathlib.Path(__file__).resolve().parent.parent
src = raiz / 'apps-script'
partes = ['Config.js', 'Parser.js', 'ParserPrestamo.js', 'Hoja.js', 'Codigo.js', 'Gmail.js', 'Ajustes.js', 'Extras.js']
cab = """/**
 * FINANZAS — servidor (Google Apps Script), todo en un solo archivo.
 * Pegalo completo en el archivo "Código" de Apps Script.
 * La app (pantallas) está en la carpeta web/ y se publica en GitHub Pages.
 */

"""
gs = cab + '\n\n'.join('// =====================================================================\n// ' + p[:-3] + '\n// =====================================================================\n' + (src / p).read_text().strip() + '\n' for p in partes)
# Los mismos cálculos de la app (sobres, viajes, tasa cero) también corren en el servidor
calc = (raiz / 'web' / 'js' / 'calculos.js').read_text().strip()
gs += '\n\n// =====================================================================\n// Calculos (copiado de web/js/calculos.js)\n// =====================================================================\n' + calc + '\n'
(raiz / 'apps-script-simple' / 'Codigo.gs').write_text(gs)
print('Codigo.gs:', len(gs.splitlines()), 'líneas')

# v2.5: lo que la app usa para actualizarse sola (se publica junto con la página)
import hashlib, json, re
web = raiz / 'web'
(web / 'servidor').mkdir(exist_ok=True)
(web / 'servidor' / 'Codigo.gs').write_text(gs)
ver_srv = re.search(r"VERSION_APP = '([\d.]+)'", gs).group(1)
ver_web = re.search(r"VERSION_WEB = '([\d.]+)'", (web / 'js' / 'app.js').read_text()).group(1)
novedades = (raiz / 'herramientas' / 'novedades.txt').read_text().strip() if (raiz / 'herramientas' / 'novedades.txt').exists() else ''
manifiesto = json.loads((raiz / 'apps-script' / 'appsscript.json').read_text())
(web / 'version.json').write_text(json.dumps({'web': ver_web, 'servidor': ver_srv, 'sha256': hashlib.sha256(gs.encode('utf-8')).hexdigest(),
  'novedades': novedades, 'manifiesto': manifiesto}, ensure_ascii=False, indent=1))
(raiz / 'apps-script-simple' / 'appsscript.json').write_text((raiz / 'apps-script' / 'appsscript.json').read_text())
print('version.json: web', ver_web, '· servidor', ver_srv)
