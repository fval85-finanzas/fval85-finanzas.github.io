"""Genera pruebas/datos-muestra.json a partir de la base de datos de ejemplo.

Imita lo que devuelve obtenerDatos() en Apps Script, para probar la app
en la computadora sin Google. Uso:
    python3 pruebas/generar_muestra.py base-de-datos/Mis_Finanzas_BD.xlsx pruebas/datos-muestra.json
(El .xlsx tiene que estar recalculado: abrirlo y guardarlo en Excel/LibreOffice.)
"""
import datetime as dt
import json
import sys

import openpyxl

CR = dt.timezone(dt.timedelta(hours=-6))


def iso(v):
    if isinstance(v, dt.datetime):
        return v.replace(tzinfo=CR).astimezone(dt.timezone.utc).isoformat().replace('+00:00', 'Z')
    return v


def tabla(ws, fila_enc, clave):
    enc = {}
    for c in range(1, ws.max_column + 1):
        t = ws.cell(fila_enc, c).value
        if t and str(t).strip() not in enc:
            enc[str(t).strip()] = c
    filas = []
    for r in range(fila_enc + 1, ws.max_row + 1):
        v = ws.cell(r, enc[clave]).value
        if v in (None, ''):
            continue
        o = {'_fila': r}
        for k, c in enc.items():
            o[k] = ws.cell(r, c).value
        filas.append(o)
    return filas


def t(v):
    return '' if v is None else str(v).strip()


def main(src, out):
    wb = openpyxl.load_workbook(src, data_only=True)
    cfg = wb['Config']
    cuentas = [{
        'fila': r['_fila'], 'nombre': t(r['Nombre (único)']), 'tipo': t(r['Tipo']), 'banco': t(r['Banco']),
        'ultimos4': t(r['Últimos 4']), 'moneda': t(r['Moneda principal']) or 'CRC',
        'limiteCRC': r['Límite ₡'], 'limiteUSD': r['Límite $'], 'diaCorte': r['Día de corte'], 'diaPago': r['Día de pago'],
        'activa': t(r['Activa']) != 'No', 'saldoCRC': r['Saldo actual ₡'], 'saldoUSD': r['Saldo actual $'], 'notas': t(r['Notas'])
    } for r in tabla(wb['Cuentas'], 4, 'Nombre (único)')]
    movimientos = [{
        'fila': r['_fila'], 'fecha': iso(r['Fecha']), 'comercio': t(r['Comercio / descripción']), 'lugar': t(r['Lugar']),
        'monto': r['Monto'] or 0, 'moneda': t(r['Moneda']) or 'CRC', 'tipo': t(r['Tipo']) or 'Gasto',
        'cuenta': t(r['Cuenta / tarjeta']), 'categoria': t(r['Categoría']), 'sobre': t(r['Sobre']),
        'origen': t(r['Origen']), 'autorizacion': t(r['Autorización']), 'nota': t(r['Nota'])
    } for r in tabla(wb['Movimientos'], 4, 'Fecha')]
    wsob = openpyxl.load_workbook(src)['Sobres']
    sobres = [{
        'fila': r['_fila'], 'nombre': t(r['Sobre']), 'moneda': t(r['Moneda']) or 'CRC', 'asignado': r['Asignado por mes'],
        'tipo': t(r['Tipo']) or 'Variable', 'notas': t(r['Notas']),
        'asignadoAuto': str(wsob.cell(r['_fila'], 3).value or '').startswith('=')
    } for r in tabla(wb['Sobres'], 4, 'Sobre')]
    tasa_cero = [{
        'fila': r['_fila'], 'descripcion': t(r['Descripción']), 'tarjeta': t(r['Tarjeta']), 'fechaCompra': iso(r['Fecha de compra']),
        'monto': r['Monto total'] or 0, 'moneda': t(r['Moneda']) or 'CRC', 'meses': r['Meses'] or 1, 'primeraCuota': iso(r['Primera cuota'])
    } for r in tabla(wb['Tasa Cero'], 6, 'Descripción')]
    p = wb['Préstamo casa']
    g = [p[f'G{i}'].value for i in range(4, 12)]
    c = [p[f'C{i}'].value for i in range(4, 12)]
    k = [p[f'K{i}'].value for i in range(5, 9)]
    pagos = [{
        'fecha': iso(r['Fecha de pago']), 'comprobante': t(r['N° comprobante']), 'principal': r['Abono principal'] or 0,
        'intereses': r['Intereses'] or 0, 'polizas': (r['Pólizas'] or 0) + (r['Pólizas BCR'] or 0), 'total': r['Total pagado'] or 0,
        'saldo': r['Saldo'], 'tbp': r['TBP (tasa real)'], 'tasa': r['Tasa BCR'], 'vence': iso(r['Vence (día 7)']), 'anticipo': r['Días de anticipo']
    } for r in tabla(p, 15, 'Fecha de pago')]
    prestamo = {
        'operacion': t(c[0]), 'saldoInicial': c[1], 'plazo': c[3], 'tbp': c[6], 'tasa': c[7],
        'saldo': g[0], 'pagadoPct': g[1], 'cuotasPagadas': g[2], 'restantes': g[3], 'ultimoPago': iso(g[4]),
        'proximoVenc': iso(g[5]), 'interesesTotal': g[7],
        'estimado': {'principal': k[0], 'intereses': k[1], 'polizas': k[2], 'total': k[3]}, 'pagos': pagos
    }
    lista = lambda col: [t(cfg[f'{col}{i}'].value) for i in range(5, 35) if t(cfg[f'{col}{i}'].value)]
    datos = {
        'hoy': '2026-10-28T17:00:00.000Z', 'tipoCambio': cfg['B15'].value, 'cuentas': cuentas, 'movimientos': movimientos,
        'sobres': sobres, 'tasaCero': tasa_cero, 'prestamo': prestamo, 'tasas': [],
        'categorias': lista('F'), 'tiposCuenta': lista('G'), 'tiposMovimiento': lista('I'),
        'sobreEspecial': {'prestamo': 'Cuota casa', 'tasaCero': 'Cuotas tasa cero'}, 'ultimaRevision': None
    }
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(datos, f, ensure_ascii=False, indent=1, default=str)
    print('ok', out, len(movimientos), 'movimientos', len(pagos), 'pagos')


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
