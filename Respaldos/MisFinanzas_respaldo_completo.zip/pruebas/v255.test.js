// v2.5.5: cuentas de ahorro con saldo vivo, historial de sobres, buscador, reparar fórmulas.  TZ=America/Costa_Rica node pruebas/v255.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const hoy = new Date(2026, 10, 2, 12);
const d = {
  cuentas: [
    { fila: 2, nombre: 'Visa Prueba', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, diaCorte: 9 },
    { fila: 3, nombre: 'Ahorros Prueba', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true, saldoCRC: 10000, fechaSaldo: '2026-10-31T12:00:00-06:00' },
    { fila: 4, nombre: 'Saldo actual: en tarjetas, lo que debés hoy (según el banco)', tipo: '', activa: true }
  ],
  movimientos: [
    { fila: 10, fecha: '2026-10-31T10:00:00-06:00', tipo: 'Ingreso', monto: 999, moneda: 'CRC', cuenta: 'Ahorros Prueba' },   // mismo día del saldo: no cuenta
    { fila: 11, fecha: '2026-11-01T08:00:00-06:00', tipo: 'Ingreso', monto: 450000, moneda: 'CRC', cuenta: '', comercio: 'Salario' },   // sin cuenta → principal
    { fila: 12, fecha: '2026-11-01T09:00:00-06:00', tipo: 'Gasto', monto: 5000, moneda: 'CRC', cuenta: 'Ahorros Prueba', comercio: 'SINPE a Juan' },
    { fila: 13, fecha: '2026-11-01T10:00:00-06:00', tipo: 'Gasto', monto: 7000, moneda: 'CRC', cuenta: 'Visa Prueba', comercio: 'Super' },   // tarjeta: no toca ahorros
    { fila: 14, fecha: '2026-11-02T10:00:00-06:00', tipo: 'Pago de tarjeta', monto: 60000, moneda: 'CRC', cuenta: 'Visa Prueba' },
    { fila: 15, fecha: '2026-11-02T11:00:00-06:00', tipo: 'Ingreso', monto: 1000, moneda: 'CRC', cuenta: 'Visa Prueba', comercio: 'Devolución' }   // devolución en tarjeta
  ],
  prestamo: { pagos: [{ fecha: '2026-11-01T12:00:00-06:00', total: 100000 }] },
  sobres: [{ fila: 2, nombre: 'Ventas', moneda: 'CRC', tipo: 'Variable', saldoInicial: 1000 }],
  sobresMov: [
    { fecha: '2026-10-05T10:00:00-06:00', sobre: 'Ventas', monto: 500, tipo: 'Mover', grupo: 'a', nota: 'De Otro a Ventas' },
    { fecha: '2026-11-01T10:00:00-06:00', sobre: 'Ventas', monto: -300, tipo: 'Gasto', grupo: 'b' }
  ],
  sobresDesde: '2026-10-01T00:00:00-06:00'
};
prueba('la nota de la hoja Cuentas no es cuenta', () => {
  assert.strictEqual(d.cuentas.filter(C.esCuentaReal).length, 2);
  assert.ok(C.esCuentaReal({ nombre: 'Ahorros BCR colones' }));
});
prueba('cuenta principal por defecto = primera de ahorro en colones', () => {
  const o = C.origenes(d, {});
  assert.deepStrictEqual({ principal: o.principal, tarjetas: o.tarjetas, prestamo: o.prestamo, fondos: o.fondos }, { principal: 'Ahorros Prueba', tarjetas: 'Ahorros Prueba', prestamo: 'Ahorros Prueba', fondos: 'Ahorros Prueba' });
  assert.strictEqual(C.origenes(d, { tarjetas: 'No existe' }).tarjetas, 'Ahorros Prueba');
});
prueba('saldo vivo: + salario − SINPE − pago de tarjeta − cuota; no cuenta la tarjeta ni el día del saldo', () => {
  const s = C.saldoCuenta(d, d.cuentas[1], C.origenes(d, {}));
  assert.ok(s.vivo);
  assert.strictEqual(s.entra.CRC, 450000); assert.strictEqual(s.sale.CRC, 5000); assert.strictEqual(s.pagos.CRC, 160000);
  assert.strictEqual(s.CRC, 10000 + 450000 - 5000 - 160000);
});
prueba('movimientos de la cuenta incluyen la cuota del préstamo', () => {
  const l = C.movsCuenta(d, d.cuentas[1], C.origenes(d, {}));
  assert.ok(l.some(x => x.pago && x.monto === -100000));
  assert.ok(!l.some(x => x.mov && x.mov.fila === 13));
});
prueba('historial del sobre con saldo corrido', () => {
  const h = C.historialSobre(d, 'Ventas');
  assert.strictEqual(h.lista.length, 2);
  assert.strictEqual(h.lista[0].antes, 1000); assert.strictEqual(h.lista[0].despues, 1500); assert.strictEqual(h.saldo, 1200);
  const m = C.saldosMensualesSobre(h, hoy, 3);
  assert.deepStrictEqual(m.map(x => x.saldo), [null, 1500, 1200]);   // setiembre: antes de empezar los sobres
});
prueba('buscador: mes, fecha, montos y palabras', () => {
  const b = C.leerBusqueda('super octubre >5.000', hoy);
  assert.deepStrictEqual(b.palabras, ['super']); assert.strictEqual(b.min, 5000);
  assert.strictEqual(b.desde.getMonth(), 9); assert.strictEqual(b.desde.getFullYear(), 2026);
  assert.strictEqual(C.leerBusqueda('diciembre', hoy).desde.getFullYear(), 2025);   // diciembre todavía no llegó: el del año pasado
  const f = C.leerBusqueda('1/11', hoy); assert.strictEqual(f.desde.getDate(), 1); assert.strictEqual(f.desde.getMonth(), 10);
  const r = C.leerBusqueda('5000-10000', hoy); assert.strictEqual(r.min, 5000); assert.strictEqual(r.max, 10000);
  assert.ok(C.coincide(d.movimientos[3], C.leerBusqueda('super noviembre 5000-10000', hoy)));
  assert.ok(!C.coincide(d.movimientos[3], C.leerBusqueda('super octubre', hoy)));
  assert.ok(C.coincide({ fecha: '2026-11-01T10:00:00-06:00', monto: 1, comercio: 'Panadería' }, C.leerBusqueda('panaderia', hoy)));
});
prueba('períodos y último corte', () => {
  const s = C.rangoPeriodo('semana', hoy); assert.strictEqual(s[0].getDay(), 1);
  assert.strictEqual(C.rangoPeriodo('pasado', hoy)[0].getMonth(), 9);
  assert.strictEqual(C.ultimoCorte({ diaCorte: 9 }, hoy).getMonth(), 9);
  assert.strictEqual(C.ultimoCorte({ diaCorte: 1 }, hoy).getDate(), 1);
});
prueba('servidor: repara la fórmula que quedó vacía o con #REF! en la fila nueva', () => {
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
  const f = { 2: ['', '=A2*2', '=C1+B2', '=D1'], 3: ['', '', '=#REF!+B3', ''] }, copias = [];
  const h = { getLastColumn: () => 4, getRange: (fila, col, nf, nc) => nc ? { getFormulas: () => [f[fila]] } : { copyTo: (dest) => copias.push([fila, col, dest.fila, dest.col]), fila, col } };
  const n = ctx.repararFormulasFila_(h, 3, { 'Monto': 4 }, ['Monto']);
  assert.strictEqual(n, 2);
  assert.deepStrictEqual(copias, [[2, 2, 3, 2], [2, 3, 3, 3]]);   // la columna escrita (Monto) no se toca
});
console.log(ok + ' pruebas OK');

// ---------------- v2.5.6 ----------------
prueba('2.5.6 · plata BCR → cuenta Davibank → pago de tarjeta: cada cuenta cuadra y no se cuenta dos veces', () => {
  const base = JSON.parse(JSON.stringify(d));
  base.cuentas.push({ fila: 5, nombre: 'Ahorros Otro Banco', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true, ultimos4: '7777', saldoCRC: 0, fechaSaldo: '2026-10-31T12:00:00-06:00' });
  base.prestamo = { pagos: [] };
  base.movimientos = [
    { fila: 30, fecha: '2026-11-02T20:07:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Otro Banco', comercio: 'Entró a cuenta Davibank ••7777' },
    { fila: 31, fecha: '2026-11-02T20:09:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Otro Banco', comercio: 'Salió de cuenta Davibank ••7777' },
    { fila: 32, fecha: '2026-11-02T20:09:30-06:00', tipo: 'Pago de tarjeta', monto: 30000, moneda: 'CRC', cuenta: 'Visa Prueba', comercio: 'Pago de tarjeta' }
  ];
  const o = C.origenes(base, {});
  const otro = C.saldoCuenta(base, base.cuentas.find(c => c.nombre === 'Ahorros Otro Banco'), o);
  const ppal = C.saldoCuenta(base, base.cuentas[1], o);
  assert.strictEqual(otro.CRC, 0);            // entró 30.000 y salió 30.000 (el pago)
  assert.strictEqual(otro.pagos.CRC, 30000);
  assert.strictEqual(ppal.CRC, 10000 - 30000); // la plata salió de la principal una sola vez
  // sin el aviso de salida: el pago sale de la cuenta donde entró la plata
  base.movimientos.splice(1, 1);
  assert.strictEqual(C.saldoCuenta(base, base.cuentas.find(c => c.nombre === 'Ahorros Otro Banco'), o).CRC, 0);
  assert.strictEqual(C.saldoCuenta(base, base.cuentas[1], o).CRC, 10000 - 30000);
  // con la salida de la principal anotada (débito en tiempo real): se emparejan, nada se inventa
  base.movimientos.push({ fila: 33, fecha: '2026-11-02T20:07:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Prueba', comercio: 'Débito en tiempo real · Persona Prueba' });
  assert.strictEqual(C.saldoCuenta(base, base.cuentas[1], o).CRC, 10000 - 30000);
  assert.strictEqual(C.saldoCuenta(base, base.cuentas.find(c => c.nombre === 'Ahorros Otro Banco'), o).CRC, 0);
});
prueba('2.5.6 · lector Davibank: pago de tarjeta, crédito/débito de cuenta y montos sin separador de miles', () => {
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script', 'Parser.js'), 'utf8'), ctx);
  const fc = new Date('2026-11-03T02:09:00Z');
  const p = ctx.parsearCorreoBanco('Estimado cliente: &nbsp DAVIbank le informa que se recibió el pago a su tarjeta de crédito , terminada en 1111, por CRC 45678.90, el día 02/11/26. &nbsp', '', fc, 'Davibank');
  assert.strictEqual(p.length, 1); assert.strictEqual(p[0].tipoMov, 'Pago de tarjeta'); assert.strictEqual(p[0].monto, 45678.9); assert.strictEqual(p[0].ultimos4, '1111');
  assert.strictEqual(p[0].fecha, fc.toISOString());
  const c = ctx.parsearCorreoBanco('Estimado(a) Cliente: Se realizó un crédito a la cuenta bancaria en CRC terminada en *******2222, por un monto de CRC 45,678.90. La transacción se realizó el día 02-11-2026 20:07:42', '', fc, 'Davibank');
  assert.strictEqual(c[0].tipoMov, 'Transferencia'); assert.strictEqual(c[0].cuenta4, '2222'); assert.match(c[0].comercio, /^Entró a/); assert.strictEqual(c[0].monto, 45678.9);
  const db = ctx.parsearCorreoBanco('Se realizó un débito a la cuenta bancaria en CRC terminada en *******2222, por un monto de CRC 45,678.90. La transacción se realizó el día 02-11-2026 20:09:42', '', fc, 'Davibank');
  assert.match(db[0].comercio, /^Salió de/); assert.notStrictEqual(db[0].autorizacion, c[0].autorizacion);
  assert.strictEqual(ctx.parsearCorreoBanco('Envío exitoso de débito en tiempo real. Usted realizó una transacción SINPE…', '', fc, 'Davibank').length, 0);
  assert.strictEqual(ctx.extraerMonto('por CRC 32978.54 el día').monto, 32978.54);
  assert.strictEqual(ctx.extraerMonto('Monto: ₡12.345,67').monto, 12345.67);
  assert.strictEqual(ctx.extraerMonto('USD 25.00').monto, 25);
  const dtr = ctx.parsearSINPE('Estimado (a): ANA PRUEBA MORA\nLe informamos que se le ha debitado de su cuenta BCR la siguiente transacción Débito Tiempo Real Entrante:\nNúmero de referencia: 123456789\nNombre Cliente Origen: PRUEBA MORA-\nMonto: 45,678.90 Colones\nEsta transacción fue realizada el 02/11/2026 a las 08:07:01 PM');
  assert.strictEqual(dtr.tipoMov, 'Transferencia'); assert.match(dtr.comercio, /^Débito en tiempo real/); assert.strictEqual(new Date(dtr.fecha).getUTCHours(), 2);
});

// ---------------- v2.5.7 ----------------
prueba('2.5.7 · cada tarjeta se paga desde la cuenta de su banco; nombres sin importar mayúsculas', () => {
  const b = { cuentas: [
    { nombre: 'Visa Uno', tipo: 'Tarjeta de crédito', banco: 'Banco Uno', activa: true },
    { nombre: 'Master Dos', tipo: 'Tarjeta de crédito', banco: 'Banco Dos', activa: true },
    { nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', banco: 'Banco Uno', moneda: 'CRC', activa: true, saldoCRC: 100000, fechaSaldo: '2026-10-31T12:00:00-06:00' },
    { nombre: 'Ahorros Dos', tipo: 'Cuenta de ahorro', banco: 'Banco Dos', moneda: 'CRC', activa: true, saldoCRC: 50000, fechaSaldo: '2026-10-31T12:00:00-06:00' }],
    movimientos: [
      { fila: 40, fecha: '2026-11-02T10:00:00-06:00', tipo: 'Pago de tarjeta', monto: 20000, moneda: 'CRC', cuenta: 'master dos' },
      { fila: 41, fecha: '2026-11-02T11:00:00-06:00', tipo: 'Gasto', monto: 1000, moneda: 'CRC', cuenta: 'AHORROS UNO' }],
    prestamo: { pagos: [] } };
  const o = C.origenes(b, { principal: 'ahorros uno' });
  assert.strictEqual(o.principal, 'Ahorros Uno');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(o.porTarjeta)), { 'Visa Uno': 'Ahorros Uno', 'Master Dos': 'Ahorros Dos' });
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[3], o).CRC, 30000);   // la Master se pagó desde Ahorros Dos
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[2], o).CRC, 99000);   // "AHORROS UNO" es la misma cuenta
  const o2 = C.origenes(b, { porTarjeta: { 'MASTER DOS': 'Ahorros Uno' } });
  assert.strictEqual(o2.porTarjeta['Master Dos'], 'Ahorros Uno');
});
prueba('2.5.7 · ¿de dónde vino esta plata?: sin contestar pregunta; de otra cuenta, o de fuera de la app', () => {
  const b = { cuentas: [
    { nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', banco: 'Banco Uno', moneda: 'CRC', activa: true, saldoCRC: 100000, fechaSaldo: '2026-10-31T12:00:00-06:00' },
    { nombre: 'Ahorros Dos', tipo: 'Cuenta de ahorro', banco: 'Banco Dos', moneda: 'CRC', activa: true, saldoCRC: 0, fechaSaldo: '2026-10-31T12:00:00-06:00' },
    { nombre: 'Ahorros Tres', tipo: 'Cuenta de ahorro', banco: 'Banco Tres', moneda: 'CRC', activa: true, saldoCRC: 7000, fechaSaldo: '2026-10-31T12:00:00-06:00' }],
    movimientos: [{ fila: 50, fecha: '2026-11-02T10:00:00-06:00', tipo: 'Transferencia', monto: 5000, moneda: 'CRC', cuenta: 'Ahorros Dos', comercio: 'Entró a cuenta ••2222' }],
    prestamo: { pagos: [] } };
  let o = C.origenes(b, {});
  let ef = C.efectosCuentas(b, o);
  assert.strictEqual(ef.sinOrigen.length, 1);
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[0], o).CRC, 95000);   // sin contestar: de la principal
  b.movimientos[0].desde = 'Cuenta: Ahorros Tres | Sobre: Ventas';
  assert.deepStrictEqual(JSON.parse(JSON.stringify(C.leerDesde(b.movimientos[0]))), { tipo: 'cuenta', cuenta: 'Ahorros Tres', sobre: 'Ventas' });
  assert.strictEqual(C.efectosCuentas(b, o).sinOrigen.length, 0);
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[0], o).CRC, 100000);
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[2], o).CRC, 2000);
  b.movimientos[0].desde = 'Fuera de la app';
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[0], o).CRC, 100000);
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[2], o).CRC, 7000);
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[1], o).CRC, 5000);
});

// ---------------- v2.5.8 ----------------
prueba('2.5.8 · pago de servicio Davibank en una sola línea o con la tabla desordenada', () => {
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script', 'Parser.js'), 'utf8'), ctx);
  const fc = new Date('2026-11-03T17:17:00Z');
  const linea = 'DAVIbank le notifica que nuestro cliente PRUEBA, ANA, ha realizado un pago de servicios con las siguientes características: CABLE DE PRUEBA SA - INTERNET Nombre Identificador Fecha Vito. Monto Prueba Ana 1234567 10/11/2026 ₡ 12,345.67 Por su seguridad:';
  const desorden = 'pago de servicios con las siguientes características:\nCABLE DE PRUEBA SA - INTERNET\nNombre\nIdentificador Fecha Vito. Monto\nPrueba Ana 1234567\n\nPor su seguridad:\n\n10/11/2026 ₡ 12,345.67\n';
  [linea, desorden].forEach((t) => {
    const r = ctx.parsearCorreoBanco(t, '', fc, 'Davibank');
    assert.strictEqual(r.length, 1); assert.strictEqual(r[0].comercio, 'CABLE DE PRUEBA SA - INTERNET'); assert.strictEqual(r[0].monto, 12345.67);
    assert.ok(r[0].esServicio); assert.strictEqual(r[0].fecha, fc.toISOString());
  });
  // lector general: una fecha futura (vencimiento) no se usa
  const g = ctx.parsearCorreo('Monto: CRC 5,000.00 vence 10/11/2026', fc, 'X');
  assert.strictEqual(g.fecha, fc.toISOString());
});

// ---------------- v2.5.9 ----------------
prueba('2.5.9 · dos días seguidos con el mismo monto (BCR → Davibank → pago) no se cruzan', () => {
  const b = { cuentas: [
    { nombre: 'Master Dos', tipo: 'Tarjeta de crédito', banco: 'Banco Dos', activa: true },
    { nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', banco: 'Banco Uno', moneda: 'CRC', activa: true, saldoCRC: 100000, fechaSaldo: '2026-11-01T12:00:00-06:00' },
    { nombre: 'Ahorros Dos', tipo: 'Cuenta de ahorro', banco: 'Banco Dos', moneda: 'CRC', activa: true, saldoCRC: 0, fechaSaldo: '2026-11-01T12:00:00-06:00' }],
    movimientos: [
      // día 1: salida del Uno + entrada al Dos + pago (sin débito del Dos)
      { fila: 60, fecha: '2026-11-02T20:07:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Uno', comercio: 'Transferencia a Dos' },
      { fila: 61, fecha: '2026-11-02T09:10:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Dos', comercio: 'Entró desde Uno' },
      { fila: 62, fecha: '2026-11-02T20:09:00-06:00', tipo: 'Pago de tarjeta', monto: 30000, moneda: 'CRC', cuenta: 'Master Dos' },
      // día 2: entrada al Dos (de dónde vino: Uno) + débito del Dos + pago
      { fila: 63, fecha: '2026-11-03T13:07:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Dos', comercio: 'ENTRO DESDE UNO', desde: 'Cuenta: Ahorros Uno' },
      { fila: 64, fecha: '2026-11-03T13:08:00-06:00', tipo: 'Transferencia', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Dos', comercio: 'Salió de cuenta Dos' },
      { fila: 65, fecha: '2026-11-03T13:07:30-06:00', tipo: 'Pago de tarjeta', monto: 30000, moneda: 'CRC', cuenta: 'Master Dos' }],
    prestamo: { pagos: [] } };
  const o = C.origenes(b, {});
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[2], o).CRC, 0);          // Dos: entra, sale, entra, sale
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[1], o).CRC, 100000 - 60000);   // Uno: dos veces la plata que pasó
});

// ---------------- v2.5.10 ----------------
prueba('2.5.10 · correos Davibank como llegan de Gmail (negritas con *, HTML con &#x20A1; y espacios antes del punto)', () => {
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script', 'Parser.js'), 'utf8'), ctx);
  const fc = new Date('2026-11-03T19:08:31Z');
  const plano = 'Estimado(a) Cliente: \nSe realizó un crédito a la cuenta bancaria en CRC terminada en ********2222*, \npor un monto de *CRC 12,345.67*. La transacción se realizó el día *03-11-2026 \n13:07:09* \n';
  const html = '<h1>Estimado(a) Cliente:</h1><br/>Se realizó un débito a la cuenta bancaria en CRC terminada en <strong>*******2222</strong>, por un monto de <strong>CRC 12,345.67</strong>. La transacción se realizó el día <strong>03-11-2026 13:08:12</strong> <br/>';
  const a = ctx.parsearCorreoBanco(plano, '', fc, 'Davibank'), b = ctx.parsearCorreoBanco('', html, fc, 'Davibank');
  assert.strictEqual(a[0].tipoMov, 'Transferencia'); assert.match(a[0].comercio, /^Entró/); assert.strictEqual(a[0].cuenta4, '2222'); assert.strictEqual(a[0].monto, 12345.67);
  assert.strictEqual(b[0].tipoMov, 'Transferencia'); assert.match(b[0].comercio, /^Salió/);
  const serv = 'DAVIbank le notifica que nuestro cliente *PRUEBA, ANA*, ha \nrealizado un pago de servicios con las siguientes características:\n\n*CABLE DE PRUEBA SA * - CABLE E INTERNET\n*Nombre*\n\nPrueba Ana\n*Identificador*\n\n111222333-444\n*Fecha Vito.*\n\n10/11/2026\n*Monto*\n\n₡ 12,345.67\n\n*Por su seguridad:*';
  const s = ctx.parsearCorreoBanco(serv, '', fc, 'Davibank');
  assert.strictEqual(s[0].comercio, 'CABLE DE PRUEBA SA - CABLE E INTERNET'); assert.strictEqual(s[0].monto, 12345.67); assert.match(s[0].nota, /111222333-444/);
  const servHtml = 'pago de servicios con las siguientes caracter&iacute;sticas:</td></tr><tr><td><div><strong>CABLE DE PRUEBA SA </strong> -  CABLE</div><table><tr><td><strong>Nombre</strong><p>Prueba Ana</p></td><td><strong>Identificador</strong><p>5556667</p></td><td><strong>Fecha Vito.</strong><p>10/11/2026</p></td><td><strong>Monto</strong><p>&#x20A1; 30,465</p></td></tr></table>';
  const h = ctx.parsearCorreoBanco('', servHtml, fc, 'Davibank');
  assert.strictEqual(h[0].monto, 30465); assert.strictEqual(h[0].comercio, 'CABLE DE PRUEBA SA - CABLE');
});

// ---------------- v2.6.0 ----------------
prueba('2.6.0 · foto de transferencia recibida en una cuenta tuya → Ingreso en esa cuenta', () => {
  global.self = global;
  const L = require('../web/js/lector.js');
  const cuentas = [{ nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', moneda: 'CRC', ultimos4: '1111', activa: true }, { nombre: 'Ahorros Dos', tipo: 'Cuenta de ahorro', moneda: 'CRC', ultimos4: '2222', activa: true }];
  const txt = 'Comprobante de transferencia\nCuenta origen: AH CR99 0000 0000 0000 0099 99\nCuenta destino: CR11 0000 0000 0000 0011 11\nMonto: ₡12.345,00\nFecha: 03/11/2026 12:53\nNúmero de referencia: 1234567';
  const r = L.leerComprobante(txt, cuentas);
  assert.strictEqual(r.tipo, 'Ingreso'); assert.strictEqual(r.cuenta, 'Ahorros Uno');
  const r2 = L.leerComprobante(txt.replace('CR99 0000 0000 0000 0099 99', 'CR22 0000 0000 0000 0022 22'), cuentas);
  assert.strictEqual(r2.tipo, 'Transferencia'); assert.strictEqual(r2.cuenta, 'Ahorros Uno'); assert.match(r2.comercio, /^Entró desde Ahorros Dos/);
});

// ---------------- v2.7.0 ----------------
prueba('2.7.0 · tarjeta que cobra todo en colones: el cobro en $ se pasa a ₡ (monto estimado)', () => {
  const ctx = { console: { log() {} }, PropertiesService: { getScriptProperties: () => ({ getProperty: () => null }) },
    SpreadsheetApp: { getActive: () => ({ getSheetByName: (n) => n === 'Config' ? { getRange: () => ({ getValue: () => 500 }) } : null }) } };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
  const cuentas = [{ 'Nombre (único)': 'Tarjeta Colones', 'Tipo': 'Tarjeta de crédito', 'Últimos 4': '1111', 'Límite ₡': 500000, 'Límite $': '' },
    { 'Nombre (único)': 'Tarjeta Dólares', 'Tipo': 'Tarjeta de crédito', 'Últimos 4': '2222', 'Límite ₡': 500000, 'Límite $': 1000 }];
  const f = ctx.completarCompra_({ fecha: '2026-11-03T12:00:00Z', comercio: 'NETFLIX.COM', monto: 15.99, moneda: 'USD', ultimos4: '1111' }, cuentas, []);
  assert.strictEqual(f['Moneda'], 'CRC'); assert.strictEqual(f['Monto'], 7995); assert.match(f['Nota'], /Cobro original \$15,99 · TC 500 · monto estimado/);
  const g = ctx.completarCompra_({ fecha: '2026-11-03T12:00:00Z', comercio: 'NETFLIX.COM', monto: 15.99, moneda: 'USD', ultimos4: '2222' }, cuentas, []);
  assert.strictEqual(g['Moneda'], 'USD'); assert.strictEqual(g['Monto'], 15.99);
});
prueba('2.7.0 · foto "Transferencia entre cuentas" con la etiqueta partida: destino tuyo → Ingreso', () => {
  global.self = global;
  const L = require('../web/js/lector.js');
  const cuentas = [{ nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', moneda: 'CRC', ultimos4: '1111', activa: true }];
  const t = 'Comprobante\nTransferencia entre cuentas\nDocumento 1234567\nCuenta AH CR00015202001000000999\norigen PERSONA DE PRUEBA\nCuenta AH CR00015202001000001111\ndestino YO MISMO PRUEBA\nMonto transferido ₡6.700,00\nMotivo CUOTA SERVICIO';
  const r = L.leerComprobante(t, cuentas);
  assert.strictEqual(r.tipo, 'Ingreso'); assert.strictEqual(r.cuenta, 'Ahorros Uno'); assert.strictEqual(r.comercio, 'De Persona De Prueba · CUOTA SERVICIO'); assert.strictEqual(r.monto, 6700);
});

// ---------------- v2.8.0 · espejo del banco ----------------
prueba('2.8.0 · sacar/meter mueven el sobre y el disponible, no el total; la salida "con lo sacado" no baja el sobre otra vez', () => {
  const b = { sobresDesde: '2026-11-01T00:00:00-06:00', cuentas: [
    { nombre: 'Visa Uno', tipo: 'Tarjeta de crédito', banco: 'Uno', activa: true },
    { nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', banco: 'Uno', moneda: 'CRC', activa: true, saldoCRC: 1000, fechaSaldo: '2026-11-01T12:00:00-06:00' }],
    sobres: [{ nombre: 'IPTV', moneda: 'CRC', saldoInicial: 50000 }],
    movimientos: [
      { fila: 1, fecha: '2026-11-02T10:00:00-06:00', tipo: 'Gasto', monto: 8000, moneda: 'CRC', cuenta: 'Visa Uno', comercio: 'Netflix', sobre: 'IPTV' },
      { fila: 2, fecha: '2026-11-03T07:05:00-06:00', tipo: 'Sobre → disponible', monto: 30000, moneda: 'CRC', cuenta: 'Ahorros Uno', comercio: 'Sacado del sobre IPTV · para pagar Visa Uno', sobre: 'IPTV', autorizacion: 'SOB-1' },
      { fila: 3, fecha: '2026-11-03T07:10:00-06:00', tipo: 'Pago de tarjeta', monto: 30000, moneda: 'CRC', cuenta: 'Visa Uno' }],
    sobresMov: [], prestamo: { pagos: [] } };
  // 50.000 + lo sacado: el disponible de 1.000 sube a 31.000 y vuelve a 1.000 con el pago
  let an = C.analizarSobres(b);
  assert.strictEqual(an.pendientes.length, 1);  // el pago (sale de la cuenta) pregunta; la compra con tarjeta no
  assert.strictEqual(an.pendientes[0].mov.fila, 3);
  b.sobresMov.push({ fecha: '2026-11-03T07:10:00-06:00', sobre: '', monto: -30000, tipo: 'Del disponible', movimiento: 3, nota: 'Con lo sacado de IPTV · SOB-1' });
  an = C.analizarSobres(b);
  assert.strictEqual(an.pendientes.length, 0);
  const s = C.saldosSobres(b, new Date(2026, 10, 1), new Date(2026, 10, 4)).lista[0];
  assert.strictEqual(s.saldo, 20000);   // 50.000 − 30.000 (Netflix con tarjeta no lo tocó)
  const o = C.origenes(b, {});
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[1], o).CRC, 1000 - 30000);   // el total baja solo por el pago
});
prueba('2.8.0 · disponible anotado: lo que se anote después con fecha anterior no descuadra', () => {
  const b = { sobresDesde: '2026-11-01T00:00:00-06:00', cuentas: [
    { nombre: 'Ahorros Uno', tipo: 'Cuenta de ahorro', banco: 'Uno', moneda: 'CRC', activa: true, saldoCRC: 329.33, fechaSaldo: '2026-11-04T12:00:00-06:00' }],
    sobres: [{ nombre: 'IPTV', moneda: 'CRC', saldoInicial: 10000 }],
    movimientos: [], sobresMov: [], prestamo: { pagos: [] } };
  const o = C.origenes(b, { dispAnotado: { 'Ahorros Uno': '2026-11-04' } });
  assert.strictEqual(C.saldoCuenta(b, b.cuentas[0], o).CRC, 10329.33);   // total = disponible + sobres
  // después se anota el ingreso de ayer y se mete al sobre: el disponible sigue en 329,33
  b.movimientos.push({ fila: 7, fecha: '2026-11-03T16:56:00-06:00', tipo: 'Ingreso', monto: 6700, moneda: 'CRC', cuenta: 'Ahorros Uno' });
  b.movimientos.push({ fila: 8, fecha: '2026-11-03T16:57:00-06:00', tipo: 'Disponible → sobre', monto: 6700, moneda: 'CRC', cuenta: 'Ahorros Uno', sobre: 'IPTV' });
  b.sobresMov.push({ fecha: '2026-11-03', sobre: '', monto: 6700, tipo: 'Al sobre', movimiento: 7 });
  const total = C.saldoCuenta(b, b.cuentas[0], o).CRC, sobres = C.saldosSobres(b, new Date(2026, 10, 1), new Date(2026, 10, 4)).total.CRC;
  assert.strictEqual(Math.round((total - sobres) * 100) / 100, 329.33);
});
