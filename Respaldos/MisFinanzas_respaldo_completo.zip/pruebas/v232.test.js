// v2.3.2: pago de tarjeta "sin sobre" (no salió de ningún sobre).  TZ=America/Costa_Rica node pruebas/v232.test.js
const assert = require('assert');
const C = require('../web/js/calculos.js');
const base = () => ({
  sobresDesde: '2026-10-01', cuentas: [{ nombre: 'Visa', tipo: 'Tarjeta de crédito' }],
  sobres: [{ nombre: 'Super', moneda: 'CRC', saldoInicial: 50000 }],
  movimientos: [
    { fila: 5, fecha: '2026-10-10T12:00:00-06:00', monto: 8000, moneda: 'CRC', tipo: 'Gasto', cuenta: 'Visa', comercio: 'Tienda' },
    { fila: 6, fecha: '2026-10-20T12:00:00-06:00', monto: 20000, moneda: 'CRC', tipo: 'Pago de tarjeta', cuenta: 'Visa', comercio: 'Pago' }],
  sobresMov: [{ fecha: '2026-10-10', sobre: 'Super', monto: -8000, tipo: 'Compra con tarjeta', movimiento: 5 }]
});
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.message); process.exitCode = 1; } }
prueba('v2.8: la compra con tarjeta asignada antes se ignora; el pago pide todo', () => {
  const a = C.analizarSobres(base());
  assert.strictEqual(a.pendientes.length, 1); assert.strictEqual(a.pendientes[0].falta, 20000);
  assert.strictEqual(a.efectos.filter(e => e.sobre === 'Super').length, 0);
});
prueba('resto "sin sobre": el pago queda cerrado y ningún sobre baja de más', () => {
  const d = base(); d.sobresMov.push({ fecha: '2026-10-20', sobre: '', monto: -20000, tipo: 'Pago tarjeta', movimiento: 6 });
  const a = C.analizarSobres(d);
  assert.strictEqual(a.pendientes.length, 0);
  const suma = a.efectos.filter(e => e.sobre === 'Super').reduce((s, e) => s + e.monto, 0);
  assert.strictEqual(suma, 0);
});
console.log(ok + ' pruebas correctas');
