// v2.14.0: al abrir todo al día (#61), bancos, recurrentes, archivar sobres y fondos, tipo de cambio (#58d–g, #59).  TZ=America/Costa_Rica node pruebas/v2140.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) { const h = hojaSim(nombre); h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]); filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f])); return h; }
const F = (d) => new Date(d + 'T12:00:00-06:00');
const cfg = tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado', 'Categorías'], [['BCR', 'bcr@ejemplo.com', 'Activo', 'Supermercado'], ['Davibank', '[PENDIENTE: correo de Davibank]', 'Por completar', 'Mascotas'], ['', '', '', 'Salud']]);
cfg.getRange(15, 1, 1, 2).setValues([['Tipo de cambio de referencia (₡ por $1)', 505]]);
const hojas = {
  'Config': cfg,
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'], [
    [F('2026-10-01'), 'VETERINARIA', '', 10000, 'CRC', 'Gasto', 'Tarjeta A', 'Mascotas', '', 'Correo', 'a1', '']]),
  'Recurrentes': tabla('Recurrentes', 4, ['Descripción', 'Monto', 'Moneda', 'Tarjeta / cuenta', 'Día del mes', 'Categoría', 'Sobre', 'Activo'], [['Suscripción demo', 2.99, 'USD', 'Tarjeta A', 12, 'Suscripciones', '', 'Sí'], ['Colegio demo', 120000, 'CRC', 'Ahorros', 3, 'Educación', '', 'Sí']]),
  'Sobres': tabla('Sobres', 4, ['Sobre', 'Moneda', 'Asignado por mes', 'Tipo', 'Salió este mes', 'Saldo actual', '% usado', 'Estado', 'Notas', 'Saldo inicial', 'Ajuste del reparto', 'Meta'], [['Super', 'CRC', 100000, 'Variable'], ['Vacaciones viejas', 'CRC', 20000, 'Variable']]),
  'Fondos': tabla('Fondos', 4, ['Subcuenta', 'Fondo', 'Moneda', 'Saldo', 'Fecha del saldo', 'Meta', 'Intereses (último ajuste)', 'Notas'], [['Marchamo', 'BCR Mixto', 'CRC', 0, F('2026-10-01'), '', 0, '']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas', getId: () => 'LIBRO' };
const props = { CLAVE_APP: 'abc' }, triggers = [];
const ctx = { console: { log() {} }, SpreadsheetApp: { getActive: () => libro, flush() {} },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] === undefined ? null : props[k], setProperty: (k, v) => { props[k] = v; }, deleteProperty: (k) => { delete props[k]; } }) },
  CacheService: { getScriptCache: () => ({ get: () => null, put() {} }) },
  ContentService: { createTextOutput: (t) => ({ t, setMimeType() { return this; } }), MimeType: { JSON: 'json' } },
  ScriptApp: { getProjectTriggers: () => triggers.map(h => ({ getHandlerFunction: () => h })), newTrigger: (h) => ({ forSpreadsheet: () => ({ onEdit: () => ({ create() { triggers.push(h); } }) }) }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) } };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 14).join('\n   ')); process.exitCode = 1; } }
const J = (x) => JSON.parse(JSON.stringify(x));
const post = (o) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(Object.assign({ clave: 'abc' }, o)) } }).t);

prueba('#61 abrirApp: la primera vez trae los datos y la marca; con la misma marca responde "sin cambios"', () => {
  ctx.obtenerDatos_ = () => JSON.stringify({ marca: ctx.marcaDatos_(), x: 1 });   // la lectura completa ya tiene sus propias pruebas
  const r1 = post({ accion: 'abrirApp', args: [''] }).resultado;
  assert.ok(r1.datos && !r1.sinCambios); assert.strictEqual(r1.acceso.pinActivo, false);
  assert.deepStrictEqual(triggers, ['alEditarHoja'], 'instala una sola vez el aviso de edición de la hoja');
  const r2 = post({ accion: 'abrirApp', args: [r1.marca] }).resultado;
  assert.ok(r2.sinCambios && !r2.datos && r2.hoy);
  post({ accion: 'abrirApp', args: [r1.marca] }); assert.strictEqual(triggers.length, 1);
});
prueba('#61 cualquier escritura (o editar la hoja a mano) cambia la marca; leer no', () => {
  const m0 = ctx.marcaDatos_();
  post({ accion: 'obtenerAjustes', args: [] }); assert.strictEqual(ctx.marcaDatos_(), m0, 'leer no cambia');
  props.DATOS_VER = '1';
  post({ accion: 'guardarCategorias', args: [['Supermercado', 'Mascotas', 'Salud', 'Viajes']] });
  assert.notStrictEqual(ctx.marcaDatos_(), '1');
  props.DATOS_VER = '2'; ctx.alEditarHoja({}); assert.notStrictEqual(ctx.marcaDatos_(), '2');
  const r = post({ accion: 'abrirApp', args: ['2'] }).resultado; assert.ok(r.datos, 'con marca vieja trae todo');
});
prueba('#61 con PIN y sin sesión: no da datos, solo dice que está bloqueado', () => {
  props.PIN_HASH = 'x';
  const r = post({ accion: 'abrirApp', args: [''] }).resultado; assert.ok(r.bloqueado && !r.datos && r.acceso.pinActivo);
  delete props.PIN_HASH;
});
prueba('#61 revisarAlAbrir: solo si pasaron 2 min; si entra algo, cambia la marca', () => {
  let n = 0; ctx.leerCorreos_ = () => { n++; return { compras: 2, pagos: 0, duplicados: 0, revisar: 0, detalle: [] }; }; ctx.tareasDespuesDeLeer_ = () => {};
  props.DATOS_VER = '5'; props.REVISION_APP = String(Date.now() - 60000);
  let r = post({ accion: 'revisarAlAbrir', args: [] }).resultado; assert.ok(r.saltada); assert.strictEqual(n, 0);
  props.REVISION_APP = String(Date.now() - 3 * 60000);
  r = post({ accion: 'revisarAlAbrir', args: [] }).resultado; assert.strictEqual(r.compras, 2); assert.strictEqual(n, 1); assert.notStrictEqual(r.marca, '5');
  r = post({ accion: 'revisarAlAbrir', args: [] }).resultado; assert.ok(r.saltada, 'recién revisado');
  r = post({ accion: 'revisarAlAbrir', args: [true] }).resultado; assert.strictEqual(n, 2, 'forzado');
});
prueba('#58d bancos: lista (el pendiente sin correo), agregar, pausar y quitar sin tocar otras columnas', () => {
  let l = J(ctx.bancosConfig_());
  assert.deepStrictEqual(l.map(b => [b.fila, b.nombre, b.activo, b.pendiente]), [[5, 'BCR', true, false], [6, 'Davibank', false, true]]);
  assert.ok(!l.some(b => /Tipo de cambio/.test(b.nombre)), 'la fila 15 no es un banco');
  l = J(ctx.guardarBanco_({ fila: 6, nombre: 'Davibank', correo: 'alertas@davibank.cr', activo: true }));
  assert.ok(l[1].activo && !l[1].pendiente);
  l = J(ctx.guardarBanco_({ nombre: 'Banco Nacional', correo: 'alertas@bncr.fi.cr', activo: true }));
  assert.strictEqual(l[2].fila, 7);
  assert.throws(() => ctx.guardarBanco_({ nombre: 'Otro', correo: 'ALERTAS@bncr.fi.cr' }), /ya está/);
  assert.throws(() => ctx.guardarBanco_({ nombre: 'Otro', correo: 'sin-arroba' }), /no parece válido/);
  l = J(ctx.guardarBanco_({ fila: 7, nombre: 'Banco Nacional', correo: 'alertas@bncr.fi.cr', activo: false }));
  assert.strictEqual(hojas.Config.getRange(7, 3).getValue(), 'Inactivo');
  assert.deepStrictEqual(J(ctx.bancosActivos_()).map(b => b.nombre), ['BCR', 'Davibank'], 'pausado no se lee');
  l = J(ctx.quitarBanco_(7, { nombre: 'Banco Nacional' })); assert.strictEqual(l.length, 2);
  assert.strictEqual(hojas.Config.getRange(5, 4).getValue(), 'Supermercado', 'las categorías siguen');
  assert.strictEqual(hojas.Config.getRange(15, 2).getValue(), 505);
});
prueba('#58e recurrentes: leer, nuevo al final, pausar y borrar sin correr las filas', () => {
  let l = J(ctx.leerRecurrentes_()); assert.strictEqual(l.length, 2); assert.strictEqual(l[0].dia, 12);
  const f = ctx.guardarRecurrente_({ descripcion: 'Gimnasio demo', monto: 25000, moneda: 'CRC', cuenta: 'Tarjeta A', dia: 5, categoria: 'Salud', sobre: '', activo: true });
  assert.strictEqual(f, 7);
  ctx.guardarRecurrente_({ fila: 5, descripcion: 'Suscripción demo', monto: 3.49, moneda: 'USD', cuenta: 'Tarjeta A', dia: 12, activo: false });
  l = J(ctx.leerRecurrentes_()); assert.strictEqual(l[0].monto, 3.49); assert.strictEqual(l[0].activo, false);
  ctx.eliminarRecurrente_(6, { descripcion: 'Colegio demo' });
  l = J(ctx.leerRecurrentes_()); assert.deepStrictEqual(l.map(r => [r.fila, r.descripcion]), [[5, 'Suscripción demo'], [7, 'Gimnasio demo']]);
  assert.throws(() => ctx.eliminarRecurrente_(7, { descripcion: 'Otro' }), /cambió/);
  assert.throws(() => ctx.guardarRecurrente_({ descripcion: 'X', monto: 1, dia: 40 }), /1 a 31/);
  const n = ctx.guardarRecurrente_({ descripcion: 'Nuevo', monto: 1000, dia: 1 }); assert.strictEqual(n, 8, 'no reusa la fila borrada');
});
prueba('#58f/#58g archivar un sobre (reparto a 0) y una subcuenta; volver a activar', () => {
  ctx.archivarSobre_(6, true);
  const s = J(ctx.leerTabla_('Sobres', 'Sobre').filas)[1]; assert.strictEqual(s['Archivado'], 'Sí'); assert.strictEqual(s['Asignado por mes'], 0);
  ctx.archivarSobre_(6, false); assert.strictEqual(J(ctx.leerTabla_('Sobres', 'Sobre').filas)[1]['Archivado'], '');
  ctx.archivarFondo_(5, true);
  assert.strictEqual(J(ctx.leerFondos_())[0].archivada, true);
  ctx.archivarFondo_(5, false); assert.strictEqual(J(ctx.leerFondos_())[0].archivada, false);
});
prueba('#59 tipo de cambio desde la app (con límites)', () => {
  assert.strictEqual(ctx.guardarTipoCambio_(512.5), 512.5);
  assert.strictEqual(hojas.Config.getRange(15, 2).getValue(), 512.5);
  assert.throws(() => ctx.guardarTipoCambio_(5), /raro/);
});
console.log('\n' + ok + ' pruebas correctas');
