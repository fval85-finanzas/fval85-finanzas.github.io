// v2.11.0: cuotas tasa cero al corte (#51).  TZ=America/Costa_Rica node pruebas/v2110.test.js
const assert = require('assert');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 8).join('\n   ')); process.exitCode = 1; } }
const tj = { fila: 2, nombre: 'Tarjeta A', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, diaCorte: 15, diaPago: 2, saldoCRC: 52300, saldoUSD: 0, fechaSaldo: '2026-10-16T12:00:00-06:00' };
const d = {
  tipoCambio: 500, cuentas: [tj],
  tasaCero: [{ fila: 7, descripcion: 'TV DEMO', tarjeta: 'Tarjeta A', fechaCompra: '2026-10-20T12:00:00-06:00', monto: 120000, moneda: 'CRC', meses: 6, primeraCuota: '2026-11-02T12:00:00-06:00', abonos: [] }],
  movimientos: [
    { fila: 10, fecha: '2026-10-20T12:00:00-06:00', tipo: 'Compra tasa cero', monto: 120000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'TV DEMO' },
    { fila: 11, fecha: '2026-10-25T12:00:00-06:00', tipo: 'Gasto', monto: 10000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'SUPER' },
    { fila: 12, fecha: '2026-11-17T12:00:00-06:00', tipo: 'Gasto', monto: 5000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'FARMACIA' }
  ]
};
const hoy = new Date(2026, 10, 20, 12);
prueba('cada cuota se carga en el corte anterior a su fecha de pago', () => {
  const l = C.cuotasAlCorte(d, tj, new Date(2026, 9, 1), hoy);
  assert.strictEqual(C.cuotasAlCorte(d, tj, new Date(2026, 9, 16), hoy).length, 1, 'lo de antes del saldo puesto no se carga');
  assert.strictEqual(l.length, 2);   // cortes 15 oct (pago 2 nov) y 15 nov (pago 2 dic)
  assert.strictEqual(l[0].n, 1); assert.strictEqual(l[0].cuota, 20000); assert.strictEqual(l[0].aut, 'TC-7-1'); assert.strictEqual(l[1].n, 2);
  assert.strictEqual(l[0].corte.getDate(), 15); assert.strictEqual(l[0].corte.getMonth(), 9);   // pago 2 nov → corte 15 oct
  assert.strictEqual(C.cuotasAlCorte(d, tj, new Date(2026, 9, 16), new Date(2027, 3, 30)).length, 5);
  assert.strictEqual(C.cuotasAlCorte(d, Object.assign({}, tj, { diaCorte: null }), null, hoy).length, 0);
});
prueba('la compra tasa cero ya no suma completa; las cuotas al corte sí', () => {
  let dt = C.deudaTarjeta(d, tj);
  assert.strictEqual(dt.CRC, 52300 + 10000 + 5000);
  const d2 = Object.assign({}, d, { movimientos: d.movimientos.concat([{ fila: 13, fecha: '2026-11-15T12:00:00-06:00', tipo: 'Cuota tasa cero', monto: 20000, moneda: 'CRC', cuenta: 'Tarjeta A', autorizacion: 'TC-7-2' }]) });
  dt = C.deudaTarjeta(d2, tj);
  assert.strictEqual(dt.CRC, 52300 + 10000 + 5000 + 20000); assert.strictEqual(dt.cuotas.CRC, 20000); assert.strictEqual(dt.nCuotas, 1);
  const pp = C.porPagarTarjeta(d2, tj, hoy);
  assert.strictEqual(pp.CRC, 52300 + 10000 + 20000, 'pago de contado: sin la compra del 17 nov (después del corte), con la cuota del 15');
});
prueba('con saldo a favor, la cuota se carga igual y lo consume', () => {
  const t2 = Object.assign({}, tj, { saldoCRC: -60000, fechaSaldo: '2026-11-10T12:00:00-06:00' });
  const d2 = Object.assign({}, d, { cuentas: [t2], movimientos: [{ fila: 13, fecha: '2026-11-15T12:00:00-06:00', tipo: 'Cuota tasa cero', monto: 45833, moneda: 'CRC', cuenta: 'Tarjeta A' }] });
  assert.strictEqual(C.deudaTarjeta(d2, t2).CRC, -14167);
});
prueba('saldo tasa cero aparte y próximas cuotas', () => {
  const st = C.saldoTasaCeroTarjeta(d, tj, hoy);
  assert.strictEqual(Math.round(st.CRC), 80000); assert.strictEqual(Math.round(st.proximo.CRC), 20000); assert.strictEqual(st.n, 1);
  assert.strictEqual(st.proxCorte.getDate(), 15); assert.strictEqual(st.proxCorte.getMonth(), 11);
});
prueba('no cuenta como gasto del mes (ya está en cuotas tasa cero)', () => {
  const d2 = Object.assign({}, d, { movimientos: d.movimientos.concat([{ fila: 13, fecha: '2026-11-15T12:00:00-06:00', tipo: 'Cuota tasa cero', monto: 20000, moneda: 'CRC', cuenta: 'Tarjeta A' }]), sobres: [], tasaCero: d.tasaCero });
  const r = C.resumenMes(Object.assign({ tasaCero: [] }, d2), new Date(2026, 10, 1));
  assert.strictEqual(r.gastos.CRC, 5000);
});
console.log(`\n${ok} pruebas correctas`);
