// Pruebas en la computadora (sin Google). Ejecutar desde la carpeta del proyecto:
//   TZ=America/Costa_Rica node pruebas/pruebas.test.js
// Los correos de ejemplo son INVENTADOS. Agregá aquí los reales (con datos cambiados).
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const raiz = path.join(__dirname, '..', 'apps-script');
const ctx = { module: undefined, console };
vm.createContext(ctx);
for (const f of ['Parser.js', 'ParserPrestamo.js']) vm.runInContext(fs.readFileSync(path.join(raiz, f), 'utf8'), ctx);
const calcSrc = fs.readFileSync(path.join(__dirname, '..', 'web', 'js', 'calculos.js'), 'utf8').replace(/<\/?script>/g, '');
vm.runInContext(calcSrc, ctx);
const { parsearCorreo, convertirNumero, parsearComprobantePrestamo, Calc } = ctx;
const D = JSON.parse(fs.readFileSync(path.join(__dirname, 'datos-muestra.json'), 'utf8'));

let ok = 0;
function prueba(nombre, fn) {
  try { fn(); ok++; console.log('✅ ' + nombre); }
  catch (e) { console.log('❌ ' + nombre + '\n   ' + e.message); process.exitCode = 1; }
}
const cerca = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.01, `${msg}: ${a} ≠ ${b}`);

// ---------------- Lector de compras ----------------
prueba('números en distintos formatos', () => {
  assert.strictEqual(convertirNumero('12,345.67'), 12345.67);
  assert.strictEqual(convertirNumero('12.345,67'), 12345.67);
  assert.strictEqual(convertirNumero('1.234.567'), 1234567);
  assert.strictEqual(convertirNumero('8 500,00'), 8500);
});

prueba('compra BCR en colones (formato con etiquetas)', () => {
  const tx = parsearCorreo(`Notificación de transacción
Comercio: AUTOMERCADO LOS YOSES
Ciudad y país: SAN JOSE, Costa Rica
Fecha: 27/10/2026 14:35
Tarjeta: VISA ************4821
Autorización: 845123
Monto: CRC 18,450.00`, null, 'BCR');
  assert.strictEqual(tx.monto, 18450);
  assert.strictEqual(tx.moneda, 'CRC');
  assert.strictEqual(tx.comercio, 'AUTOMERCADO LOS YOSES');
  assert.strictEqual(tx.ultimos4, '4821');
  assert.strictEqual(tx.autorizacion, '845123');
  assert.strictEqual(tx.fecha, '2026-10-27T20:35:00.000Z');
});

prueba('compra en dólares', () => {
  const tx = parsearCorreo('Compra con su tarjeta terminada en 1093\nEstablecimiento: AMAZON MKTPLACE\nMonto: $25.99\nCódigo de autorización: A7K29X', null, 'Davibank');
  assert.strictEqual(tx.moneda, 'USD');
  assert.strictEqual(tx.monto, 25.99);
  assert.strictEqual(tx.ultimos4, '1093');
});

prueba('correo sin monto no es compra', () => {
  assert.strictEqual(parsearCorreo('Su estado de cuenta ya está disponible.', null, 'BCR'), null);
});

// ---------------- Comprobante del préstamo (formato provisional) ----------------
const txtEjemplo = `BANCO DE COSTA RICA
COMPROBANTE DE PAGO
Fecha: 26/09/2026
Número de comprobante: 10184152
Operación: XXXXXXXXXXXX
Tasa de interés: 6,61%
Amortización a principal:        77.725,80
Intereses corrientes:           125.883,30
Póliza de vida:                  21.000,00
Póliza de incendio:              41.766,33
Total pagado:                   266.375,43
Saldo nuevo:                 22.775.527,29`;

prueba('comprobante del préstamo: montos, fecha y comprobante', () => {
  const p = parsearComprobantePrestamo(txtEjemplo, null);
  assert.strictEqual(p.comprobante, '10184152');
  cerca(p.principal, 77725.80, 'principal');
  cerca(p.intereses, 125883.30, 'intereses');
  cerca(p.polizas, 62766.33, 'pólizas');
  cerca(p.total, 266375.43, 'total');
  assert.strictEqual(p.fecha.toISOString().slice(0, 10), '2026-09-26');
});

prueba('comprobante sin línea de principal: se calcula con el total', () => {
  const p = parsearComprobantePrestamo('Fecha 03/10/2026\nComprobante 12345678\nInteres 100,000.00\nPoliza 50,000.00\nTotal 250,000.00', null);
  cerca(p.principal, 100000, 'principal');
});

prueba('texto que no es comprobante → null', () => {
  assert.strictEqual(parsearComprobantePrestamo('Hola, gracias por usar BCR', null), null);
});

// ---------------- Cálculos (deben dar lo mismo que la hoja) ----------------
const mes = new Date(2026, 9, 1);
const hoy = new Date(D.hoy);
const res = Calc.resumenMes(D, mes);

prueba('gastos de octubre = Resumen de la hoja (₡179.300 y $38,97)', () => {
  cerca(res.gastos.CRC, 179300, 'CRC');
  cerca(res.gastos.USD, 38.97, 'USD');
  cerca(res.ingresos.CRC, 1265000, 'ingresos');
  assert.strictEqual(res.porRevisar, 1);
});

prueba('cuotas tasa cero de octubre = hoja (₡70.000 y $150)', () => {
  cerca(res.cuotasTC.CRC, 70000, 'CRC');
  cerca(res.cuotasTC.USD, 150, 'USD');
});

prueba('estado de cada compra tasa cero = hoja', () => {
  const e = D.tasaCero.map(t => Calc.estadoTasaCero(t, hoy));
  assert.deepStrictEqual(e.map(x => x.cobradas), [8, 11, 5, 10, 0]);
  assert.deepStrictEqual(e.map(x => x.estado), ['Activa', 'Activa', 'Activa', 'Terminada', 'Por iniciar']);
  cerca(e[0].saldo, 160000, 'saldo refri');
});

prueba('sobres de octubre = hoja', () => {
  const s = Calc.sobres(D, mes, res).lista;
  const por = Object.fromEntries(s.map(x => [x.nombre, x]));
  cerca(por['Supermercado'].gastado, 65300, 'super');
  cerca(por['Transporte'].gastado, 35900, 'transporte');
  cerca(por['Restaurantes'].gastado, 44300, 'restaurantes');
  cerca(por['Suscripciones'].gastado, 12.98, 'suscripciones');
  assert.strictEqual(por['Cuota casa'].estado, 'Pendiente');
  assert.strictEqual(por['Cuotas tasa cero'].estado, 'Pagado');
  const set = Calc.sobres(D, new Date(2026, 8, 1), Calc.resumenMes(D, new Date(2026, 8, 1))).lista;
  assert.strictEqual(set.find(x => x.nombre === 'Cuota casa').estado, 'Pagado', 'setiembre: pagado el 26/09');
});

prueba('gastos por tarjeta = hoja', () => {
  cerca(res.porCuenta['Visa BCR'].CRC, 167000, 'Visa');
  cerca(res.porCuenta['Mastercard Davibank'].USD, 38.97, 'Davibank $');
});

prueba('formato de dinero', () => {
  assert.strictEqual(Calc.dinero(18450, 'CRC'), '₡18.450');
  assert.strictEqual(Calc.dinero(25.99, 'USD'), '$25,99');
  assert.strictEqual(Calc.dinero(-1500.5, 'CRC'), '−₡1.500,50');
  assert.strictEqual(Calc.leerNumero('18.450,50'), 18450.5);
  assert.strictEqual(Calc.leerNumero('18450.5'), 18450.5);
  assert.strictEqual(Calc.leerNumero('18.450'), 18450);
  assert.strictEqual(Calc.leerNumero('3,56'), 3.56);
});

prueba('próxima fecha de pago', () => {
  const d = Calc.proximaFecha(9, new Date(2026, 9, 28));
  assert.strictEqual(d.toDateString(), new Date(2026, 10, 9).toDateString());
  const f = Calc.proximaFecha(31, new Date(2026, 10, 3));   // noviembre tiene 30 días
  assert.strictEqual(f.getDate(), 30);
});

// ---------------- Calculadora de préstamos ----------------
const base = { monto: 12000000, plazo: 60, tasaMensual: 0.095 / 12, tipo: 'fija', poliza: { monto: 18500, tipo: 'fijo' } };

prueba('calculadora: cuota fija, intereses y total (ejemplo del boceto)', () => {
  const r = Calc.amortizar(base);
  cerca(r.cuota, 252022.34, 'cuota');
  cerca(r.cuotaConPoliza, 270522.34, 'cuota con pólizas');
  cerca(r.totalIntereses, 3121340.14, 'intereses');
  cerca(r.totalPolizas, 1110000, 'pólizas');
  cerca(r.totalPagado, 16231340.14, 'total');
  assert.strictEqual(r.meses, 60);
  cerca(r.filas[0].interes, 95000, 'interés mes 1');
  cerca(r.filas[0].saldo, 11842977.66, 'saldo mes 1');
  cerca(r.filas[59].saldo, 0, 'saldo final');
});

prueba('calculadora: cuota decreciente', () => {
  const r = Calc.amortizar({ ...base, tipo: 'decreciente' });
  cerca(r.cuota + 18500, 313500, 'primera');
  cerca(r.ultimaCuota + 18500, 220083.33, 'última');
  cerca(r.totalIntereses, 2897500, 'intereses');
});

prueba('calculadora: abono ₡50.000 cada mes baja 12 meses y ahorra ₡655.924', () => {
  const r = Calc.amortizar({ ...base, abono: { monto: 50000, frecuencia: 'mensual', modo: 'plazo' } });
  assert.strictEqual(r.meses, 48);
  cerca(3121340.14 - r.totalIntereses, 655924.47, 'ahorro');
});

prueba('calculadora: abono bajando la cuota mantiene el plazo', () => {
  const r = Calc.amortizar({ ...base, abono: { monto: 1000000, frecuencia: 'unica', mes: 12, modo: 'cuota' } });
  assert.strictEqual(r.meses, 60);
  assert.ok(r.filas[12].cuota < r.filas[10].cuota, 'la cuota baja después del abono');
  cerca(r.filas[59].saldo, 0, 'termina en cero');
});

prueba('calculadora: tu préstamo de casa (176 cuotas al 6,56%)', () => {
  const casa = { monto: 22775527.29, plazo: 176, tasaMensual: 0.0656 / 12, tipo: 'fija' };
  const r = Calc.amortizar(casa);
  cerca(r.cuota, 201818.86, 'cuota');
  cerca(r.totalIntereses, 12744592.08, 'intereses');
  const a = Calc.amortizar({ ...casa, abono: { monto: 50000, frecuencia: 'mensual', modo: 'plazo' } });
  assert.strictEqual(176 - a.meses, 50);
});

prueba('calculadora: tasa 0% y pólizas como % del saldo', () => {
  const r = Calc.amortizar({ monto: 1200, plazo: 12, tasaMensual: 0, poliza: { monto: 0.001, tipo: 'pct' } });
  cerca(r.cuota, 100, 'cuota sin interés');
  cerca(r.filas[0].poliza, 1.2, 'póliza mes 1 = 0,1% de 1200');
  assert.ok(r.filas[11].poliza < r.filas[0].poliza, 'la póliza baja con el saldo');
});


// ---------------- Abonos extra en tasa cero ----------------
const refri = () => JSON.parse(JSON.stringify(D.tasaCero[0]));   // ₡480.000 en 12, 8 cuotas cobradas al 28/10
prueba('tasa cero sin abonos: igual que antes', () => {
  const e = Calc.estadoTasaCero(refri(), hoy);
  assert.strictEqual(e.cobradas, 8); cerca(e.saldo, 160000, 'saldo'); cerca(e.cuota, 40000, 'cuota'); assert.strictEqual(e.estado, 'Activa');
});
prueba('abono ₡60.000: misma cantidad de cuotas, cuota baja a ₡25.000', () => {
  const t = refri(); t.abonos = [{ fecha: '2026-10-20T18:00:00Z', monto: 60000, gasto: true }];
  const e = Calc.estadoTasaCero(t, hoy);
  cerca(e.saldo, 100000, 'saldo'); cerca(e.cuota, 25000, 'cuota nueva'); assert.strictEqual(e.restantes, 4);
  cerca(e.abonado, 60000, 'abonado'); cerca(e.cuotaOriginal, 40000, 'original');
  cerca(Calc.cuotaEnMes(t, new Date(2026, 10, 1)), 25000, 'cuota de noviembre');
  cerca(Calc.cuotaEnMes(t, new Date(2027, 1, 1)), 25000, 'última cuota (feb)');
  assert.strictEqual(Calc.cuotaEnMes(t, new Date(2027, 2, 1)), 0, 'no hay cuota en marzo');
});
prueba('abono por todo el saldo: pagada antes de tiempo y sin más cuotas', () => {
  const t = refri(); t.abonos = [{ fecha: '2026-10-20T18:00:00Z', monto: 160000 }];
  const e = Calc.estadoTasaCero(t, hoy);
  assert.strictEqual(e.estado, 'Pagada'); assert.strictEqual(e.saldo, 0); assert.strictEqual(e.restantes, 0);
  assert.strictEqual(Calc.cuotaEnMes(t, new Date(2026, 10, 1)), 0);
});
prueba('abono el mismo día de la cuota cuenta desde la siguiente; dos abonos se acumulan', () => {
  const t = refri(); t.abonos = [{ fecha: '2026-10-05T12:00:00Z', monto: 40000 }, { fecha: '2026-10-25T12:00:00Z', monto: 20000 }];
  const e = Calc.estadoTasaCero(t, hoy);
  cerca(Calc.cuotaEnMes(t, new Date(2026, 9, 1)), 40000, 'octubre sigue en 40.000');
  cerca(e.saldo, 100000, 'saldo'); cerca(e.cuota, 25000, 'cuota');
  assert.strictEqual(e.plan.abonos.length, 2); cerca(e.plan.abonos[0].cuotaNueva, 30000, 'tras el primero');
});
prueba('los abonos cuentan como pago del mes (si se marcó "contar como gasto")', () => {
  const d = JSON.parse(JSON.stringify(D));
  d.tasaCero[0].abonos = [{ fecha: '2026-10-20T18:00:00Z', monto: 60000, gasto: true }];
  d.tasaCero[1].abonos = [{ fecha: '2026-10-21T18:00:00Z', monto: 10000, gasto: false }];
  const r = Calc.resumenMes(d, mes);
  cerca(r.abonosTC.CRC, 60000, 'abonos'); cerca(r.cuotasTC.CRC, 130000, 'cuotas + abono');
  const s = Calc.sobres(d, mes, r).lista.find(x => x.nombre === 'Cuotas tasa cero');
  cerca(s.gastado, 130000, 'sobre tasa cero');
});


// ---------------- Sobres con saldo (v1.6) ----------------
const conSobres = () => {
  const d = JSON.parse(JSON.stringify(D));
  d.sobresDesde = '2026-10-01T06:00:00.000Z';
  d.sobres.forEach(s => { s.saldoInicial = 0; });
  d.sobres.find(s => s.nombre === 'Supermercado').saldoInicial = 10000;
  d.sobres.find(s => s.nombre === 'Imprevistos').ajuste = true;
  d.sobresMov = [];
  return d;
};
prueba('v2.8: compras con tarjeta NO tocan sobres (aunque tengan regla); el pago de la tarjeta desde la cuenta sí pregunta', () => {
  const d = conSobres(), r = Calc.saldosSobres(d, mes, hoy);
  cerca(r.lista.find(s => s.nombre === 'Supermercado').saldo, 10000, 'súper: las compras con tarjeta no lo bajan');
  const pago = r.pendientes.find(p => p.mov.fila === 14);
  cerca(pago.falta, 250000, 'el pago completo pregunta de qué sobre salió');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(r.reservado)), {}, 'ya no hay reservado');
});
prueba('v2.8: el pago de la tarjeta "del disponible" (fila sin sobre) queda cerrado y no baja ningún sobre', () => {
  const d = conSobres();
  d.sobresMov = [{ fecha: '2026-10-15T15:00:00Z', sobre: '', monto: -250000, tipo: 'Sin sobre', movimiento: 14, grupo: 'z' }];
  const r = Calc.saldosSobres(d, mes, hoy);
  assert.ok(!r.pendientes.some(p => p.mov.fila === 14));
  cerca(r.lista.find(s => s.nombre === 'Supermercado').saldo, 10000, 'súper igual');
});
prueba('sobres: reparto con sobre de ajuste (entró más de lo de siempre)', () => {
  const d = conSobres(), rp = Calc.reparto(d, 1250000, 'CRC');
  cerca(rp.siempre, 910000, 'reparto de siempre en ₡');
  assert.strictEqual(rp.ajuste, 'Imprevistos');
  cerca(rp.filas.find(f => f.nombre === 'Imprevistos').monto, 100000 + 340000, 'ajuste recibe la diferencia');
  const menos = Calc.reparto(d, 900000, 'CRC');
  cerca(menos.filas.find(f => f.nombre === 'Imprevistos').monto, 90000, 'si entra menos, se resta del ajuste');
});
prueba('sobres: repartir el salario, pagar la tarjeta desde dos sobres y mover entre sobres', () => {
  const d = conSobres();
  d.sobresMov = [
    { fecha: '2026-10-01T15:00:00Z', sobre: 'Supermercado', monto: 130000, tipo: 'Reparto', movimiento: 6, grupo: 'a' },
    { fecha: '2026-10-01T15:00:00Z', sobre: 'Imprevistos', monto: 1120000, tipo: 'Reparto', movimiento: 6, grupo: 'a' },
    { fecha: '2026-10-15T15:00:00Z', sobre: 'Imprevistos', monto: -200000, tipo: 'Pago tarjeta', movimiento: 14, grupo: 'b' },
    { fecha: '2026-10-15T15:00:00Z', sobre: 'Supermercado', monto: -50000, tipo: 'Pago tarjeta', movimiento: 14, grupo: 'b' },
    { fecha: '2026-10-20T15:00:00Z', sobre: 'Supermercado', monto: -20000, tipo: 'Mover', grupo: 'c' },
    { fecha: '2026-10-20T15:00:00Z', sobre: 'Restaurantes', monto: 20000, tipo: 'Mover', grupo: 'c' }
  ];
  const r = Calc.saldosSobres(d, mes, hoy), s = n => r.lista.find(x => x.nombre === n);
  cerca(s('Supermercado').saldo, 10000 + 130000 - 50000 - 20000, 'súper (las compras con tarjeta ya no cuentan)');
  cerca(s('Supermercado').inicioMes, 10000, 'venía de antes');
  cerca(s('Supermercado').entradas, 130000, 'entradas'); cerca(s('Supermercado').salidas, 70000, 'salidas');
  cerca(s('Restaurantes').saldo, 20000, 'restaurantes'); cerca(s('Imprevistos').saldo, 920000, 'imprevistos');
  assert.ok(r.pendientes.some(p => p.mov.fila === 20) && !r.pendientes.some(p => p.mov.fila === 19), 'queda el SINPE recibido; la compra con tarjeta ya no pide sobre');
  cerca(s('Cuota casa').saldo, 0, 'el pago del préstamo de setiembre es anterior al inicio');
});
prueba('sobres: el pago del préstamo sale solo de "Cuota casa"; la regla del correo asigna un SINPE enviado', () => {
  const d = conSobres();
  d.prestamo.pagos.push({ fecha: '2026-10-27T16:00:00Z', total: 266000 });
  d.movimientos.push({ fila: 99, fecha: '2026-10-27T13:00:00Z', comercio: 'SINPE a PERSONA DEMO', monto: 25000, moneda: 'CRC', tipo: 'Gasto', cuenta: 'Ahorros BCR colones', sobre: 'Salud' });
  const r = Calc.saldosSobres(d, mes, hoy);
  cerca(r.lista.find(s => s.nombre === 'Cuota casa').saldo, -266000, 'cuota casa');
  cerca(r.lista.find(s => s.nombre === 'Salud').saldo, -25000, 'salud: SINPE por regla (la compra con tarjeta ya no cuenta)');
  assert.ok(!r.pendientes.some(p => p.mov.fila === 99));
});
prueba('sobres: asignación parcial deja el resto por asignar', () => {
  const d = conSobres();
  d.sobresMov = [{ fecha: '2026-10-26T15:00:00Z', sobre: 'Salud', monto: 5000, tipo: 'Asignación', movimiento: 20, grupo: 'x' }];
  const p = Calc.saldosSobres(d, mes, hoy).pendientes.find(x => x.mov.fila === 20);
  cerca(p.falta, 10000, 'faltan 10.000');
});


// ---------------- Fondos y viaje (v1.7) ----------------
prueba('fondos: saldo anotado + aportes − retiros posteriores; sugerencia por monto', () => {
  const d = JSON.parse(JSON.stringify(D));
  d.fondos = [{ fila: 5, nombre: 'Marchamo 2026', moneda: 'CRC', saldo: 200000, fechaSaldo: '2026-09-30T18:00:00Z', meta: 250000 }];
  d.movimientos.push({ fila: 90, fecha: '2026-09-22T20:00:00Z', tipo: 'Inversión', monto: 12500, moneda: 'CRC', subcuenta: 'Marchamo 2026' });
  d.movimientos.push({ fila: 91, fecha: '2026-10-22T20:00:00Z', tipo: 'Inversión', monto: 12500, moneda: 'CRC', subcuenta: 'Marchamo 2026' });
  d.movimientos.push({ fila: 92, fecha: '2026-10-25T20:00:00Z', tipo: 'Retiro de fondo', monto: 5000, moneda: 'CRC', subcuenta: 'Marchamo 2026' });
  d.movimientos.push({ fila: 93, fecha: '2026-10-27T20:00:00Z', tipo: 'Inversión', monto: 12500, moneda: 'CRC', subcuenta: '' });
  const f = Calc.fondos(d, hoy);
  cerca(f.lista[0].saldo, 200000 + 12500 - 5000, 'el aporte de setiembre ya estaba en el saldo anotado');
  cerca(f.lista[0].aportesMes, 12500, 'aportes de octubre');
  assert.strictEqual(f.pendientes.length, 1);
  assert.strictEqual(Calc.sugerirSubcuenta(d, f.pendientes[0]), 'Marchamo 2026');
  assert.strictEqual(Calc.sentidoSobre(d, { tipo: 'Inversión' }), 'sale');
  assert.strictEqual(Calc.sentidoSobre(d, { tipo: 'Retiro de fondo' }), 'entra');
});
prueba('viaje: tarjetas elegidas, fechas, ₡ a $, categorías, excluir y agregar a mano', () => {
  const d = JSON.parse(JSON.stringify(D));
  const v = { nombre: 'Panamá', desde: '2026-10-20T06:00:00Z', hasta: '2026-10-28T06:00:00Z', limite: 500, moneda: 'USD', tarjetas: ['Mastercard Davibank', 'Efectivo'] };
  d.movimientos.push({ fila: 80, fecha: '2026-10-21T15:00:00Z', comercio: 'AVIANCA.COM', monto: 300, moneda: 'USD', tipo: 'Gasto', cuenta: 'Mastercard Davibank' });
  d.movimientos.push({ fila: 81, fecha: '2026-10-22T15:00:00Z', comercio: 'Restaurante', monto: 25250, moneda: 'CRC', tipo: 'Gasto', cuenta: '' });
  d.movimientos.push({ fila: 82, fecha: '2026-10-23T15:00:00Z', comercio: 'Algo', monto: 10, moneda: 'USD', tipo: 'Gasto', cuenta: 'Mastercard Davibank', viaje: 'Fuera' });
  d.movimientos.push({ fila: 83, fecha: '2026-10-24T15:00:00Z', comercio: 'Souvenir', monto: 20, moneda: 'USD', tipo: 'Gasto', cuenta: 'Visa BCR', viaje: '+Compras' });
  const r = Calc.viaje(d, v, new Date('2026-10-26T18:00:00Z'));
  const filas = r.compras.map(c => c.mov.fila);
  assert.ok(filas.includes(80) && filas.includes(81) && filas.includes(83) && !filas.includes(82), 'incluye/excluye bien');
  cerca(r.porCategoria.Vuelos, 300, 'Avianca (v2.10: categoría Vuelos)');
  cerca(r.porCategoria.Comida, 50, '₡25.250 al cambio de ₡505');
  cerca(r.porCategoria.Compras, 20, 'agregada a mano');
  assert.strictEqual(r.diasRestantes, 3); assert.strictEqual(r.diasTotal, 9);
  cerca(r.porDia, r.disponible / 3, 'por día');
});

console.log(`\n${ok} pruebas correctas`);
