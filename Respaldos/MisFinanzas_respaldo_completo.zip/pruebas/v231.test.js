// v2.3.1: no duplicar movimientos (id de la cola y número de documento).  TZ=America/Costa_Rica node pruebas/v231.test.js
const assert = require('assert');
const fs = require('fs'); const path = require('path'); const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) { const h = hojaSim(nombre); h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]); filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f])); return h; }
const hojas = {
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'], []),
  'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado', '', '', 'Categorías', 'Tipos de cuenta', 'Monedas', 'Tipo de movimiento', 'Origen'],
    [['BCR', 'x@bcr', 'Activo', '', '', 'Super', 'Tarjeta de crédito', 'CRC', 'Gasto', 'Correo'], ['', '', '', '', '', '', '', 'USD', 'Pago de tarjeta', 'Manual']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = { CLAVE_APP: 'k' }, cache = {};
const ctx = {
  console: { log() {} }, SpreadsheetApp: { getActive: () => libro }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  CacheService: { getScriptCache: () => ({ get: (k) => cache[k] || null, put: (k, v) => { cache[k] = v; }, remove: (k) => { delete cache[k]; } }) },
  ContentService: { createTextOutput: (t) => ({ t, setMimeType() { return this; } }), MimeType: { JSON: 'json' } }, Utilities: { getUuid: () => 'u' + Math.random() }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const filas = () => JSON.parse(JSON.stringify(ctx.leerTabla_('Movimientos', 'Fecha').filas));
const m = { fecha: '2026-10-31T18:17:00-06:00', monto: 12000, moneda: 'CRC', tipo: 'Pago de tarjeta', comercio: 'Pago de tarjeta ••9125', cuenta: 'Visa', origen: 'Foto', autorizacion: 'DOC-1', nota: 'x' };
prueba('mismo documento: no se agrega dos veces y el origen inválido pasa a Manual', () => {
  const f1 = ctx.guardarMovimiento_(Object.assign({}, m)), f2 = ctx.guardarMovimiento_(Object.assign({}, m));
  assert.strictEqual(f1, f2); assert.strictEqual(filas().length, 1); assert.strictEqual(filas()[0]['Origen'], 'Manual');
});
prueba('la misma orden de la cola (mismo id) solo se hace una vez', () => {
  const pedido = (id) => ({ postData: { contents: JSON.stringify({ clave: 'k', accion: 'guardarMovimiento', id, args: [Object.assign({}, m, { autorizacion: '' })] }) } });
  const r1 = JSON.parse(ctx.doPost(pedido('abc')).t), r2 = JSON.parse(ctx.doPost(pedido('abc')).t);
  assert.ok(r1.ok, r1.error); assert.deepStrictEqual(r1, r2); assert.strictEqual(filas().length, 2);
  ctx.doPost(pedido('otro')); assert.strictEqual(filas().length, 3);
});
console.log(ok + ' pruebas correctas');
