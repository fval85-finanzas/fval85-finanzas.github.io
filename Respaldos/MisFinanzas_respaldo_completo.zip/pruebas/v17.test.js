// v1.7 en el servidor: fondos, viajes, avisos y columnas de Sobres.  TZ=America/Costa_Rica node pruebas/v17.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) {
  const h = hojaSim(nombre);
  h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]);
  filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f]));
  return h;
}
const hojas = {
  'Sobres': tabla('Sobres', 4, ['Sobre', 'Moneda', 'Asignado por mes', 'Tipo', 'Gastado en el mes', 'Disponible', '% usado', 'Estado', 'Notas', 'Saldo inicial'],
    [['Supermercado', 'CRC', 130000, 'Variable', '', '', '', '', '', 50000], ['Pago tarjetas', 'CRC', 0, 'Ahorro', '', '', '', '', '', 0]]),
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'],
    [[new Date('2026-10-30T15:00:00Z'), 'AVIANCA.COM', 'Panamá', 1700, 'USD', 'Gasto', 'MC Davibank', '', '', 'Correo', '889833', '']]),
  'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado', '', '', 'Categorías', 'Tipos de cuenta', 'Monedas', 'Tipo de movimiento', 'Origen'],
    [['BCR', 'x@bcr', 'Activo', '', '', 'Supermercado', 'Tarjeta de crédito', 'CRC', 'Gasto', 'Correo'], ['', '', '', '', '', '', '', 'USD', 'Ingreso', 'Manual']]),
  'Resumen': tabla('Resumen', 30, ['Sobre', '', 'Asignado', 'Gastado', '', 'Disponible', 'Estado'], [])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = { V16_LISTO: 'si', V161_LISTO: 'si', SOBRES_DESDE: '2026-10-01T06:00:00.000Z' };
const correos = [];
const ctx = {
  console: { log() {} }, SpreadsheetApp: { getActive: () => libro }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  MailApp: { sendEmail: (a, s, b) => correos.push({ a, s, b }) }, Session: { getEffectiveUser: () => ({ getEmail: () => 'yo@correo.com' }) }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const J = (x) => JSON.parse(JSON.stringify(x));
const filas = (n, c) => J(ctx.leerTabla_(n, c).filas);

prueba('preparación 1.7: columnas, sobre Fondos, tipos en Config, pestañas y títulos (una vez)', () => {
  ctx.prepararV17_(); ctx.prepararV17_();
  const mc = J(ctx.columnas_(hojas['Movimientos'], 4)); assert.ok(mc['Subcuenta'] && mc['Viaje']);
  assert.ok(filas('Sobres', 'Sobre').some(r => r['Sobre'] === 'Fondos'));
  const tipos = J(ctx.listaConfig_('Tipo de movimiento')); assert.ok(tipos.includes('Inversión') && tipos.includes('Retiro de fondo'));
  assert.ok(hojas['Fondos'] && hojas['Viajes']);
  const sc = J(ctx.columnas_(hojas['Sobres'], 4)); assert.ok(sc['Salió este mes'] && sc['Saldo actual']);
  assert.strictEqual(hojas['Resumen'].getRange(30, 4).getValues()[0][0], 'Salió este mes');
});
prueba('fondos: crear subcuenta, actualizar saldo con intereses, marcar subcuenta de un movimiento', () => {
  const f = ctx.guardarFondo_({ nombre: 'Marchamo 2026', fondo: 'BCR Mixto Colones', moneda: 'CRC', saldo: 214164.05, meta: 250000 });
  assert.throws(() => ctx.guardarFondo_({ nombre: 'Marchamo 2026' }), /Ya existe/);
  ctx.actualizarSaldoFondo_(f, 230000, 1500);
  const r = filas('Fondos', 'Subcuenta')[0];
  assert.strictEqual(r['Saldo'], 230000); assert.strictEqual(r['Intereses (último ajuste)'], 1500); assert.strictEqual(r['Meta'], 250000);
  ctx.marcarMovimiento_(5, 'Subcuenta', 'Marchamo 2026', { monto: 1700 });
  assert.strictEqual(filas('Movimientos', 'Fecha')[0]['Subcuenta'], 'Marchamo 2026');
  assert.throws(() => ctx.marcarMovimiento_(5, 'Monto', 1, null), /no permitida/);
});
prueba('viaje: guardar, aviso por correo al 80 % (una sola vez) y al 100 %', () => {
  const f = ctx.guardarViaje_({ nombre: 'Panamá', desde: '2026-10-29T06:00:00Z', hasta: new Date(Date.now() + 5 * 86400000).toISOString(), limite: 2000, moneda: 'USD', tarjetas: ['MC Davibank'] });
  assert.throws(() => ctx.guardarViaje_({ nombre: 'X', desde: '2026-10-29', hasta: '2026-10-20', limite: 5, tarjetas: [] }), /antes de la inicial/);
  const D = () => JSON.parse(ctx.obtenerDatos_ ? JSON.stringify({ viajes: J(ctx.leerViajes_()), movimientos: filas('Movimientos', 'Fecha').map(r => ({ fila: r._fila, fecha: r['Fecha'], comercio: r['Comercio / descripción'], monto: r['Monto'], moneda: r['Moneda'], tipo: r['Tipo'], cuenta: r['Cuenta / tarjeta'], viaje: r['Viaje'] || '' })), tipoCambio: 505 }) : '{}');
  ctx.revisarViajes_(D());
  assert.strictEqual(correos.length, 1); assert.match(correos[0].s, /85%/);
  ctx.revisarViajes_(D());
  assert.strictEqual(correos.length, 1, 'no se repite el aviso del 80 %');
  hojas['Movimientos'].getRange(6, 1, 1, 7).setValues([[new Date('2026-10-31T15:00:00Z'), 'HOTEL', '', 400, 'USD', 'Gasto', 'MC Davibank']]);
  ctx.revisarViajes_(D());
  assert.strictEqual(correos.length, 2); assert.match(correos[1].b, /límite/);
  assert.strictEqual(f, 5);
});
prueba('Sobres: "Salió este mes" y "Saldo actual" iguales a la app', () => {
  ctx.actualizarHojaSobres_({ sobresDesde: props.SOBRES_DESDE, sobres: [{ fila: 5, nombre: 'Supermercado', moneda: 'CRC', asignado: 130000, tipo: 'Variable', saldoInicial: 50000 }],
    sobresMov: [{ fecha: new Date().toISOString(), sobre: 'Supermercado', monto: -20000, tipo: 'Pago tarjeta', grupo: 'a' }], movimientos: [], cuentas: [], sobreEspecial: {} });
  const r = filas('Sobres', 'Sobre').find(x => x['Sobre'] === 'Supermercado');
  assert.strictEqual(r['Saldo actual'], 30000); assert.strictEqual(r['Salió este mes'], 20000); assert.strictEqual(r['Estado'], 'OK');
});
console.log(`\n${ok} pruebas correctas`);
