// Sobres con saldo (v1.6) en el servidor, con hoja simulada.  TZ=America/Costa_Rica node pruebas/sobres.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) {
  const h = hojaSim(nombre);
  h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]);
  filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f]));
  return h;
}
const hojas = {
  'Sobres': tabla('Sobres', 4, ['Sobre', 'Moneda', 'Asignado por mes', 'Tipo', 'Gastado en el mes'], [['Supermercado', 'CRC', 130000, 'Variable'], ['Imprevistos', 'CRC', 100000, 'Variable']]),
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto'], [[new Date('2026-10-30T13:00:00Z'), 'SERVICENTRO POAS', '', 30000], [new Date('2026-10-30T12:00:00Z'), 'Salario', '', 1250000]]),
  'Reglas': tabla('Reglas', 4, ['Si el comercio contiene', 'Categoría', 'Sobre'], [['SINPE A PERSONA DEMO', 'Ejercicio', '']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = {};
const ctx = {
  console, SpreadsheetApp: { getActive: () => libro }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 3).join('\n   ')); process.exitCode = 1; } }
const sob = () => JSON.parse(JSON.stringify(ctx.leerTabla_('Sobres', 'Sobre').filas));

prueba('preparación: columnas nuevas, fecha de inicio y sobre "Pago tarjetas" (una sola vez)', () => {
  ctx.prepararSobresV16_(); ctx.prepararSobresV16_();
  const cols = JSON.parse(JSON.stringify(ctx.columnas_(hojas['Sobres'], 4)));
  ['Saldo inicial', 'Ajuste del reparto', 'Meta'].forEach(c => assert.ok(cols[c], c));
  assert.ok(props.SOBRES_DESDE);
  assert.strictEqual(sob().filter(r => r['Sobre'] === 'Pago tarjetas').length, 1);
});
prueba('movimientos de sobres: guardar un reparto y deshacerlo por grupo', () => {
  ctx.guardarSobresMov_([
    { fecha: '2026-10-30T15:00:00Z', sobre: 'Supermercado', monto: 130000, tipo: 'Reparto', movimiento: 6, grupo: 'g1' },
    { fecha: '2026-10-30T15:00:00Z', sobre: 'Imprevistos', monto: 120000, tipo: 'Reparto', movimiento: 6, grupo: 'g1' },
    { fecha: '2026-10-30T15:00:00Z', sobre: 'Imprevistos', monto: -5000, tipo: 'Mover', grupo: 'g2' }
  ]);
  let l = JSON.parse(JSON.stringify(ctx.leerSobresMov_()));
  assert.strictEqual(l.length, 3); assert.strictEqual(l[0].movimiento, 6); assert.strictEqual(l[2].monto, -5000);
  assert.strictEqual(ctx.eliminarGrupoSobres_('g1'), 2);
  l = JSON.parse(JSON.stringify(ctx.leerSobresMov_()));
  assert.strictEqual(l.length, 1); assert.strictEqual(l[0].grupo, 'g2');
});
prueba('reparto de siempre: montos y sobre de ajuste', () => {
  ctx.guardarReparto_([{ nombre: 'Supermercado', monto: 140000 }, { nombre: 'Imprevistos', monto: 90000 }], 'Imprevistos');
  const s = sob();
  assert.strictEqual(s.find(r => r['Sobre'] === 'Supermercado')['Asignado por mes'], 140000);
  assert.strictEqual(s.find(r => r['Sobre'] === 'Imprevistos')['Ajuste del reparto'], 'Sí');
  assert.strictEqual(s.find(r => r['Sobre'] === 'Supermercado')['Ajuste del reparto'], '');
});
prueba('recordar: regla de sobre sin borrar la categoría existente', () => {
  ctx.guardarReglaSobre_('SINPE a PERSONA DEMO', 'Imprevistos');
  ctx.guardarReglaSobre_('SINPE de CARLOS', 'Supermercado');
  const r = JSON.parse(JSON.stringify(ctx.leerTabla_('Reglas', 'Si el comercio contiene').filas));
  assert.strictEqual(r[0]['Categoría'], 'Ejercicio'); assert.strictEqual(r[0]['Sobre'], 'Imprevistos');
  assert.strictEqual(r[1]['Si el comercio contiene'], 'SINPE DE CARLOS');
});
prueba('guardar sobre con saldo inicial y meta', () => {
  const f = sob().find(r => r['Sobre'] === 'Supermercado')._fila;
  ctx.guardarSobre_({ fila: f, asignado: 140000, saldoInicial: 25000, meta: 0, tipo: 'Variable' });
  assert.strictEqual(sob().find(r => r['Sobre'] === 'Supermercado')['Saldo inicial'], 25000);
});
prueba('1.6.1: prepara una vez, crea "Movimientos de sobres" y no borra datos', () => {
  const antes = sob().find(r => r['Sobre'] === 'Supermercado')['Saldo inicial'];
  ctx.prepararV161_(); ctx.prepararV161_();
  assert.ok(hojas['Movimientos de sobres'], 'pestaña creada');
  assert.strictEqual(sob().find(r => r['Sobre'] === 'Supermercado')['Saldo inicial'], antes, 'el saldo inicial sigue igual');
  assert.strictEqual(ctx.leerSobresMov_().length, 1, 'los movimientos de sobres siguen ahí');
});
prueba('préstamo: un "pago" sin capital ni intereses se ignora', () => {
  assert.strictEqual(ctx.registrarPagoPrestamo_({ fecha: '2011-06-07', principal: 0, intereses: 0, polizas: 62766.33 }), 'ignorado');
});
prueba('1.8.1: no deja asignar dos veces el mismo movimiento', () => {
  ctx.guardarSobresMov_([{ fecha: '2026-10-30T13:00:00Z', sobre: 'Supermercado', monto: -30000, tipo: 'Compra con tarjeta', movimiento: 5, grupo: 'x1' }]);
  assert.throws(() => ctx.guardarSobresMov_([{ fecha: '2026-10-30T13:00:00Z', sobre: 'Supermercado', monto: -30000, tipo: 'Compra con tarjeta', movimiento: 5, grupo: 'x2' }]), /ya estaba asignado/);
  assert.throws(() => ctx.guardarSobresMov_([{ fecha: '2026-10-30T12:00:00Z', sobre: 'Supermercado', monto: 2000000, tipo: 'Reparto', movimiento: 6, grupo: 'x3' }]), /Solo faltan/);
});
prueba('1.9: al borrar un movimiento, las asignaciones de los de abajo se corren y las suyas se borran', () => {
  hojas['Movimientos'].getRange(7, 1, 1, 4).setValues([[new Date('2026-10-30T14:00:00Z'), 'OTRO', '', 5000]]);
  ctx.guardarSobresMov_([{ fecha: '2026-10-30T14:00:00Z', sobre: 'Supermercado', monto: -5000, tipo: 'Gasto', movimiento: 7, grupo: 'z7' }]);
  ctx.eliminarMovimiento_(5, { monto: 30000 });
  const l = JSON.parse(JSON.stringify(ctx.leerSobresMov_()));
  assert.ok(!l.some(x => x.grupo === 'x1'), 'la asignación del movimiento borrado se fue');
  assert.strictEqual(l.find(x => x.grupo === 'z7').movimiento, 6, 'la del movimiento de abajo ahora apunta a la fila 6');
});
console.log(`\n${ok} pruebas correctas`);
