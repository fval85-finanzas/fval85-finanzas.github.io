// v2.17.0: presupuesto por corte (#66) y compras a mano que se unen con el correo (#67).  TZ=America/Costa_Rica node pruebas/v2170.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) { const h = hojaSim(nombre); h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]); filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f])); return h; }
const F = (d, h) => new Date(d + 'T' + (h || '12:00') + ':00-06:00');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 10).join('\n   ')); process.exitCode = 1; } }
const hoy = F('2026-11-19', '07:00');
const g = (fecha, monto, cuenta, cat) => ({ fecha: F(fecha).toISOString(), monto, moneda: 'CRC', tipo: 'Gasto', cuenta, categoria: cat || 'Supermercado', comercio: 'SUPER DEMO' });
const d = {
  tipoCambio: 500,
  familia: { '4321': { persona: 'Persona B', nombre: 'Visa', presu: '' } },
  presupuesto: { limites: { Supermercado: 100000, Restaurantes: 50000 } },
  cortes: [{ cuenta: 'Familia ••4321', nombre: 'Súper de la casa', monto: 300000, dia: 24, enMes: false, aviso: true }],
  movimientos: [
    g('2026-10-24', 99999, 'Familia ••4321'),           // corte anterior (último día)
    g('2026-10-25', 50000, 'Familia ••4321'),           // primer día del corte
    g('2026-11-10', 120000, 'Familia ••4321'),
    g('2026-11-18', 78350, 'Familia ••4321'),
    g('2026-11-25', 1000, 'Familia ••4321'),            // corte que viene
    g('2026-11-05', 30000, 'Tarjeta A'),                // mía, en mi presupuesto
    g('2026-11-06', 20000, 'Tarjeta A', 'Restaurantes'),
    g('2026-09-20', 250000, 'Familia ••4321'), g('2026-08-20', 320000, 'Familia ••4321')
  ]
};
prueba('período del corte: corta el 24 → del 25 al 24; después del 24 ya es el siguiente', () => {
  let p = C.periodoCorte(24, hoy, 0);
  assert.strictEqual(p.ini.toDateString(), F('2026-10-25').toDateString()); assert.strictEqual(p.fin.toDateString(), F('2026-11-24').toDateString());
  assert.strictEqual(p.dias, 31); assert.strictEqual(p.dia, 26); assert.strictEqual(p.faltan, 5);
  p = C.periodoCorte(24, F('2026-11-25'), 0); assert.strictEqual(p.ini.toDateString(), F('2026-11-25').toDateString()); assert.strictEqual(p.dia, 1);
  p = C.periodoCorte(24, F('2026-11-24', '23:00'), 0); assert.strictEqual(p.faltan, 0, 'el día del corte es el último');
  p = C.periodoCorte(31, F('2026-02-15'), 0); assert.strictEqual(p.fin.toDateString(), F('2026-02-28').toDateString(), 'día 31 en febrero → 28');
  p = C.periodoCorte(24, hoy, 1); assert.strictEqual(p.ini.toDateString(), F('2026-09-25').toDateString()); assert.strictEqual(p.faltan, 0);
});
prueba('presupuesto del corte: gastado, queda, por día, ritmo', () => {
  const r = C.presupuestoCorte(d, d.cortes[0], hoy);
  assert.strictEqual(r.gastado, 248350); assert.strictEqual(r.quedan, 51650); assert.strictEqual(r.n, 3);
  assert.strictEqual(r.porDia, 10330); assert.strictEqual(r.serie.length, 26); assert.strictEqual(r.serie[25], 248350);
  assert.strictEqual(r.estado, 'alerta', '83% → aviso');
  assert.ok(r.ritmo > 0, 'va por debajo del ideal (300000·26/31 = 251.613)');
});
prueba('historial de cortes', () => {
  const h = C.historialCorte(d, d.cortes[0], hoy, 3);
  assert.deepStrictEqual(h.map(x => x.gastado), [99999, 250000, 320000]);
});
prueba('va aparte del presupuesto del mes (salvo "contar en mi presupuesto")', () => {
  let p = C.presupuesto(d, hoy, {});
  const sup = p.cats.find(c => c.cat === 'Supermercado'); assert.strictEqual(sup.gastado, 30000, 'solo mi compra');
  const d2 = Object.assign({}, d, { cortes: [Object.assign({}, d.cortes[0], { enMes: true })] });
  p = C.presupuesto(d2, hoy, {}); assert.strictEqual(p.cats.find(c => c.cat === 'Supermercado').gastado, 30000 + 120000 + 78350 + 1000, 'con enMes cuenta en el mes de noviembre (del 1 al 30)');
  const d3 = Object.assign({}, d, { cortes: [Object.assign({}, d.cortes[0], { on: false })] });
  p = C.presupuesto(d3, hoy, {}); assert.strictEqual(p.cats.find(c => c.cat === 'Supermercado').gastado, 30000, 'pausado: vuelve a como antes (familia sin presupuesto)');
});
prueba('una tarjeta propia también sirve', () => {
  const cfg = { cuenta: 'Tarjeta A', nombre: 'X', monto: 100000, dia: 24 };
  assert.strictEqual(C.presupuestoCorte(d, cfg, hoy).gastado, 50000);
  assert.ok(!C.esDeCorte(cfg, { cuenta: 'Familia ••4321' }));
});

// ---- #67 servidor: unir con la compra anotada a mano
const hojas = {
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'], [
    [F('2026-11-18', '19:00'), 'Súper', '', 42380, 'CRC', 'Gasto', 'Familia ••4321', 'Supermercado', '', 'Manual', '', 'Tarjeta de la familia · anotada a mano'],
    [F('2026-11-18', '20:00'), 'Otra', '', 42380, 'CRC', 'Gasto', 'Tarjeta A', '', '', 'Manual', '', ''],
    [F('2026-11-10'), 'Vieja', '', 5000, 'CRC', 'Gasto', 'Familia ••4321', '', '', 'Manual', '', '']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const ctx = { console: { log() {} }, SpreadsheetApp: { getActive: () => libro, flush() {} },
  PropertiesService: { getScriptProperties: () => ({ getProperty: () => null, setProperty() {} }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) } };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
const filaCorreo = (o) => Object.assign({ 'Fecha': F('2026-11-18', '18:42'), 'Comercio / descripción': 'AUTOMERCADO DEMO', 'Lugar': 'SAN JOSE', 'Monto': 42380, 'Moneda': 'CRC', 'Tipo': 'Gasto', 'Cuenta / tarjeta': 'Familia ••4321', 'Categoría': 'Supermercado', 'Sobre': '', 'Origen': 'Correo', 'Autorización': 'AUT1', 'Nota': '' }, o || {});
prueba('busca la manual igual: misma tarjeta y monto, ±1 día; no la de otra tarjeta ni la vieja', () => {
  const mov = ctx.leerTabla_('Movimientos', 'Fecha'), unidas = {};
  const r = ctx.buscarManualIgual_(mov, filaCorreo(), unidas); assert.strictEqual(r._fila, 5);
  assert.strictEqual(ctx.buscarManualIgual_(mov, filaCorreo({ 'Monto': 42000 }), unidas), null, 'otro monto');
  assert.strictEqual(ctx.buscarManualIgual_(mov, filaCorreo({ 'Fecha': F('2026-11-21') }), unidas), null, 'tres días después');
  unidas[5] = true; assert.strictEqual(ctx.buscarManualIgual_(mov, filaCorreo(), unidas), null, 'ya unida en esta vuelta');
  assert.strictEqual(ctx.buscarManualIgual_(mov, filaCorreo({ 'Fecha': F('2026-11-11'), 'Monto': 5000 }), {})._fila, 7, 'un día después sirve');
});
console.log(`\n${ok} pruebas correctas`);

// ---- #67 de punta a punta: procesarCorreos une el correo con la anotada a mano
(function () {
  const crypto = require('crypto');
  const T = (n) => fs.readFileSync(path.join(__dirname, 'correos.test.js'), 'utf8').match(new RegExp('const ' + n + ' = `([\\s\\S]*?)`;'))[1];
  const texto = T('bcrTexto'), cuando = new Date(Date.now() - 3600e3);
  const enc = ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'];
  const H = {
    'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado'], [['BCR', 'bcrtarjestcta@bancobcr.com', 'Activo']]),
    'Cuentas': tabla('Cuentas', 4, ['Nombre (único)', 'Tipo', 'Banco', 'Últimos 4', 'Moneda principal', 'Activa'], [['Visa BCR', 'Tarjeta de crédito', 'BCR', '9125', 'CRC', 'Sí']]),
    'Movimientos': tabla('Movimientos', 4, enc, []), 'Reglas': tabla('Reglas', 4, ['Si el comercio contiene', 'Categoría', 'Sobre'], []),
    'Sobres': tabla('Sobres', 4, ['Sobre', 'Moneda', 'Asignado por mes', 'Tipo'], [])
  };
  const lib = { getSheetByName: (n) => H[n] || null, insertSheet: (n) => (H[n] = hojaSim(n)), getName: () => 'Finanzas' };
  const hilo = { etiquetas: new Set(), msgs: [{ de: 'bcrtarjestcta@bancobcr.com', getId: () => 'm1', getDate: () => cuando, getSubject: () => 'Notificación de Transacciones BCR', getPlainBody: () => texto, getBody: () => '', getAttachments: () => [], getHeader: () => '' }] };
  hilo.getMessages = () => hilo.msgs; hilo.getId = () => 'h1'; hilo.markRead = () => {}; hilo.moveToArchive = () => {};
  const et = {};
  const G = { search: (q) => /from:bcrtarjestcta/i.test(q) && !/label:/.test(q) ? [hilo] : [], getUserLabelByName: (n) => et[n] || null,
    createLabel: (n) => (et[n] = { addToThread: (h) => h.etiquetas.add(n), removeFromThread: (h) => h.etiquetas.delete(n), removeFromThreads() {} }),
    moveThreadsToInbox() {}, markThreadsRead() {}, moveThreadsToArchive() {} };
  const pr = { ULTIMA_REVISION: String(Date.now() - 2 * 3600e3) };
  const cx = { console: { log() {} }, GmailApp: G, SpreadsheetApp: { getActive: () => lib, flush() {} },
    PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => pr[k] || null, setProperty: (k, v) => { pr[k] = v; } }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) },
    Utilities: { DigestAlgorithm: { MD5: 'md5' }, computeDigest: (a, s) => [...crypto.createHash('md5').update(s).digest()], base64EncodeWebSafe: (b) => Buffer.from(b).toString('base64url') } };
  vm.createContext(cx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), cx);
  const tx = cx.parsearCorreoBanco(texto, '', cuando, 'BCR')[0];
  H.Movimientos.getRange(5, 1, 1, enc.length).setValues([[new Date(tx.fecha), 'Súper', '', tx.monto, tx.moneda, 'Gasto', 'Visa BCR', 'Supermercado', '', 'Manual', '', '']]);
  prueba('procesarCorreos: la compra que ya anotaste a mano se une (no se duplica) y guarda la autorización', () => {
    const msg = cx.procesarCorreos();
    const f = JSON.parse(JSON.stringify(cx.leerTabla_('Movimientos', 'Fecha').filas));
    assert.strictEqual(f.length, 1, msg);
    assert.strictEqual(f[0]['Origen'], 'Correo'); assert.strictEqual(String(f[0]['Autorización']), String(tx.autorizacion));
    assert.strictEqual(f[0]['Comercio / descripción'], 'Súper', 'se queda tu nombre'); assert.strictEqual(f[0]['Categoría'], 'Supermercado');
    assert.match(f[0]['Nota'], /Unida con el correo/); assert.match(msg, /Unidas con las anotadas a mano: 1/);
    cx.procesarCorreos(); assert.strictEqual(cx.leerTabla_('Movimientos', 'Fecha').filas.length, 1, 'la segunda vez es repetida');
  });
  console.log(`\n${ok} pruebas correctas`);
})();
