// v2.12.0: presupuesto (#53).  TZ=America/Costa_Rica node pruebas/v2120.test.js
const assert = require('assert');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 6).join('\n   ')); process.exitCode = 1; } }
const F = (dia, h) => `2026-11-${String(dia).padStart(2, '0')}T${h || '12'}:00:00-06:00`;
const d = {
  tipoCambio: 500, tasaCero: [], sobres: [], categorias: ['Supermercado', 'Restaurantes', 'Salud'],
  presupuesto: { modo: 'mes', limites: { Supermercado: 180000, Restaurantes: 60000 }, inv: { 'Fondo A': 100000, 'Fondo USD': 150 } },
  familia: { '7777': { persona: 'Ana', nombre: 'Visa', presu: 'Supermercado' }, '8888': { persona: 'Ana', nombre: 'MC', presu: '*' }, '9999': { persona: 'Ana', nombre: 'Otra' } },
  cuentas: [{ fila: 2, nombre: 'Tarjeta A', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, ultimos4: '1111' }, { fila: 3, nombre: 'Ahorros', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true }],
  fondos: [{ fila: 5, nombre: 'Fondo A', moneda: 'CRC' }, { fila: 6, nombre: 'Fondo USD', moneda: 'USD' }],
  viajes: [{ fila: 5, id: 'v1', nombre: 'Viaje', desde: F(20), hasta: F(25), limite: 1000, moneda: 'USD', tarjetas: ['Tarjeta A'] }],
  movimientos: [
    { fila: 10, fecha: F(3), tipo: 'Gasto', monto: 6775, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'SUPER', categoria: 'Supermercado' },
    { fila: 11, fecha: F(5), tipo: 'Gasto', monto: 98300, moneda: 'CRC', cuenta: 'Familia ••7777', comercio: 'AUTOMERCADO', categoria: 'Compras' },   // todo al súper
    { fila: 12, fecha: F(6), tipo: 'Gasto', monto: 20, moneda: 'USD', cuenta: 'Familia ••8888', comercio: 'FARMACIA', categoria: 'Salud' },          // según categoría → Salud (sin límite)
    { fila: 13, fecha: F(7), tipo: 'Gasto', monto: 50000, moneda: 'CRC', cuenta: 'Familia ••9999', comercio: 'X', categoria: 'Supermercado' },       // no cuenta
    { fila: 14, fecha: F(8), tipo: 'Gasto', monto: 55900, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'REST', categoria: 'Restaurantes' },
    { fila: 15, fecha: F(9), tipo: 'Gasto', monto: 9000, moneda: 'CRC', cuenta: 'Ahorros', comercio: 'PARA OTRO', categoria: 'Supermercado', para: 'Luis' },
    { fila: 16, fecha: F(21), tipo: 'Gasto', monto: 40000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'EN VIAJE', categoria: 'Restaurantes' },    // dentro del viaje
    { fila: 17, fecha: F(4), tipo: 'Pago de tarjeta', monto: 30000, moneda: 'CRC', cuenta: 'Tarjeta A' },
    { fila: 18, fecha: F(4), tipo: 'Gasto', monto: 4725, moneda: 'CRC', cuenta: 'Efectivo', comercio: 'FERIA', categoria: 'Supermercado' },
    { fila: 19, fecha: F(6), tipo: 'Inversión', monto: 100000, moneda: 'CRC', cuenta: 'Ahorros', subcuenta: 'Fondo A' },
    { fila: 20, fecha: F(6), tipo: 'Inversión', monto: 80, moneda: 'USD', cuenta: 'Ahorros', subcuenta: 'Fondo USD' },
    { fila: 21, fecha: F(10), tipo: 'Retiro de fondo', monto: 30, moneda: 'USD', cuenta: 'Ahorros', subcuenta: 'Fondo USD' },
    { fila: 22, fecha: '2026-10-10T12:00:00-06:00', tipo: 'Gasto', monto: 150000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'SUPER', categoria: 'Supermercado' },
    { fila: 23, fecha: '2026-10-06T12:00:00-06:00', tipo: 'Ingreso', monto: 900000, moneda: 'CRC', cuenta: 'Ahorros', comercio: 'Salario', categoria: 'Salario' }
  ]
};
const hoy = new Date(2026, 10, 14, 12);
prueba('por mes: categorías, familia ligada, exclusiones (viaje, para otro, pagos, familia sin ligar)', () => {
  const p = C.presupuesto(d, hoy);
  assert.strictEqual(p.periodo.modo, 'mes'); assert.strictEqual(p.periodo.dias, 30); assert.strictEqual(p.periodo.dia, 14); assert.strictEqual(p.periodo.faltan, 16);
  const s = p.cats.find(c => c.cat === 'Supermercado'), r = p.cats.find(c => c.cat === 'Restaurantes');
  assert.strictEqual(s.gastado, 6775 + 98300 + 4725); assert.strictEqual(s.limite, 180000); assert.strictEqual(s.estado, 'rapido');
  assert.strictEqual(s.porPersona.Ana.monto, 98300); assert.strictEqual(s.porPersona[''].monto, 11500); assert.strictEqual(s.porPersona[''].tarjetas.Efectivo, 4725);
  assert.strictEqual(r.gastado, 55900, 'lo del viaje no cuenta'); assert.strictEqual(r.estado, 'rapido');
  assert.strictEqual(p.sin.cats[0].cat, 'Salud'); assert.strictEqual(p.sin.monto, 10000, 'USD 20 × 500, tarjeta de familia "según categoría"');
  assert.strictEqual(p.total.limite, 240000); assert.strictEqual(p.total.gastado, 165700);
  assert.strictEqual(Math.round(p.total.porDia), Math.round((240000 - 165700) / 16));
});
prueba('estados: bien / rápido / pasado', () => {
  const d2 = Object.assign({}, d, { presupuesto: { limites: { Supermercado: 100000, Restaurantes: 200000 } } });
  const p = C.presupuesto(d2, hoy);
  assert.strictEqual(p.cats.find(c => c.cat === 'Supermercado').estado, 'pasado'); assert.strictEqual(p.cats.find(c => c.cat === 'Restaurantes').estado, 'bien');
  assert.strictEqual(p.cats[0].cat, 'Supermercado', 'la más llena primero');
});
prueba('inversión: aportes − retiros por fondo, meta cumplida', () => {
  const p = C.presupuesto(d, hoy);
  const a = p.inversion.find(f => f.nombre === 'Fondo A'), u = p.inversion.find(f => f.nombre === 'Fondo USD');
  assert.ok(a.cumplida); assert.strictEqual(a.aportado, 100000);
  assert.strictEqual(u.aportado, 50); assert.strictEqual(u.faltan, 100); assert.ok(!u.cumplida);
  assert.strictEqual(p.invTotal.meta, 100000 + 150 * 500); assert.strictEqual(p.invTotal.aportado, 100000 + 50 * 500);
});
prueba('por salario: período entre pagos y límites proporcionales', () => {
  const cfg = { frecuencia: 'bisemanal', fecha: '2026-11-06' };
  const p = C.presupuesto(d, hoy, { modo: 'salario', salario: cfg });
  assert.strictEqual(p.periodo.modo, 'salario'); assert.strictEqual(p.periodo.ini.getDate(), 6); assert.strictEqual(p.periodo.fin.getDate(), 19); assert.strictEqual(p.periodo.dias, 14);
  const s = p.cats.find(c => c.cat === 'Supermercado');
  assert.strictEqual(Math.round(s.limite), Math.round(180000 * 14 / 30.4375));
  assert.strictEqual(s.gastado, 0, 'las compras del súper fueron antes del 6');
  assert.strictEqual(C.presupuesto(d, hoy, { modo: 'salario' }).periodo.modo, 'mes', 'sin fechas de salario → por mes');
  const ant = C.presupuesto(d, hoy, { modo: 'salario', salario: cfg, atras: 1 });
  assert.strictEqual(ant.periodo.ini.getDate(), 23); assert.strictEqual(ant.periodo.ini.getMonth(), 9);
});
prueba('período anterior, promedios y lo libre', () => {
  const ant = C.presupuesto(d, hoy, { atras: 1 });
  assert.strictEqual(ant.periodo.ini.getMonth(), 9); assert.strictEqual(ant.cats.find(c => c.cat === 'Supermercado').gastado, 150000); assert.strictEqual(ant.periodo.pct, 1);
  const pr = C.promediosPresupuesto(d, hoy, 3);
  assert.strictEqual(pr.cats.Supermercado, 50000); assert.strictEqual(pr.salario, 300000);
  const lb = C.librePresupuesto(d, hoy);
  assert.strictEqual(lb.inversion, 175000); assert.strictEqual(lb.libre, 300000 - 175000); assert.strictEqual(lb.limites, 240000); assert.ok(!lb.caben);
});
prueba('servidor: avisos del presupuesto al 80% y al pasarse', () => {
  const fs = require('fs'), path = require('path'), vm = require('vm');
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
  const dd = Object.assign({}, d, { prestamo: null, sobreEspecial: {} }); delete dd.presupuesto; delete dd.familia;
  ctx.obtenerDatos_ = () => JSON.stringify(dd); ctx.listasDatos_ = () => [];
  ctx.prefs_ = () => ({ presupuesto: { limites: { Supermercado: 120000, Restaurantes: 50000 } }, familia: d.familia });
  const RealDate = Date; ctx.Date = class extends RealDate { constructor(...a) { if (!a.length) return new RealDate(2026, 10, 14, 8); return new RealDate(...a); } static now() { return new RealDate(2026, 10, 14, 8).getTime(); } };
  vm.runInContext('Date = this.Date', ctx);
  const r = ctx.resumenAvisos_();
  assert.ok(!r.errPresupuesto, r.errPresupuesto);
  const s = r.presupuesto.find(x => x.cat === 'Supermercado'), re = r.presupuesto.find(x => x.cat === 'Restaurantes');
  assert.strictEqual(s.nivel, 80); assert.strictEqual(s.pct, 92); assert.strictEqual(re.nivel, 100); assert.strictEqual(re.quedan, -5900); assert.strictEqual(s.periodo, '2026-11-1');
});
prueba('v2.13.0 (#55): lo libre con salario bisemanal = pago × 26 ÷ 12', () => {
  const d2 = Object.assign({}, d, { salario: { frecuencia: 'bisemanal', fecha: '2026-11-06', monto: 450000 } });
  const lb = C.librePresupuesto(d2, hoy);
  assert.strictEqual(Math.round(lb.salario), Math.round(450000 * 26 / 12)); assert.strictEqual(lb.comoSalario, 'bisemanal');
  const d3 = Object.assign({}, d, { salario: { frecuencia: 'bisemanal', fecha: '2026-11-06' } });
  assert.strictEqual(Math.round(C.librePresupuesto(d3, hoy).salario), Math.round(900000 * 26 / 12), 'sin monto: promedio de cada pago');
});
console.log(`\n${ok} pruebas correctas`);
