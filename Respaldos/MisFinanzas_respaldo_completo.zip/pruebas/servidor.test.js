// Prueba de la "puerta" del servidor (doPost): clave, PIN y respuesta JSON.
// Simula los servicios de Google. Ejecutar: node pruebas/servidor.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');

const props = {};
const cache = {};
const ctx = {
  console,
  PropertiesService: { getScriptProperties: () => ({
    getProperty: (k) => (k in props ? props[k] : null),
    setProperty: (k, v) => { props[k] = v; }, setProperties: (o) => Object.assign(props, o),
    deleteProperty: (k) => { delete props[k]; } }) },
  CacheService: { getScriptCache: () => ({
    get: (k) => (k in cache ? cache[k] : null), put: (k, v) => { cache[k] = v; }, remove: (k) => { delete cache[k]; } }) },
  ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ texto: t, setMimeType() { return this; } }) },
  Utilities: {
    getUuid: () => crypto.randomUUID(),
    DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' },
    computeDigest: (alg, s) => [...crypto.createHash('sha256').update(s).digest()],
    base64Encode: (b) => Buffer.from(b).toString('base64')
  },
  SpreadsheetApp: { getActive: () => ({ getName: () => 'Mis Finanzas', getId: () => 'x' }) }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
vm.runInContext("obtenerDatos_ = function () { return 'DATOS'; };", ctx);

const post = (o) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(o) } }).texto);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.message); process.exitCode = 1; } }

props.CLAVE_APP = 'clave-correcta';
prueba('clave incorrecta → CLAVE_INVALIDA', () => {
  const r = post({ clave: 'mala', accion: 'ping' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.error, 'CLAVE_INVALIDA');
});
prueba('ping con clave correcta', () => {
  const r = post({ clave: 'clave-correcta', accion: 'ping' });
  assert.strictEqual(r.ok, true); assert.match(r.resultado, /Conectado/);
});
prueba('sin PIN, los datos salen con la clave', () => {
  const r = post({ clave: 'clave-correcta', accion: 'obtenerDatos' });
  assert.strictEqual(r.resultado, 'DATOS');
});
prueba('acción desconocida → error', () => {
  const r = post({ clave: 'clave-correcta', accion: 'borrarTodo' });
  assert.strictEqual(r.ok, false); assert.match(r.error, /desconocida/);
});
prueba('con PIN: sin sesión → PIN_REQUERIDO; con PIN correcto → datos', () => {
  const s0 = post({ clave: 'clave-correcta', accion: 'guardarPIN', args: ['4321', ''] });
  assert.strictEqual(s0.ok, true);
  assert.strictEqual(post({ clave: 'clave-correcta', accion: 'estadoAcceso' }).resultado.pinActivo, true);
  assert.strictEqual(post({ clave: 'clave-correcta', accion: 'obtenerDatos' }).error, 'PIN_REQUERIDO');
  assert.strictEqual(post({ clave: 'clave-correcta', accion: 'verificarPIN', args: ['0000'] }).ok, false);
  const ses = post({ clave: 'clave-correcta', accion: 'verificarPIN', args: ['4321'] }).resultado;
  assert.strictEqual(post({ clave: 'clave-correcta', sesion: ses, accion: 'obtenerDatos' }).resultado, 'DATOS');
});
prueba('largo del PIN y huella: activar, entrar, llave falsa, cambiar PIN borra huellas', () => {
  const K = 'clave-correcta';
  assert.strictEqual(post({ clave: K, accion: 'estadoAcceso' }).resultado.pinLargo, 4);
  assert.strictEqual(post({ clave: K, accion: 'activarHuella', args: ['9999', 'Fold'] }).ok, false, 'PIN malo no activa');
  for (const k of Object.keys(cache)) if (k === 'pin_fallos') delete cache[k];
  const h = post({ clave: K, accion: 'activarHuella', args: ['4321', 'Fold'] }).resultado;
  assert.ok(h.id && h.llave && h.sesion);
  assert.ok(!props.HUELLAS.includes(h.llave), 'la llave no se guarda en claro');
  const ses = post({ clave: K, accion: 'entrarConHuella', args: [h.id, h.llave] }).resultado;
  assert.strictEqual(post({ clave: K, sesion: ses, accion: 'obtenerDatos' }).resultado, 'DATOS');
  assert.strictEqual(post({ clave: K, accion: 'entrarConHuella', args: [h.id, 'falsa'] }).error, 'HUELLA_INVALIDA');
  delete cache.pin_fallos;
  post({ clave: K, sesion: ses, accion: 'guardarPIN', args: ['123456', '4321'] });
  assert.strictEqual(post({ clave: K, accion: 'estadoAcceso' }).resultado.pinLargo, 6);
  assert.strictEqual(post({ clave: K, accion: 'entrarConHuella', args: [h.id, h.llave] }).error, 'HUELLA_INVALIDA');
  delete cache.pin_fallos;
});
prueba('muchos intentos con clave mala → bloqueo temporal', () => {
  for (let i = 0; i < 12; i++) post({ clave: 'x' + i, accion: 'ping' });
  const r = post({ clave: 'clave-correcta', accion: 'ping' });
  assert.strictEqual(r.ok, false); assert.match(r.error, /Esperá 10 minutos/);
});
console.log(`\n${ok} pruebas correctas`);
