// Prueba de punta a punta del lector de correos (Gmail y la hoja simulados).
// Ejecutar: TZ=America/Costa_Rica node pruebas/gmail.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');
const { hojaSim } = require('./hoja-simulada');

function tabla(nombre, filaEnc, enc, filas) {
  const h = hojaSim(nombre);
  h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]);
  filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f]));
  return h;
}
const hojas = {
  'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado'], [['BCR', 'bcrtarjestcta@bancobcr.com', 'Activo'], ['Davibank', 'Alertas@davibank.cr', 'Activo']]),
  'Cuentas': tabla('Cuentas', 4, ['Nombre (único)', 'Tipo', 'Banco', 'Últimos 4', 'Moneda principal', 'Activa'], [
    ['Visa BCR', 'Tarjeta de crédito', 'BCR', '9125', 'CRC', 'Sí'], ['MC Davibank', 'Tarjeta de crédito', 'Davibank', '9615', 'USD', 'Sí'],
    ['Préstamo casa BCR', 'Préstamo', 'BCR', '', 'CRC', 'Sí'], ['Ahorros BCR colones', 'Cuenta de ahorro', 'BCR', '', 'CRC', 'Sí']]),
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'], []),
  'Sobres': tabla('Sobres', 4, ['Sobre', 'Moneda', 'Asignado por mes', 'Tipo'], [['SOBRE FONDOS DE INVERSION', 'CRC', 150000, 'Ahorro']]),
  'Reglas': tabla('Reglas', 4, ['Si el comercio contiene', 'Categoría', 'Sobre'], [['MASCOTAS', 'Mascotas', 'Varios']]),
  'Préstamo casa': tabla('Préstamo casa', 15, ['Cuota #', 'Fecha de pago', 'N° comprobante', 'Abono principal', 'Intereses', 'Pólizas', 'Pólizas BCR', 'Ajuste', 'Total pagado', 'Saldo', 'TBP (tasa real)', 'Tasa BCR'],
    [[183, new Date('2026-08-27'), '10000001', 77000, 126000, 62766.33, '', '', 265766.33, 22853253.09, '', 0.0665]])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };

// ---- Gmail simulado ----
const muestras = path.join(__dirname, 'muestras');
const recibo = fs.readFileSync(path.join(muestras, 'RECIBOPAGOPRESTAMO.TXT'), 'utf8');
const estado = fs.readFileSync(path.join(muestras, 'ESTADO_CUENTA_PRESTAMO.TXT'), 'utf8');
const adj = (nombre, txt) => ({ getName: () => nombre, getContentType: () => nombre.endsWith('.gif') ? 'image/gif' : 'text/plain', getDataAsString: () => txt });
let idn = 0;
function hilo(de, asunto, cuerpo, opc = {}) {
  const h = { etiquetas: new Set(opc.etiquetas || []), msgs: [] };
  (Array.isArray(cuerpo) ? cuerpo : [cuerpo]).forEach((c, i) => {
    const id = 'm' + (++idn);
    h.msgs.push({ de, getId: () => id, getDate: () => new Date(Date.now() - 3600e3 + i * 1000), getSubject: () => asunto, getPlainBody: () => c, getBody: () => opc.html || '', getAttachments: () => opc.adjuntos || [], getHeader: (k) => (opc.headers || {})[k] || '' });
  });
  h.getMessages = () => h.msgs;
  h.id = 'h' + (++idn); h.getId = () => h.id; h.markRead = () => { h.leido = true; }; h.moveToArchive = () => { h.archivado = true; };
  return h;
}
const T = (n) => fs.readFileSync(path.join(__dirname, 'correos.test.js'), 'utf8').match(new RegExp('const ' + n + ' = `([\\s\\S]*?)`;'))[1];
const hilos = [
  hilo('bcrtarjestcta@bancobcr.com', 'Notificación de Transacciones BCR', T('bcrTexto')),
  hilo('bcrtarjestcta@bancobcr.com', 'Notificación de Transacciones BCR', T('bcrTexto')),                 // correo repetido
  hilo('mensajero@bancobcr.com', 'SINPEMOVIL - Notificación de transacción realizada', [T('sinpeRecibido'), T('sinpeEnviado')], { adjuntos: [adj('logo.gif', 'GIF')], etiquetas: ['Finanzas/Revisar'] }),
  hilo('mensajero@bancobcr.com', 'Recibo de Pago de Prestamo', 'Le informamos que en esta fecha usted realizo un pago en las cajas.', { adjuntos: [adj('RECIBOPAGOPRESTAMO.TXT', recibo)] }),
  hilo('mensajero@bancobcr.com', 'Recibo de Pago de Prestamo', 'Le informamos que en esta fecha usted realizo un pago en las cajas.', { adjuntos: [adj('RECIBOPAGOPRESTAMO.TXT', recibo)] }),
  hilo('mensajero@bancobcr.com', 'Estado de cuenta operacion de credito BCR', 'Adjunto encontrara el estado de cuenta', { adjuntos: [adj('OP_X_092026.TXT', estado)] }),
  hilo('Alertas@davibank.cr', 'Alerta Transacción Tarjeta de Crédito Titular', T('dvCompra')),
  hilo('Alertas@davibank.cr', 'Pago de Servicio', T('dvServicio')),
  hilo('Alertas@davibank.cr', 'Promoción', 'Conozca nuestras tarjetas'),
  hilo('mensajerobcrsafi@bancobcr.com', 'Solicitud de inversión', T('safiInv')),
  hilo('bcrtarjestcta@bancobcr.com', 'ESTADO DE CUENTA', '', { adjuntos: [adj('Estado_de_cuenta_X.pdf', '%PDF')], etiquetas: ['Finanzas/Revisar'] }),
  hilo('mensajerobcrsafi@bancobcr.com', 'BCR Fondos de Inversión. Orden Nº 574434', 'Orden adjunta', { adjuntos: [adj('Orden Nº 574434-7.pdf', '%PDF')] })
];
function coincide(h, q) {
  const m0 = h.msgs[0];
  for (const tok of q.match(/-?\w+:(\([^)]*\)|\S+)/g) || []) {
    const neg = tok[0] === '-'; const [k, ...v] = tok.replace(/^-/, '').split(':'); const val = v.join(':').replace(/[()]/g, '').toLowerCase();
    let ok = true;
    if (k === 'from') ok = m0.de.toLowerCase() === val;
    else if (k === 'subject') ok = m0.getSubject().toLowerCase().includes(val);
    else if (k === 'has') ok = m0.getAttachments().length > 0;
    else if (k === 'label') ok = [...h.etiquetas].some(e => e.toLowerCase().replace(/[\/ ]/g, '-') === val);
    else if (k === 'after') ok = true;
    else if (k === 'in') ok = val === 'inbox' ? !h.archivado : true;
    if (neg ? ok : !ok) return false;
  }
  return true;
}
const etiquetas = {};
const GmailApp = {
  search: (q) => hilos.filter(h => coincide(h, q)),
  getUserLabelByName: (n) => etiquetas[n] || null,
  createLabel: (n) => (etiquetas[n] = { addToThread: (h) => h.etiquetas.add(n), removeFromThread: (h) => h.etiquetas.delete(n), removeFromThreads: (l) => l.forEach(h => h.etiquetas.delete(n)) }),
  moveThreadsToInbox: (l) => l.forEach(h => { h.archivado = false; }),
  markThreadsRead: (l) => l.forEach(h => { h.leido = true; }), moveThreadsToArchive: (l) => l.forEach(h => { h.archivado = true; })
};
const props = { ULTIMA_REVISION: String(Date.now() - 2 * 3600e3) };
const ctx = {
  console: { log() {} }, GmailApp, SpreadsheetApp: { getActive: () => libro },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) },
  Utilities: { DigestAlgorithm: { MD5: 'md5' }, computeDigest: (a, s) => [...crypto.createHash('md5').update(s).digest()], base64EncodeWebSafe: (b) => Buffer.from(b).toString('base64url') }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);

let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const movs = () => JSON.parse(JSON.stringify(ctx.leerTabla_('Movimientos', 'Fecha').filas));

let msg;
prueba('procesarCorreos corre sin errores', () => { msg = ctx.procesarCorreos(); assert.match(msg, /Movimientos nuevos: 6/); assert.match(msg, /Pagos del préstamo: 1/); assert.match(msg, /Para revisar: 1/); });
prueba('compra BCR: una sola vez (aunque llegó 2 veces), tarjeta y regla aplicadas', () => {
  const m = movs().filter(x => x['Autorización'] === '00102853');
  assert.strictEqual(m.length, 1);
  assert.strictEqual(m[0]['Cuenta / tarjeta'], 'Visa BCR'); assert.strictEqual(m[0]['Categoría'], 'Mascotas'); assert.strictEqual(m[0]['Lugar'], 'Alajuela');
});
prueba('SINPE: recibido = Ingreso y enviado = Gasto, en la cuenta de ahorro BCR (no en el préstamo)', () => {
  const m = movs();
  const rec = m.find(x => x['Comercio / descripción'].startsWith('SINPE de')), env = m.find(x => x['Comercio / descripción'].startsWith('SINPE a'));
  assert.strictEqual(rec['Tipo'], 'Ingreso'); assert.strictEqual(env['Tipo'], 'Gasto');
  assert.strictEqual(rec['Cuenta / tarjeta'], 'Ahorros BCR colones'); assert.strictEqual(env['Cuenta / tarjeta'], 'Ahorros BCR colones');
});
prueba('el hilo de SINPE que estaba en Revisar pasa a Procesado', () => {
  assert.ok(!hilos[2].etiquetas.has('Finanzas/Revisar')); assert.ok(hilos[2].etiquetas.has('Finanzas/Procesado'));
});
prueba('Davibank: compra en $ a la tarjeta 9615 y servicio a la tarjeta Davibank con categoría Servicios', () => {
  const m = movs();
  const av = m.find(x => x['Autorización'] === '889833'), tc = m.find(x => /TELECABLE/.test(x['Comercio / descripción']));
  assert.strictEqual(av['Moneda'], 'USD'); assert.strictEqual(av['Cuenta / tarjeta'], 'MC Davibank');
  assert.strictEqual(tc['Cuenta / tarjeta'], 'MC Davibank'); assert.strictEqual(tc['Categoría'], 'Servicios');
});
prueba('préstamo: un solo pago (recibo repetido), con ajuste para cuadrar con el saldo del banco', () => {
  const p = ctx.leerTabla_('Préstamo casa', 'Fecha de pago').filas;
  assert.strictEqual(p.length, 2);
  const f = p[1];
  assert.strictEqual(String(f['N° comprobante']), '10184152'); assert.strictEqual(f['Abono principal'], 77725.8);
  assert.strictEqual(f['Pólizas'], 62766.33); assert.strictEqual(f['Tasa BCR'], 0.0661);
  assert.strictEqual(Math.round((22853253.09 - 77725.8 - f['Ajuste']) * 100) / 100, 22775527.29, 'saldo = el del banco');
});
prueba('estado de cuenta: no se anota ni se etiqueta (v2.10.2: se queda en la bandeja); la promoción queda para revisar', () => {
  assert.ok(!hilos[5].etiquetas.has('Finanzas/Procesado') && !hilos[5].etiquetas.has('Finanzas/Revisar'));
  assert.ok(hilos[8].etiquetas.has('Finanzas/Revisar'));
});
prueba('fondos: la solicitud de inversión sale del sobre de fondos (con tu nombre); la confirmación con PDF se ignora', () => {
  const m = movs().find(x => x['Autorización'] === 'SAFI-I-574434');
  assert.strictEqual(m['Tipo'], 'Inversión'); assert.strictEqual(m['Sobre'], 'SOBRE FONDOS DE INVERSION', 'reconoce el sobre de fondos por su nombre'); assert.strictEqual(m['Monto'], 43508);
  assert.strictEqual(m['Cuenta / tarjeta'], 'Ahorros BCR colones');
  assert.ok(hilos.find(h => /Orden/.test(h.msgs[0].getSubject())).etiquetas.has('Finanzas/Procesado'));
});
prueba('segunda pasada: no duplica nada', () => {
  const antes = movs().length;
  const m2 = ctx.procesarCorreos();
  assert.strictEqual(movs().length, antes); assert.match(m2, /Movimientos nuevos: 0/);
});
prueba('v2.10.2: estado de cuenta de la tarjeta: se queda en la bandeja, sin Revisar ni Procesado', () => {
  const h = hilos.find(x => x.msgs[0].getSubject() === 'ESTADO DE CUENTA');
  assert.ok(!h.archivado); assert.ok(!h.etiquetas.has('Finanzas/Revisar')); assert.ok(!h.etiquetas.has('Finanzas/Procesado'));
  assert.ok(!hilos[5].archivado && !hilos[5].etiquetas.has('Finanzas/Procesado'), 'estado de cuenta del préstamo también se queda');
});
prueba('v2.10.1: bandeja limpia: lo procesado sale de la bandeja y queda leído; lo de Revisar se queda', () => {
  assert.ok(hilos[0].archivado && hilos[0].leido, 'compra BCR archivada');
  assert.ok(hilos[2].archivado, 'SINPE archivado');
  assert.ok(!hilos[8].archivado, 'la promoción (Revisar) sigue en la bandeja');
  assert.strictEqual(props.BANDEJA_LIMPIA_V1, 'si');
});
prueba('v2.9.0: tarjeta que no es mía se salta (y cuenta); tarjeta desconocida se anota sin cuenta con la nota', () => {
  props.PREFS = JSON.stringify({ ajenas: { '4444': { nombre: 'Prueba', desde: '2026-11-04' } } });
  const otra = (u4, aut) => T('bcrTexto').replace('9125', u4).replace('00102853', aut).replace('83716366', aut + '9');
  const h1 = hilo('bcrtarjestcta@bancobcr.com', 'Notificación de Transacciones BCR', otra('4444', '00900001'));
  const h2 = hilo('bcrtarjestcta@bancobcr.com', 'Notificación de Transacciones BCR', otra('5555', '00900002'));
  hilos.push(h1, h2);
  const antes = movs().length;
  props.ULTIMA_REVISION = String(Date.now() - 2 * 3600e3);
  ctx.procesarCorreos();
  const m = movs();
  assert.strictEqual(m.length, antes + 1, 'solo se anota la desconocida');
  assert.ok(!m.some(x => x['Autorización'] === '00900001'));
  const d = m.find(x => x['Autorización'] === '00900002');
  assert.strictEqual(d['Cuenta / tarjeta'], ''); assert.match(d['Nota'], /Tarjeta ••5555 no está en Cuentas/);
  assert.ok(h1.etiquetas.has('Finanzas/Procesado'), 'el correo de la ajena queda procesado');
  assert.deepStrictEqual(JSON.parse(props.AJENAS_SALTADAS), { '4444': 1 });
  ctx.procesarCorreos();
  assert.deepStrictEqual(JSON.parse(props.AJENAS_SALTADAS), { '4444': 1 }, 'no vuelve a contar');
});
prueba('v2.10.6: tarjetas de la familia: BAC y Davibank reenviados se anotan como "Familia ••u4" sin sobre; lo demás reenviado no', () => {
  props.PREFS = JSON.stringify({ ajenas: { '4444': { nombre: 'Prueba', desde: '2026-11-04' } }, familia: { '7777': { persona: 'Ana', nombre: 'BAC' }, '8888': { persona: 'Ana', nombre: 'Davibank' } } });
  const bac = (u4, aut, monto) => `Notificación de transacción TIENDA PRUEBA 05-11-2026 - 14:20\nHola PERSONA DE PRUEBA\nA continuación le detallamos la transacción realizada:\nComercio:   TIENDA PRUEBA\nCiudad y país:   SAN JOSE, Costa Rica\nFecha:   Nov 5, 2026, 14:20\nVISA:   ************${u4}\nAutorización:   ${aut}\nReferencia:   55500011\nTipo de Transacción:   COMPRA\nMonto:   USD ${monto}\n¿Tiene dudas sobre esta transacción?`;
  const dv = (u4, aut) => T('dvCompra').replace('9615', u4).replace('889833', aut);
  const hs = [
    hilo('NotificacionBAC@baccredomatic.cr', 'Notificación de transacción TIENDA PRUEBA', bac('7777', '700001', '1,234.50')),
    hilo('NotificacionBAC@baccredomatic.cr', 'Notificación de transacción OTRA', bac('6666', '700002', '10.00')),
    hilo('Alertas@davibank.cr', 'Alerta Transacción Tarjeta de Crédito Titular', dv('8888', '800001'), { headers: { 'X-Forwarded-For': 'persona@ejemplo.com yo@ejemplo.com' } }),
    hilo('Alertas@davibank.cr', 'Alerta Transacción', dv('9615', '800002'), { headers: { 'X-Forwarded-For': 'persona@ejemplo.com yo@ejemplo.com' } }),
    hilo('persona@ejemplo.com', 'Fwd: Alerta Transacción', 'De: Alertas@davibank.cr\n' + dv('8888', '800003'))
  ];
  hilos.push(...hs);
  const antes = movs().length;
  props.ULTIMA_REVISION = String(Date.now() - 2 * 3600e3);
  ctx.procesarCorreos();
  const m = movs();
  const b = m.find(x => x['Autorización'] === 'BAC-700001');
  assert.ok(b, 'compra BAC anotada');
  assert.strictEqual(b['Cuenta / tarjeta'], 'Familia ••7777'); assert.strictEqual(b['Monto'], 1234.5); assert.strictEqual(b['Moneda'], 'USD');
  assert.strictEqual(b['Sobre'], ''); assert.match(b['Nota'], /familia/); assert.strictEqual(b['Lugar'], 'San Jose');
  assert.ok(!m.some(x => x['Autorización'] === 'BAC-700002'), 'BAC de una tarjeta que no es de la familia: no');
  assert.strictEqual(m.find(x => x['Autorización'] === '800001')['Cuenta / tarjeta'], 'Familia ••8888');
  assert.ok(!m.some(x => x['Autorización'] === '800002'), 'reenviado con una tarjeta mía: no se anota (es de otra persona)');
  assert.strictEqual(m.find(x => x['Autorización'] === '800003')['Cuenta / tarjeta'], 'Familia ••8888', 'reenviado a mano');
  assert.strictEqual(m.length, antes + 3, JSON.stringify(m.slice(antes)));
  assert.ok(hs[0].etiquetas.has('Finanzas/Procesado') && hs[4].etiquetas.has('Finanzas/Procesado'));
  assert.ok(!hilos[8].etiquetas.has('Finanzas/Procesado'), 'la promoción no se toca por la búsqueda de reenviados');
  ctx.procesarCorreos();
  assert.strictEqual(movs().length, antes + 3, 'no duplica');
});
prueba('v2.13.0: familia pausada no se anota (y cuenta); tarjeta ajena "sin ignorar" vuelve a anotarse', () => {
  props.PREFS = JSON.stringify({ ajenas: { '4444': { nombre: 'Prueba', off: true } }, familia: { '7777': { persona: 'Ana', nombre: 'BAC', pausada: true } } });
  props.AJENAS_SALTADAS = '{}';
  const bac = (u4, aut) => `Notificación de transacción TIENDA PAUSA 05-11-2026 - 15:20\nComercio:   TIENDA PAUSA\nCiudad y país:   SAN JOSE, Costa Rica\nFecha:   Nov 5, 2026, 15:20\nVISA:   ************${u4}\nAutorización:   ${aut}\nReferencia:   55500099\nTipo de Transacción:   COMPRA\nMonto:   USD 9.99\n¿Tiene dudas sobre esta transacción?`;
  const otra = (u4, aut) => T('bcrTexto').replace('9125', u4).replace('00102853', aut).replace('83716366', aut + '9');
  hilos.push(hilo('NotificacionBAC@baccredomatic.cr', 'Notificación de transacción TIENDA PAUSA', bac('7777', '710001')), hilo('bcrtarjestcta@bancobcr.com', 'Notificación de Transacciones BCR', otra('4444', '00910001')));
  props.ULTIMA_REVISION = String(Date.now() - 2 * 3600e3);
  ctx.procesarCorreos();
  const m = movs();
  assert.ok(!m.some(x => x['Autorización'] === 'BAC-710001'), 'pausada: no se anota');
  assert.strictEqual(JSON.parse(props.AJENAS_SALTADAS).f7777, 1);
  const a = m.find(x => x['Autorización'] === '00910001');
  assert.ok(a, 'sin ignorar: se anota'); assert.match(a['Nota'], /4444/);
});
console.log(`\n${ok} pruebas correctas`);
