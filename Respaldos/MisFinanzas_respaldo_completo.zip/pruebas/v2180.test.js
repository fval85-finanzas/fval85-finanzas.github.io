// v2.18.0: devoluciones en el corte, IVA estimado que se confirma con el correo, app de la casa.  TZ=America/Costa_Rica node pruebas/v2180.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) { const h = hojaSim(nombre); h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]); filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f])); return h; }
const F = (d, h) => new Date(d + 'T' + (h || '12:00') + ':00-06:00');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 10).join('\n   ')); process.exitCode = 1; } }
const CTA = 'Familia ••4321';
const cfg = { cuenta: CTA, nombre: 'Súper de la casa', monto: 300000, dia: 24 };
const m = (f, monto, tipo, nota) => ({ fecha: F(f).toISOString(), monto, moneda: 'CRC', tipo: tipo || 'Gasto', cuenta: CTA, comercio: 'X', nota: nota || '' });
const hoy = F('2026-11-20');

prueba('corte: las devoluciones restan y se separa lo estimado', () => {
  const d = { tipoCambio: 500, movimientos: [m('2026-11-01', 248350), m('2026-11-20', 5200), m('2026-11-20', 676, 'Gasto', 'IVA estimado (13%) · se confirma cuando el banco lo aplique'), m('2026-11-20', 15000, 'Ingreso')] };
  const r = C.presupuestoCorte(d, cfg, hoy);
  assert.strictEqual(r.gastado, 248350 + 5200 + 676 - 15000); assert.strictEqual(r.brutas, 254226); assert.strictEqual(r.devoluciones, 15000); assert.strictEqual(r.estimado, 676);
  assert.strictEqual(r.compras.filter(x => x.devolucion).length, 1);
});
prueba('una devolución en la tarjeta de la familia no es ingreso tuyo', () => {
  const d = { movimientos: [m('2026-11-20', 15000, 'Ingreso'), Object.assign(m('2026-11-20', 1000, 'Ingreso'), { cuenta: 'Ahorros' })], cuentas: [], sobres: [], tasaCero: [] };
  const r = C.resumenMes(d, F('2026-11-20'));
  assert.strictEqual(r.ingresos.CRC, 1000);
});

// ---- servidor
const enc = ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'];
const hojas = {
  'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado', 'Origen'], [['BCR', 'x@ejemplo.com', 'Activo', 'Correo'], ['', '', '', 'Manual']]),
  'Movimientos': tabla('Movimientos', 4, enc, [
    [F('2026-11-10'), 'AUTOMERCADO DEMO', '', 42380, 'CRC', 'Gasto', CTA, 'Supermercado', '', 'Correo', 'A1', ''],
    [F('2026-11-12'), 'Mía', '', 99999, 'CRC', 'Gasto', 'Tarjeta A', '', '', 'Manual', '', ''],
    [F('2026-11-18', '08:00'), 'IVA · Google One', '', 676, 'CRC', 'Gasto', CTA, '', '', 'Manual', 'IVA-77', 'IVA estimado (13%) · se confirma cuando el banco lo aplique']])
};
hojas.Config.getRange(15, 2, 1, 1).setValues([[505]]);
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = { PREFS: JSON.stringify({ cortes: [cfg] }) }, cache = {};
let n = 0;
const ctx = { console: { log() {} }, SpreadsheetApp: { getActive: () => libro, flush() {} },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) },
  CacheService: { getScriptCache: () => ({ get: (k) => cache[k] || null, put: (k, v) => { cache[k] = v; }, remove: (k) => { delete cache[k]; } }) },
  Utilities: { getUuid: () => 'abcdef12-3456-7890-abcd-ef12345678' + String(++n).padStart(2, '0') },
  ScriptApp: { getService: () => ({ getUrl: () => 'https://script.google.com/macros/s/IMPL123/exec' }) } };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
const filas = () => JSON.parse(JSON.stringify(ctx.leerTabla_('Movimientos', 'Fecha').filas));

prueba('IVA estimado: el cobro del IVA en el correo lo confirma con el monto real', () => {
  const mov = ctx.leerTabla_('Movimientos', 'Fecha');
  const correo = { 'Fecha': F('2026-11-22'), 'Comercio / descripción': 'IVA SERVICIOS DIGITALES', 'Monto': 702, 'Moneda': 'CRC', 'Tipo': 'Gasto', 'Cuenta / tarjeta': CTA, 'Nota': '' };
  assert.strictEqual(ctx.buscarIVAEstimado_(mov, correo, {})._fila, 7);
  assert.strictEqual(ctx.buscarIVAEstimado_(mov, Object.assign({}, correo, { 'Comercio / descripción': 'AUTOMERCADO' }), {}), null, 'sin la palabra IVA no');
  assert.strictEqual(ctx.buscarIVAEstimado_(mov, Object.assign({}, correo, { 'Monto': 5000 }), {}), null, 'monto muy distinto no');
  assert.strictEqual(ctx.buscarIVAEstimado_(mov, Object.assign({}, correo, { 'Fecha': F('2026-12-20') }), {}), null, 'mucho después no');
});
let token;
prueba('app de la casa: crear link, ver solo esa tarjeta', () => {
  assert.throws(() => ctx.casaLink_('Tarjeta A', {}), /Primero activá/);
  const e = ctx.casaLink_(CTA, { persona: 'Persona B' });
  assert.ok(e.activo && e.token.length >= 20 && e.implementacion === 'IMPL123'); token = e.token;
  assert.throws(() => ctx.apiCasa_('x'.repeat(30), 'ver', []), /ya no sirve/);
  const v = JSON.parse(JSON.stringify(ctx.apiCasa_(token, 'ver', [])));
  assert.strictEqual(v.cfg.nombre, 'Súper de la casa'); assert.strictEqual(v.tipoCambio, 505); assert.strictEqual(v.persona, 'Persona B');
  assert.deepStrictEqual(v.movimientos.map(x => x.monto), [42380, 676], 'no ve la compra de la otra tarjeta');
  assert.ok(!('autorizacion' in v.movimientos[0]) || v.movimientos[0].autorizacion === '', 'no manda autorizaciones');
  assert.strictEqual(JSON.parse(JSON.stringify(ctx.apiCasa_(token, 'ver', [v.marca]))).sinCambios, true);
});
prueba('app de la casa: anotar, corregir y borrar solo lo suyo', () => {
  const r = ctx.apiCasa_(token, 'guardar', [{ tipo: 'Gasto', monto: 23450, comercio: 'Pali', fecha: F('2026-11-20').toISOString(), cuenta: 'Tarjeta A', sobre: 'X' }]);
  let f = filas().find(x => x._fila === r.fila);
  assert.strictEqual(f['Cuenta / tarjeta'], CTA, 'siempre a la tarjeta de la casa'); assert.strictEqual(f['Sobre'], ''); assert.match(f['Nota'], /app de la casa · Persona B/); assert.strictEqual(f['Categoría'], 'Supermercado'); assert.strictEqual(f['Autorización'], '');
  ctx.apiCasa_(token, 'guardar', [{ fila: r.fila, tipo: 'Gasto', monto: 23500, comercio: 'Pali' }]);
  assert.strictEqual(filas().find(x => x._fila === r.fila)['Monto'], 23500);
  assert.throws(() => ctx.apiCasa_(token, 'borrar', [5]), /Solo podés cambiar/);
  assert.throws(() => ctx.apiCasa_(token, 'guardar', [{ fila: 6, monto: 1 }]), /Solo podés cambiar/);
  const dv = ctx.apiCasa_(token, 'guardar', [{ tipo: 'Ingreso', monto: 15000, comercio: 'Walmart' }]);
  f = filas().find(x => x._fila === dv.fila); assert.strictEqual(f['Tipo'], 'Ingreso'); assert.match(f['Nota'], /^Devolución \/ crédito · app de la casa/);
  ctx.apiCasa_(token, 'borrar', [r.fila]); assert.ok(!filas().some(x => x['Comercio / descripción'] === 'Pali'));
});
prueba('app de la casa: permisos y apagar el link', () => {
  ctx.casaPermisos_(CTA, { anotar: false });
  assert.throws(() => ctx.apiCasa_(token, 'guardar', [{ monto: 1 }]), /solo deja ver/);
  const e2 = ctx.casaLink_(CTA, { nuevo: true }); assert.notStrictEqual(e2.token, token);
  assert.throws(() => ctx.apiCasa_(token, 'ver', []), /ya no sirve/);
  ctx.casaApagar_(CTA); assert.throws(() => ctx.apiCasa_(e2.token, 'ver', []), /ya no sirve/);
  assert.strictEqual(ctx.casaEstado_(CTA).activo, false);
});
console.log(`\n${ok} pruebas correctas`);
