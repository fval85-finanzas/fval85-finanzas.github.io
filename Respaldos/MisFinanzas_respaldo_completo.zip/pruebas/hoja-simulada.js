// Hoja de cálculo simulada en memoria para las pruebas del servidor.
function hojaSim(nombre) {
  const celdas = {}; let maxR = 1000;
  const get = (r, c) => (celdas[r + ',' + c] === undefined ? '' : celdas[r + ',' + c]);
  const sh = {
    nombre,
    getLastRow: () => Math.max(0, ...Object.keys(celdas).filter(k => celdas[k] !== '').map(k => +k.split(',')[0])),
    getLastColumn: () => Math.max(1, ...Object.keys(celdas).filter(k => celdas[k] !== '').map(k => +k.split(',')[1])),
    getMaxRows: () => maxR, insertRowsAfter: (r, n) => { maxR += n; },
    deleteRow: (r) => {
      const n = {}; for (const k of Object.keys(celdas)) { const [rr, cc] = k.split(',').map(Number); if (rr < r) n[k] = celdas[k]; else if (rr > r) n[(rr - 1) + ',' + cc] = celdas[k]; }
      for (const k of Object.keys(celdas)) delete celdas[k]; Object.assign(celdas, n);
    },
    setFrozenRows() {}, setColumnWidth() {},
    appendRow: (fila) => { const r = sh.getLastRow() + 1; fila.forEach((x, j) => { celdas[r + ',' + (j + 1)] = x; }); },
    getRange(r, c, nr, nc) {
      if (typeof r === 'string') {   // notación A1 (solo para formato): devolvemos un rango que ignora todo
        const m = r.match(/^([A-Z])(\d+)$/);
        if (m) { r = +m[2]; c = m[1].charCodeAt(0) - 64; nr = 1; nc = 1; }
        else if (/^([A-Z]):\1$/.test(r)) {   // columna entera: solo para buscar
          const col = r.charCodeAt(0) - 64;
          return { createTextFinder: (v) => ({ matchEntireCell() { return this; }, findNext: () => { for (let i = 1; i <= sh.getLastRow(); i++) if (String(get(i, col)) === String(v)) return { getRow: () => i }; return null; } }) };
        }
        else return encadenable({});
      }
      nr = nr || 1; nc = nc || 1;
      const rg = {
        getValues: () => Array.from({ length: nr }, (_, i) => Array.from({ length: nc }, (_, j) => get(r + i, c + j))),
        getDisplayValues: () => rg.getValues().map(f => f.map(String)),
        getValue: () => get(r, c),
        getFormulas: () => Array.from({ length: nr }, () => Array.from({ length: nc }, () => '')),
        setValues: (v) => { v.forEach((f, i) => f.forEach((x, j) => { celdas[(r + i) + ',' + (c + j)] = x; })); return encadenable(rg); },
        setValue: (x) => { celdas[r + ',' + c] = x; return encadenable(rg); }
      };
      return encadenable(rg);
    }
  };
  return sh;
}
function encadenable(o) {
  return new Proxy(o, { get: (t, k) => (k in t ? t[k] : () => encadenable(t)) });
}
module.exports = { hojaSim, encadenable };
