// v2.4.0: filas de la hoja Sobres que no son sobres; pago de tarjeta cubierto por compras asignadas.  TZ=America/Costa_Rica node pruebas/v240.test.js
const assert = require('assert');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.message); process.exitCode = 1; } }
prueba('totales y notas al pie no son sobres', () => {
  const nombres = ['SOBRE INGLES', 'Supermercado', 'Total asignado ₡', 'Total asignado $', 'Los movimientos de Tipo "Pago de tarjeta" no se descuentan de ningún sobre (cada compra ya se contó).', ''];
  assert.deepStrictEqual(nombres.filter(n => C.esSobreReal({ nombre: n })), ['SOBRE INGLES', 'Supermercado']);
});
prueba('v2.8: compras de la tarjeta asignadas antes ya no cubren el pago (el pago pregunta)', () => {
  const d = {
    sobresDesde: '2026-10-01', cuentas: [{ nombre: 'Visa', tipo: 'Tarjeta de crédito' }],
    sobres: [{ nombre: 'Salud', moneda: 'CRC' }, { nombre: 'Colegio', moneda: 'CRC' }],
    movimientos: [
      { fila: 5, fecha: '2026-10-10T12:00:00-06:00', monto: 6500, moneda: 'CRC', tipo: 'Gasto', cuenta: 'Visa' },
      { fila: 6, fecha: '2026-10-12T12:00:00-06:00', monto: 8000, moneda: 'CRC', tipo: 'Gasto', cuenta: 'Visa' },
      { fila: 7, fecha: '2026-10-20T12:00:00-06:00', monto: 15000, moneda: 'CRC', tipo: 'Pago de tarjeta', cuenta: 'Visa' }],
    sobresMov: [
      { sobre: 'Salud', monto: -6500, tipo: 'Compra con tarjeta', movimiento: 5, grupo: 'g' },
      { sobre: 'Colegio', monto: -8000, tipo: 'Compra con tarjeta', movimiento: 6, grupo: 'g' },
      { sobre: '', monto: -500, tipo: 'Pago tarjeta', movimiento: 7, grupo: 'g' }]
  };
  const a = C.analizarSobres(d);
  assert.strictEqual(a.pendientes.length, 1); assert.strictEqual(a.pendientes[0].falta, 14500);
  assert.strictEqual(a.efectos.filter(e => e.sobre === 'Salud' || e.sobre === 'Colegio').length, 0);
});
console.log(ok + ' pruebas correctas');
