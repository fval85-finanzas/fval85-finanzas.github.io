// v2.10.0: viajes (ligadas antes, efectivo, presupuesto, por tarjeta, Vuelos), porPagarTarjeta, avisos de viaje.  TZ=America/Costa_Rica node pruebas/v2100.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const d = {
  tipoCambio: 500,
  cuentas: [
    { fila: 2, nombre: 'Tarjeta A', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, ultimos4: '1111', diaCorte: 20, diaPago: 6, saldoCRC: 100000, fechaSaldo: '2026-10-25T12:00:00-06:00' },
    { fila: 3, nombre: 'Tarjeta B', tipo: 'Tarjeta de crédito', moneda: 'USD', activa: true, ultimos4: '2222' },
    { fila: 4, nombre: 'Ahorros', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true, saldoCRC: 100000, fechaSaldo: '2026-10-01T12:00:00-06:00' }
  ],
  viajes: [{ fila: 5, id: 'v123', activo: true, nombre: 'Panamá', desde: '2026-11-10T12:00:00-06:00', hasta: '2026-11-16T12:00:00-06:00', limite: 1500, moneda: 'USD', tarjetas: ['Tarjeta A', 'Tarjeta B', 'Efectivo'], presupuesto: { Comida: 150, Vuelos: 400 } }],
  movimientos: [
    { fila: 10, fecha: '2026-10-20T10:00:00-06:00', tipo: 'Gasto', monto: 380, moneda: 'USD', cuenta: 'Tarjeta B', comercio: 'COPA AIRLINES', viaje: '+Vuelos@v123' },
    { fila: 11, fecha: '2026-10-21T10:00:00-06:00', tipo: 'Gasto', monto: 140, moneda: 'USD', cuenta: 'Tarjeta B', comercio: 'BOOKING.COM' },   // no ligada
    { fila: 12, fecha: '2026-11-12T10:00:00-06:00', tipo: 'Gasto', monto: 50000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'RESTAURANTE MAR' },   // $100 comida
    { fila: 13, fecha: '2026-11-12T12:00:00-06:00', tipo: 'Gasto', monto: 80, moneda: 'USD', cuenta: 'Tarjeta B', comercio: 'CAFE CASCO' },
    { fila: 14, fecha: '2026-11-12T13:00:00-06:00', tipo: 'Gasto', monto: 15, moneda: 'USD', cuenta: 'Efectivo', comercio: 'Taxi', viaje: '+Transporte@v123', origen: 'Manual' },
    { fila: 15, fecha: '2026-11-11T09:00:00-06:00', tipo: 'Gasto', monto: 100000, moneda: 'CRC', cuenta: 'Ahorros', comercio: 'Retiro de cajero', viaje: 'Efectivo@v123' },   // $200 a efectivo
    { fila: 16, fecha: '2026-11-13T10:00:00-06:00', tipo: 'Gasto', monto: 20, moneda: 'USD', cuenta: 'Tarjeta B', comercio: 'OTRO VIAJE', viaje: '+Otros@zzz' }   // de otro viaje
  ]
};
const hoy = new Date(2026, 10, 13, 12);
prueba('viaje: compra de antes ligada cuenta; la no ligada no; la de otro viaje no; el retiro no es gasto', () => {
  const r = C.viaje(d, d.viajes[0], hoy);
  assert.deepStrictEqual(r.compras.map(c => c.mov.fila).sort(), [10, 12, 13, 14]);
  assert.strictEqual(Math.round(r.gastado), 380 + 100 + 80 + 15);
  assert.strictEqual(r.antes, 380); assert.strictEqual(Math.round(r.durante), 195);
});
prueba('viaje: por tarjeta, efectivo del viaje y Vuelos', () => {
  const r = C.viaje(d, d.viajes[0], hoy);
  assert.strictEqual(r.porTarjeta['Tarjeta B'].monto, 460); assert.strictEqual(r.porTarjeta['Tarjeta B'].n, 2);
  assert.strictEqual(r.porTarjeta['Tarjeta A'].monto, 100); assert.strictEqual(r.porTarjeta.Efectivo.monto, 15);
  assert.strictEqual(r.efectivo.retirado, 200); assert.strictEqual(r.efectivo.gastado, 15); assert.strictEqual(r.efectivo.queda, 185);
  assert.strictEqual(r.porCategoria.Vuelos, 380); assert.strictEqual(C.categoriaViaje({ comercio: 'AVIANCA' }), 'Vuelos');
});
prueba('viaje: presupuesto por categoría (Comida se pasó) y ayer', () => {
  const r = C.viaje(d, d.viajes[0], hoy);
  assert.strictEqual(r.presupuesto.Comida.gastado, 180); assert.ok(r.presupuesto.Comida.gastado > r.presupuesto.Comida.limite);
  assert.strictEqual(r.presupuesto.Vuelos.gastado, 380);
  assert.strictEqual(Math.round(r.ayer), 195); assert.strictEqual(r.diaActual, 4);
});
prueba('efectivo: el gasto en efectivo no baja la cuenta de ahorros (ya salió con el retiro)', () => {
  const o = C.origenes(d, { principal: 'Ahorros' });
  const ef = C.efectosCuentas(d, o);
  assert.ok(!ef.some(e => e.mov && e.mov.fila === 14));
  assert.ok(ef.some(e => e.mov && e.mov.fila === 15 && e.cuenta === 'Ahorros'), 'el retiro sí sale de Ahorros');
});
prueba('porPagarTarjeta: deuda sin compras después del corte', () => {
  const d2 = { cuentas: [d.cuentas[0]], movimientos: [{ fecha: '2026-11-02T10:00:00-06:00', tipo: 'Gasto', monto: 5000, moneda: 'CRC', cuenta: 'Tarjeta A' }, { fecha: '2026-10-28T10:00:00-06:00', tipo: 'Gasto', monto: 3000, moneda: 'CRC', cuenta: 'Tarjeta A' }] };
  const p = C.porPagarTarjeta(d2, d2.cuentas[0], new Date(2026, 10, 4));
  assert.strictEqual(p.deuda.CRC, 108000); assert.strictEqual(p.CRC, 100000, 'corte 20 oct: las dos compras son después del corte (van al próximo)');
  const p2 = C.porPagarTarjeta(d2, d2.cuentas[0], new Date(2026, 10, 22));
  assert.strictEqual(p2.CRC, 108000, 'corte 20 nov: ya entran al estado');
});
prueba('servidor: resumen de avisos con el viaje en curso', () => {
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
  ctx.obtenerDatos_ = () => JSON.stringify(d); ctx.prefs_ = () => ({}); ctx.listasDatos_ = () => [];
  const RealDate = Date; ctx.Date = class extends RealDate { constructor(...a) { if (!a.length) return new RealDate(2026, 10, 13, 8); return new RealDate(...a); } static now() { return new RealDate(2026, 10, 13, 8).getTime(); } };
  vm.runInContext('Date = this.Date', ctx);
  const r = ctx.resumenAvisos_();
  assert.strictEqual(r.viajes.length, 1, r.errViajes || JSON.stringify(r));
  const v = r.viajes[0];
  assert.strictEqual(v.dia, 4); assert.strictEqual(Math.round(v.ayer), 195); assert.ok(v.pasadas.some(p => p.cat === 'Comida'));
});
console.log(`\n${ok} pruebas correctas`);
