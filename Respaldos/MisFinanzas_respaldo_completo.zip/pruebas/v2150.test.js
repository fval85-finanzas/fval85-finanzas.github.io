// v2.15.0 (#62): pagos repartidos por compra tasa cero, adelantos que no bajan la cuota.  TZ=America/Costa_Rica node pruebas/v2150.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) { const h = hojaSim(nombre); h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]); filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f])); return h; }
const F = (d) => new Date(d + 'T12:00:00-06:00');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 10).join('\n   ')); process.exitCode = 1; } }
const hoy = new Date('2026-11-16T20:00:00-06:00');
function compra(extra) {
  const t = { descripcion: 'TV DEMO', tarjeta: 'Tarjeta A', monto: 300000, moneda: 'CRC', meses: 18, primeraCuota: F('2026-05-20').toISOString(), abonos: [] };
  (extra || []).forEach(a => t.abonos.push(Object.assign({ gasto: false }, a, { fecha: F(a.fecha).toISOString() })));
  return t;
}
const pagos = ['06', '07', '08', '09', '10', '11'].map(m => ({ fecha: '2026-' + m + '-16', monto: 15000, tipo: 'pago' }));

prueba('adelanto: el banco mantiene la cuota y no cuenta como gasto', () => {
  const t = compra([{ fecha: '2026-06-02', monto: 150000, tipo: 'adelanto' }]);
  const e = C.estadoTasaCero(t, hoy);
  assert.strictEqual(Math.round(e.cuota), 16667); assert.strictEqual(Math.round(e.saldo), 200000); assert.strictEqual(e.abonado, 0);
  assert.strictEqual(C.abonosEnMes(t, F('2026-06-10')), 0);
  const t2 = compra([{ fecha: '2026-06-02', monto: 150000, gasto: true }]);
  assert.ok(C.estadoTasaCero(t2, hoy).cuota < 9000, 'un abono normal sí baja la cuota');
});
prueba('cuenta por compra: pagos de ₡15.000 con adelanto de ₡150.000', () => {
  const cu = C.cuentaTasaCero(compra([{ fecha: '2026-06-02', monto: 150000, tipo: 'adelanto' }].concat(pagos)), hoy);
  assert.strictEqual(cu.pagado, 90000); assert.strictEqual(cu.adelanto, 150000);
  assert.strictEqual(Math.round(cu.usado), 10000); assert.strictEqual(Math.round(cu.queda), 140000);
  assert.strictEqual(Math.round(cu.antes), 16667, 'la cuota de mayo, antes de llevar la cuenta, se toma como pagada');
  assert.strictEqual(Math.round(cu.puesto), 256667); assert.strictEqual(Math.round(cu.falta), 43333);
  assert.strictEqual(cu.restantes, 11); assert.strictEqual(cu.alcanza, true); assert.strictEqual(Math.round(cu.sobra), 121667);
});
prueba('sin pagos ni adelantos no hay cuenta; pagos sin adelanto dejan "sin cubrir"', () => {
  assert.strictEqual(C.cuentaTasaCero(compra(), hoy), null);
  const cu = C.cuentaTasaCero(compra(pagos), hoy);
  assert.strictEqual(Math.round(cu.sinCubrir), 10000); assert.strictEqual(cu.queda, 0);
});
prueba('cuota cobrada después del último pago anotado queda "por pagar"', () => {
  const cu = C.cuentaTasaCero(compra(pagos.slice(0, 4)), hoy);   // último pago: 16 sep
  assert.strictEqual(cu.nPorPagar, 1); assert.strictEqual(Math.round(cu.porPagar), 16667);   // la de oct (la de sep la paga el del 16 sep)
});

// ---- servidor
const hojas = {
  'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado', 'Categorías'], [['BCR', 'bcr@ejemplo.com', 'Activo', 'Compras']]),
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'], [
    [F('2026-10-02'), 'TV DEMO', '', 300000, 'CRC', 'Compra tasa cero', 'Tarjeta A', 'Compras', '', 'Correo', 'a1', ''],
    [F('2026-11-16'), 'Pago de tarjeta', '', 45000, 'CRC', 'Pago de tarjeta', 'Tarjeta A', '', '', 'Manual', 'PAGO-X1', '']]),
  'Tasa Cero': tabla('Tasa Cero', 6, ['Descripción', 'Tarjeta', 'Fecha de compra', 'Monto total', 'Moneda', 'Meses', 'Primera cuota'], [['TV DEMO', 'Tarjeta A', F('2026-05-01'), 300000, 'CRC', 18, F('2026-05-20')], ['CEL DEMO', 'Tarjeta A', F('2026-10-01'), 48000, 'CRC', 6, F('2026-11-20')]]),
  'Abonos tasa cero': tabla('Abonos tasa cero', 4, ['Fecha', 'Compra', 'Tarjeta', 'Monto', 'Moneda', 'De dónde salió', 'Contar como gasto', 'Movimiento', 'Nota'], [[F('2026-06-02'), 'TV DEMO', 'Tarjeta A', 150000, 'CRC', 'Ahorros', 'Sí', '', '']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = {};
const ctx = { console: { log() {} }, SpreadsheetApp: { getActive: () => libro, flush() {} },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) } };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
const abonos = () => JSON.parse(JSON.stringify(ctx.leerAbonosTC_()));

prueba('servidor: abono viejo sin Tipo se lee como "abono"; se puede pasar a adelanto', () => {
  assert.strictEqual(abonos()[0].tipo, 'abono');
  ctx.guardarAbonoTC_({ fila: 5, control: { monto: 150000 }, fecha: F('2026-06-02').toISOString(), compra: 'TV DEMO', tarjeta: 'Tarjeta A', monto: 150000, moneda: 'CRC', origen: 'Ahorros', gasto: false, tipo: 'adelanto' });
  const a = abonos(); assert.strictEqual(a.length, 1); assert.strictEqual(a[0].tipo, 'adelanto'); assert.strictEqual(a[0].gasto, false);
});
prueba('servidor: repartir un pago nuevo (se encuentra por autorización) y volver a repartirlo', () => {
  assert.strictEqual(ctx.API.guardarRepartoTC({ autorizacion: 'PAGO-X1', fecha: F('2026-11-16').toISOString(), moneda: 'CRC', reparto: [{ compra: 'TV DEMO', tarjeta: 'Tarjeta A', monto: 15000 }, { compra: 'CEL DEMO', tarjeta: 'Tarjeta A', monto: 8000 }] }), 2);
  let a = abonos().filter(x => x.tipo === 'pago'); assert.strictEqual(a.length, 2); assert.ok(a.every(x => x.movimiento === 6 && x.gasto === false));
  ctx.API.guardarRepartoTC({ movimiento: 6, reparto: [{ compra: 'TV DEMO', tarjeta: 'Tarjeta A', monto: 14000 }] });
  a = abonos().filter(x => x.tipo === 'pago'); assert.strictEqual(a.length, 1); assert.strictEqual(a[0].monto, 14000);
  assert.strictEqual(abonos().filter(x => x.tipo === 'adelanto').length, 1, 'el adelanto no se toca');
  assert.throws(() => ctx.API.guardarRepartoTC({ movimiento: 6, reparto: [{ compra: 'TV DEMO', monto: 99000 }] }), /mayor/);
  assert.throws(() => ctx.API.guardarRepartoTC({ movimiento: 5, reparto: [] }), /no es un pago/);
});
prueba('servidor: al borrar el pago se borra su reparto (el adelanto queda)', () => {
  assert.deepStrictEqual(abonos().map(a => a.tipo).sort(), ['adelanto', 'pago']);
  ctx.eliminarMovimiento_(6, { monto: 45000 });
  const a = abonos(); assert.strictEqual(a.length, 1); assert.strictEqual(a[0].tipo, 'adelanto');
});
console.log(`\n${ok} pruebas correctas`);
