// v2.5.0: listas compartidas, preferencias, fechas de salario, llave de avisos.  TZ=America/Costa_Rica node pruebas/v250.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
const C = require('../web/js/calculos.js');
const hojas = {};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = { CLAVE_APP: 'k' }, cache = {};
let uid = 0;
const ctx = {
  console: { log() {} }, SpreadsheetApp: { getActive: () => libro }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; }, deleteProperty: (k) => { delete props[k]; }, setProperties: (o) => Object.assign(props, o) }) },
  CacheService: { getScriptCache: () => ({ get: (k) => cache[k] || null, put: (k, v) => { cache[k] = v; }, remove: (k) => { delete cache[k]; } }) },
  ContentService: { createTextOutput: (t) => ({ t, setMimeType() { return this; } }), MimeType: { JSON: 'json' } },
  Utilities: { getUuid: () => (++uid).toString(16).padStart(7, '0') + 'a-bcde-f012-3456789abcdef', computeDigest: (a, s) => Array.from(Buffer.from(require('crypto').createHash('sha256').update(String(s)).digest())), base64Encode: (b) => Buffer.from(b).toString('base64'), DigestAlgorithm: {}, Charset: {} },
  ScriptApp: { getProjectTriggers: () => [], newTrigger: () => ({ timeBased: () => ({ everyHours: () => ({ create() {} }) }) }), getService: () => ({ getUrl: () => 'https://script.google.com/macros/s/AKfyDEP123/exec' }), getScriptId: () => 'SID' }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const post = (o) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(o) } }).t);
let lista, token;
prueba('crear lista con cosas y leerla', () => {
  lista = ctx.crearLista_('Super semanal', '🛒', [{ n: 'Leche', q: 4, u: 'L', p: 'Lácteos' }, { n: 'Arroz', q: 2, u: 'kg' }, { n: '' }]);
  assert.strictEqual(lista.items.length, 2);
  assert.strictEqual(ctx.listasResumen_()[0].total, 2);
});
prueba('link: ve y marca solo esa lista; sin clave no entra a lo demás', () => {
  token = ctx.linkLista_(lista.id).token;
  const v = post({ lista: token, accion: 'ver' });
  assert.ok(v.ok, v.error); assert.strictEqual(v.resultado.token, undefined);
  const m = post({ lista: token, accion: 'cambiar', args: [{ t: 'marcar', item: lista.items[0].id, on: true }, 'Ana'] });
  assert.ok(m.ok); assert.ok(m.resultado.items[0].on); assert.match(m.resultado.cambio.txt, /Ana marcó Leche/);
  const otra = post({ lista: token, accion: 'obtenerDatos' }); assert.ok(!otra.ok);
  const sinClave = post({ accion: 'obtenerDatos' }); assert.ok(!sinClave.ok);
});
prueba('versión: si no cambió, responde sin datos', () => {
  const v = post({ lista: token, accion: 'ver' }).resultado.v;
  assert.ok(post({ lista: token, accion: 'ver', args: [v] }).resultado.sinCambios);
});
prueba('foto pequeña y "¿este sirve?" con respuesta', () => {
  const fid = post({ lista: token, accion: 'subirFoto', args: ['data:image/jpeg;base64,AAAA'] }).resultado;
  post({ lista: token, accion: 'cambiar', args: [{ t: 'consulta', item: lista.items[1].id, foto: fid, msg: '¿Este?' }, 'Ana'] });
  const fr = post({ lista: token, accion: 'foto', args: [fid] }); assert.strictEqual(fr.resultado, 'data:image/jpeg;base64,AAAA', JSON.stringify(fr) + ' fid=' + fid);
  const r = ctx.cambiarLista_(lista.id, { t: 'responder', item: lista.items[1].id, si: true }, 'Yo', false);
  assert.ok(r.items[1].on, JSON.stringify(r.items[1])); assert.strictEqual(r.items[1].consulta.resp.si, true);
});
prueba('lista no editable por link: solo marcar', () => {
  ctx.cambiarLista_(lista.id, { t: 'editable', on: false }, 'Yo', false);
  assert.ok(!post({ lista: token, accion: 'cambiar', args: [{ t: 'agregar', datos: { n: 'Pan' } }, 'Ana'] }).ok);
});
prueba('terminar: pendientes se quedan y se limpian marcas y fotos de consulta', () => {
  ctx.cambiarLista_(lista.id, { t: 'marcar', item: lista.items[0].id, on: false }, 'Yo', false);
  const r = ctx.cambiarLista_(lista.id, { t: 'terminar', pendientes: 'dejar' }, 'Yo', false);
  assert.strictEqual(r.items.length, 2); assert.ok(r.items.every(x => !x.on && !x.consulta));
  assert.strictEqual(hojas['Fotos listas'].getLastRow(), 1);
});
prueba('cambiar link: el viejo deja de servir', () => {
  const nuevo = ctx.linkLista_(lista.id, true).token;
  assert.ok(!post({ lista: token, accion: 'ver' }).ok); assert.ok(post({ lista: nuevo, accion: 'ver' }).ok);
});
prueba('preferencias y llave de avisos', () => {
  ctx.guardarPreferencias_({ salario: { activo: true, frecuencia: 'bisemanal', fecha: '2026-10-30' } });
  assert.strictEqual(ctx.prefs_().salario.frecuencia, 'bisemanal');
  const llave = ctx.activarAvisosTelefono_();
  assert.ok(ctx.llaveAvisosValida_(llave)); assert.ok(!ctx.llaveAvisosValida_('otra'));
});
prueba('fechas de salario bisemanal y quincenal con fin de semana', () => {
  const f = C.fechasSalario({ frecuencia: 'bisemanal', fecha: '2026-10-30' }, '2026-11-01', '2026-11-30').map(d => d.getDate());
  assert.deepStrictEqual(f, [13, 27]);
  const q = C.fechasSalario({ frecuencia: 'quincenal', dias: [15, 31], finde: 'antes' }, '2026-11-01', '2026-11-30').map(d => d.getDate());
  assert.deepStrictEqual(q, [13, 30]);
});
prueba('URL de actualización: solo GitHub Pages y no se puede cambiar desde la app', () => {
  assert.throws(() => ctx.fijarUrlActualizacion_('https://malo.com/'));
  assert.strictEqual(ctx.fijarUrlActualizacion_('https://alguien.github.io/finanzas/index.html'), 'https://alguien.github.io/finanzas/');
  assert.throws(() => ctx.fijarUrlActualizacion_('https://otro.github.io/x/'));
});
console.log(ok + ' pruebas correctas');
