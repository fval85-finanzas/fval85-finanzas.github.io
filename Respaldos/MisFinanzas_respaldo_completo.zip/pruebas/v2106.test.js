// v2.10.6: tarjetas de la familia (solo viajes) + lector BAC.  TZ=America/Costa_Rica node pruebas/v2106.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const d = {
  tipoCambio: 500, tasaCero: [],
  ajustes: { prefs: { familia: { '7777': { persona: 'Ana', nombre: 'Visa BAC' }, '8888': { persona: 'Ana', nombre: 'MC Davibank' } }, origenes: { principal: 'Ahorros' } } },
  cuentas: [
    { fila: 2, nombre: 'Tarjeta A', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, ultimos4: '1111', saldoCRC: 0, fechaSaldo: '2026-11-01T12:00:00-06:00' },
    { fila: 4, nombre: 'Ahorros', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true, saldoCRC: 100000, fechaSaldo: '2026-10-01T12:00:00-06:00' }
  ],
  viajes: [{ fila: 5, id: 'v1', nombre: 'Panamá', desde: '2026-11-10T12:00:00-06:00', hasta: '2026-11-16T12:00:00-06:00', limite: 2000, moneda: 'USD', tarjetas: ['Tarjeta A'] }],
  movimientos: [
    { fila: 10, fecha: '2026-11-12T10:00:00-06:00', tipo: 'Gasto', monto: 50000, moneda: 'CRC', cuenta: 'Tarjeta A', comercio: 'RESTAURANTE MAR', categoria: 'Comida' },
    { fila: 11, fecha: '2026-11-12T12:00:00-06:00', tipo: 'Gasto', monto: 48, moneda: 'USD', cuenta: 'Familia ••7777', comercio: 'ZARA', categoria: 'Ropa', sobre: '' },
    { fila: 12, fecha: '2026-11-13T12:00:00-06:00', tipo: 'Gasto', monto: 12, moneda: 'USD', cuenta: 'Familia ••8888', comercio: 'UBER' },
    { fila: 13, fecha: '2026-11-02T12:00:00-06:00', tipo: 'Gasto', monto: 30000, moneda: 'CRC', cuenta: 'Familia ••8888', comercio: 'SUPER', categoria: 'Supermercado' },   // fuera del viaje
    { fila: 14, fecha: '2026-11-03T12:00:00-06:00', tipo: 'Gasto', monto: 5000, moneda: 'CRC', cuenta: 'Ahorros', comercio: 'FARMACIA', categoria: 'Salud' }
  ]
};
const hoy = new Date(2026, 10, 14, 12);
prueba('esFamilia / familia4', () => {
  assert.ok(C.esFamilia(d.movimientos[1])); assert.ok(!C.esFamilia(d.movimientos[0]));
  assert.strictEqual(C.familia4(d.movimientos[2]), '8888'); assert.strictEqual(C.personaFamilia(d, '7777'), 'Ana');
});
prueba('no tocan el resumen del mes, las cuentas, los sobres ni Me deben', () => {
  const r = C.resumenMes(d, new Date(2026, 10, 1));
  assert.strictEqual(r.gastos.USD, 0); assert.strictEqual(r.gastos.CRC, 55000);
  assert.ok(!r.porCategoria.Supermercado && !r.porCategoria.Ropa);
  d.movimientos.filter(C.esFamilia).forEach(m => assert.strictEqual(C.efectoCuenta(d, m, { principal: 'Ahorros' }), null));
  assert.strictEqual(C.meDeben(d).total.USD, 0);
});
prueba('viaje: entran solas en las fechas, agrupadas por persona y tarjeta', () => {
  const r = C.viaje(d, d.viajes[0], hoy);
  assert.strictEqual(r.compras.length, 3); assert.ok(r.hayFamilia);
  assert.strictEqual(Math.round(r.gastado), 160);
  assert.strictEqual(r.porPersona[''].monto, 100); assert.strictEqual(r.porPersona.Ana.monto, 60);
  assert.deepStrictEqual(Object.keys(r.porPersona.Ana.tarjetas).sort(), ['Familia ••7777', 'Familia ••8888']);
  assert.strictEqual(r.porPersona.Ana.tarjetas['Familia ••7777'].familia, '7777');
});
prueba('viaje que no las incluye (-Familia)', () => {
  const v = Object.assign({}, d.viajes[0], { tarjetas: ['Tarjeta A', C.SIN_FAMILIA] });
  const r = C.viaje(d, v, hoy);
  assert.strictEqual(r.compras.length, 1); assert.ok(!r.hayFamilia);
});
prueba('ligada a mano (+Cat@id) cuenta aunque sea de otra fecha', () => {
  const m = Object.assign({}, d.movimientos[3], { viaje: '+Compras@v1' });
  const r = C.viaje(Object.assign({}, d, { movimientos: d.movimientos.concat([m]) }), d.viajes[0], hoy);
  assert.strictEqual(r.compras.length, 4);
});
prueba('v2.10.8: efectivo que ya tenía (cuenta Efectivo, Efectivo@id): suma al efectivo del viaje, no es gasto ni toca cuentas/sobres', () => {
  const m = { fila: 20, fecha: '2026-11-08T12:00:00-06:00', tipo: 'Gasto', monto: 500, moneda: 'USD', cuenta: 'Efectivo', comercio: 'Efectivo que ya tenía (para el viaje)', viaje: 'Efectivo@v1', sobre: '' };
  const d2 = Object.assign({}, d, { movimientos: d.movimientos.concat([m]) });
  assert.ok(C.efectivoPropioViaje(m));
  assert.strictEqual(C.resumenMes(d2, new Date(2026, 10, 1)).gastos.USD, 0);
  assert.strictEqual(C.efectoCuenta(d2, m, { principal: 'Ahorros' }), null);
  const r = C.viaje(d2, d.viajes[0], hoy);
  assert.strictEqual(r.efectivo.retirado, 500); assert.strictEqual(r.efectivo.queda, 500); assert.strictEqual(Math.round(r.gastado), 160);
});
prueba('v2.10.10: columna con lista que rechaza (Cuenta / tarjeta): pasa a "advertencia" y se escribe Efectivo completo', () => {
  const sctx = { console: { log() {} }, convertirNumero: Number }; vm.createContext(sctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script', 'Hoja.js'), 'utf8'), sctx);
  const regla = (ok, inval) => ({ ok, getAllowInvalid: () => inval, getCriteriaType: () => 'VALUE_IN_LIST', getCriteriaValues: () => [ok], copy() { const me = this; return { setAllowInvalid: (v) => ({ build: () => regla(me.ok, v) }) }; } });
  const celdas = {}, val = {}; const R = 10;
  for (let r = 5; r <= R; r++) val[r + ':2'] = regla(['Ahorros', 'Tarjeta A'], false);
  const h = {
    getLastColumn: () => 3, getMaxRows: () => R,
    getRange: (f, c, nf = 1, nc = 1) => ({
      getFormulas: () => [...Array(nf)].map(() => [...Array(nc)].map(() => '')),
      getValues: () => [...Array(nf)].map((_, i) => [...Array(nc)].map((_, j) => celdas[(f + i) + ':' + (c + j)] || '')),
      getDataValidations: () => [...Array(nf)].map((_, i) => [...Array(nc)].map((_, j) => val[(f + i) + ':' + (c + j)] || null)),
      setDataValidations: (a) => a.forEach((fila, i) => fila.forEach((x, j) => { val[(f + i) + ':' + (c + j)] = x; })),
      setValues: (a) => a[0].forEach((v, j) => { const k = f + ':' + (c + j), rg = val[k]; if (rg && !rg.getAllowInvalid() && rg.ok.indexOf(v) < 0) throw new Error('Los datos que ingresaste en la celda no cumplen las reglas de validación'); }) || a[0].forEach((v, j) => { celdas[f + ':' + (c + j)] = v; })
    })
  };
  sctx.escribirFila_(h, 6, { 'Comercio': 1, 'Cuenta / tarjeta': 2, 'Viaje': 3 }, { 'Comercio': 'Efectivo que ya tenía', 'Cuenta / tarjeta': 'Efectivo', 'Viaje': 'Efectivo@f5' });
  assert.strictEqual(celdas['6:2'], 'Efectivo'); assert.strictEqual(celdas['6:3'], 'Efectivo@f5');
  assert.ok(val['9:2'].getAllowInvalid(), 'toda la columna queda en advertencia'); assert.deepStrictEqual(val['9:2'].ok, ['Ahorros', 'Tarjeta A']);
});
// ---- lector BAC (correo inventado) ----
const ctx = { console }; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script', 'Parser.js'), 'utf8'), ctx);
const bac = (tipo, monto, fecha) => `Notificación de transacción TIENDA DEMO 03-11-2026 - 09:05
Hola PERSONA DEMO
A continuación le detallamos la transacción realizada:
Comercio:        TIENDA DEMO
Ciudad y país:   HEREDIA, Costa Rica
Fecha:           ${fecha || 'Nov 3, 2026, 09:05'}
MASTERCARD:      ************1234
Autorización:    123456
Referencia:      99990000
Tipo de Transacción:   ${tipo}
Monto:           ${monto}
¿Tiene dudas sobre esta transacción?`;
prueba('BAC: compra en colones con miles en formato US', () => {
  const r = ctx.parsearCorreoBanco(bac('COMPRA', 'CRC 249,906.69'), '', new Date(), 'BAC');
  assert.strictEqual(r.length, 1);
  const t = r[0];
  assert.strictEqual(t.comercio, 'TIENDA DEMO'); assert.strictEqual(t.lugar, 'Heredia'); assert.strictEqual(t.monto, 249906.69); assert.strictEqual(t.moneda, 'CRC');
  assert.strictEqual(t.ultimos4, '1234'); assert.strictEqual(t.autorizacion, 'BAC-123456'); assert.strictEqual(t.tipo, 'gasto');
  assert.strictEqual(t.fecha, '2026-11-03T15:05:00.000Z');
});
prueba('BAC: dólares, PM, devolución y rechazada', () => {
  const u = ctx.parsearCorreoBanco(bac('COMPRA', 'USD 25.50', 'Dec 24, 2026, 3:15 PM'), '', new Date(), 'BAC')[0];
  assert.strictEqual(u.moneda, 'USD'); assert.strictEqual(u.monto, 25.5); assert.strictEqual(u.fecha, '2026-12-24T21:15:00.000Z');
  assert.strictEqual(ctx.parsearCorreoBanco(bac('DEVOLUCION', 'USD 10.00'), '', new Date(), 'BAC')[0].tipo, 'ingreso');
  assert.deepStrictEqual(ctx.parsearCorreoBanco(bac('COMPRA DECLINADA', 'USD 10.00'), '', new Date(), 'BAC').length, 0);
});
console.log(`\n${ok} pruebas correctas`);
