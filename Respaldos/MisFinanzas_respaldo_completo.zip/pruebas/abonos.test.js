// Prueba de la pestaña "Abonos tasa cero" con una hoja simulada en memoria.
// Ejecutar: TZ=America/Costa_Rica node pruebas/abonos.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function hojaSim(nombre) {
  const celdas = {}; let maxR = 1000;
  const get = (r, c) => (celdas[r + ',' + c] === undefined ? '' : celdas[r + ',' + c]);
  const sh = {
    nombre,
    getLastRow: () => Math.max(0, ...Object.keys(celdas).filter(k => celdas[k] !== '').map(k => +k.split(',')[0])),
    getLastColumn: () => Math.max(1, ...Object.keys(celdas).filter(k => celdas[k] !== '').map(k => +k.split(',')[1])),
    getMaxRows: () => maxR, insertRowsAfter: (r, n) => { maxR += n; },
    deleteRow: (r) => {
      const n = {}; for (const k of Object.keys(celdas)) { const [rr, cc] = k.split(',').map(Number); if (rr < r) n[k] = celdas[k]; else if (rr > r) n[(rr - 1) + ',' + cc] = celdas[k]; }
      for (const k of Object.keys(celdas)) delete celdas[k]; Object.assign(celdas, n);
    },
    setFrozenRows() {}, setColumnWidth() {},
    getRange(r, c, nr, nc) {
      if (typeof r === 'string') {   // notación A1 (solo para formato): devolvemos un rango que ignora todo
        const m = r.match(/^([A-Z])(\d+)$/);
        if (m) { r = +m[2]; c = m[1].charCodeAt(0) - 64; nr = 1; nc = 1; }
        else return encadenable({});
      }
      nr = nr || 1; nc = nc || 1;
      const rg = {
        getValues: () => Array.from({ length: nr }, (_, i) => Array.from({ length: nc }, (_, j) => get(r + i, c + j))),
        getDisplayValues: () => rg.getValues().map(f => f.map(String)),
        getFormulas: () => Array.from({ length: nr }, () => Array.from({ length: nc }, () => '')),
        setValues: (v) => { v.forEach((f, i) => f.forEach((x, j) => { celdas[(r + i) + ',' + (c + j)] = x; })); return encadenable(rg); },
        setValue: (x) => { celdas[r + ',' + c] = x; return encadenable(rg); }
      };
      return encadenable(rg);
    }
  };
  return sh;
}
function encadenable(o) {
  return new Proxy(o, { get: (t, k) => (k in t ? t[k] : () => encadenable(t)) });
}
const hojas = { 'Tasa Cero': hojaSim('Tasa Cero') };
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const ctx = {
  console, PropertiesService: { getScriptProperties: () => ({ getProperty: () => null }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  SpreadsheetApp: { getActive: () => libro }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);

let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack); process.exitCode = 1; } }

prueba('sin la pestaña, no hay abonos (y no da error)', () => {
  assert.strictEqual(ctx.leerAbonosTC_().length, 0);
});
prueba('el primer abono crea la pestaña con encabezados en la fila 4', () => {
  ctx.guardarAbonoTC_({ fecha: '2026-11-12T18:00:00Z', compra: 'Refrigeradora', tarjeta: 'Visa BCR', monto: 60000, moneda: 'CRC', origen: 'Sobrante de Restaurantes', gasto: true });
  const h = hojas['Abonos tasa cero'];
  assert.ok(h, 'pestaña creada');
  assert.strictEqual(JSON.stringify(h.getRange(4, 1, 1, ctx.COLS_ABONOS.length).getValues()[0]), JSON.stringify(ctx.COLS_ABONOS));
  const l = ctx.leerAbonosTC_();
  assert.strictEqual(l.length, 1); assert.strictEqual(l[0].monto, 60000); assert.strictEqual(l[0].gasto, true);
  assert.strictEqual(l[0].compra, 'Refrigeradora'); assert.strictEqual(l[0].fila, 5);
});
prueba('segundo abono (sin contar como gasto, ligado a un pago), editar y borrar', () => {
  ctx.guardarAbonoTC_({ fecha: '2026-12-01T18:00:00Z', compra: 'Celular', monto: 10000, gasto: false, movimiento: 42 });
  let l = ctx.leerAbonosTC_();
  assert.strictEqual(l.length, 2); assert.strictEqual(l[1].gasto, false); assert.strictEqual(l[1].movimiento, 42);
  ctx.guardarAbonoTC_({ fila: 5, control: { monto: 60000 }, fecha: '2026-11-12T18:00:00Z', compra: 'Refrigeradora', monto: 70000 });
  assert.strictEqual(ctx.leerAbonosTC_()[0].monto, 70000);
  assert.throws(() => ctx.eliminarAbonoTC_(5, { monto: 1 }), /cambió/);
  ctx.eliminarAbonoTC_(5, { monto: 70000 });
  l = ctx.leerAbonosTC_();
  assert.strictEqual(l.length, 1); assert.strictEqual(l[0].compra, 'Celular');
});
prueba('montos inválidos se rechazan', () => {
  assert.throws(() => ctx.guardarAbonoTC_({ fecha: '2026-11-12', compra: 'X', monto: 0 }), /mayor que cero/);
});
console.log(`\n${ok} pruebas correctas`);
