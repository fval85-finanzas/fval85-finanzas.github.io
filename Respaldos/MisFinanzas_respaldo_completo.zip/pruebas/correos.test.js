// Pruebas con el FORMATO REAL de los correos (datos personales cambiados).
// Ejecutar: TZ=America/Costa_Rica node pruebas/correos.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = { console };
vm.createContext(ctx);
for (const f of ['Parser.js', 'ParserPrestamo.js']) vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script', f), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 3).join('\n   ')); process.exitCode = 1; } }
const cerca = (a, b, m) => assert.ok(Math.abs(a - b) < 0.01, `${m}: ${a} ≠ ${b}`);
const J = (x) => JSON.parse(JSON.stringify(x));   // objetos del contexto → objetos normales

// ---------- BCR Tarjetas ----------
const bcrTexto = `Notificación de Transacciones BCR
Transacciones en su tarjeta BCR: ****-****-****-9125
Estimado (a) cliente:
Le informamos la siguiente transacción realizada con su tarjeta BCR :
Detalle de Transacciones
Fecha
Autorización
No.Referencia
Monto
Moneda
Comercio
Estado
29/10/2026 17:31:34
00102853
83716366
12,000.00
COLON COSTA RICA
TIENDA DE MASCOTAS SAN ALAJUELA CRI
Aprobada
En caso de dudas respecto a las transacciones notificadas, escribir al WhatsApp 2211-1135`;
const bcrHtml = `<p>Transacciones en su tarjeta BCR: ****-****-****-9125</p><table><tr><td><b>Detalle de Transacciones</b></td></tr>
<tr><th>Fecha</th><th>Autorizaci&oacute;n</th><th>No.Referencia</th><th>Monto</th><th>Moneda</th><th>Comercio</th><th>Estado</th></tr>
<tr><td>29/10/2026 17:31:34</td><td>00102853</td><td>83716366</td><td>12,000.00</td><td>COLON COSTA RICA</td><td>TIENDA DE MASCOTAS SAN ALAJUELA CRI</td><td>Aprobada</td></tr>
<tr><td>29/10/2026 18:02:10</td><td>00102999</td><td>83716400</td><td>5,500.50</td><td>COLON COSTA RICA</td><td>AUTOMERCADO LOS YOSES  SAN JOSE      CRI</td><td>Aprobada</td></tr>
<tr><td>29/10/2026 18:05:00</td><td>00103000</td><td>83716401</td><td>99,000.00</td><td>COLON COSTA RICA</td><td>TIENDA X SAN JOSE CRI</td><td>Rechazada</td></tr></table>`;

prueba('BCR (texto plano): compra de ₡12.000 en Alajuela, tarjeta 9125', () => {
  const r = J(ctx.parsearCorreoBanco(bcrTexto, '', new Date('2026-10-29T23:31:40Z'), 'BCR'));
  assert.strictEqual(r.length, 1);
  const t = r[0];
  assert.strictEqual(t.monto, 12000); assert.strictEqual(t.moneda, 'CRC'); assert.strictEqual(t.ultimos4, '9125');
  assert.strictEqual(t.autorizacion, '00102853'); assert.strictEqual(t.comercio, 'TIENDA DE MASCOTAS SAN'); assert.strictEqual(t.lugar, 'Alajuela');
  assert.strictEqual(t.fecha, '2026-10-29T23:31:00.000Z');
});
prueba('BCR (tabla HTML): varias compras, la rechazada no se anota', () => {
  const r = J(ctx.parsearCorreoBanco('Notificación de Transacciones BCR', bcrHtml, new Date(), 'BCR'));
  assert.strictEqual(r.length, 2);
  assert.strictEqual(r[1].comercio, 'AUTOMERCADO LOS YOSES'); assert.strictEqual(r[1].lugar, 'San Jose');
  cerca(r[1].monto, 5500.5, 'monto'); assert.strictEqual(r[0].ultimos4, '9125');
});

// ---------- SINPE ----------
const sinpeEnviado = `Transacción SINPE MÓVIL
Estimado (a): PEREZ MORA JUAN
Le informamos que se le ha debitado de su cuenta BCR la siguiente transacción SINPE Móvil:
Número de referencia: 2026102915284002284863020
Teléfono Destino: 88887777
Nombre cliente Destino: ANA MARIA SOLIS VEGA
Entidad Destino: Banco de Costa Rica
Monto: 10,000.00
Motivo: CLAUDE*********
Esta transacción fue realizada el 29/10/2026 a las 4:53 PM`;
const sinpeRecibido = `Transacción SINPE MÓVIL
Estimado (a): JUAN PEREZ MORA
Le informamos que se le ha acreditado en su cuenta BCR la siguiente transacción SINPE Móvil:
Número de referencia: 2026102610283002574674294
Teléfono origen: 0
Nombre cliente origen: CARLOS_ANDRES_ROJAS
Entidad origen: Banco BAC San José
Monto: 20,700.00
Motivo: IPTV_3_1_______
Esta transacción fue realizada el 26/10/2026 a las 8:13 PM`;
prueba('SINPE enviado a otra persona → Gasto', () => {
  const t = J(ctx.parsearSINPE(sinpeEnviado));
  assert.strictEqual(t.tipoMov, 'Gasto'); assert.strictEqual(t.monto, 10000); assert.strictEqual(t.comercio, 'SINPE a ANA MARIA SOLIS VEGA');
  assert.strictEqual(t.autorizacion, '2026102915284002284863020'); assert.strictEqual(t.fecha, '2026-10-29T22:53:00.000Z');
  assert.match(t.nota, /Motivo: CLAUDE/); assert.match(t.nota, /Tel 88887777/);
});
prueba('SINPE recibido → Ingreso (guiones bajos fuera)', () => {
  const t = J(ctx.parsearSINPE(sinpeRecibido));
  assert.strictEqual(t.tipoMov, 'Ingreso'); assert.strictEqual(t.comercio, 'SINPE de CARLOS ANDRES ROJAS');
  cerca(t.monto, 20700, 'monto'); assert.strictEqual(t.nota.indexOf('Tel'), -1, 'teléfono 0 no se anota'); assert.match(t.nota, /Motivo: IPTV 3 1/);
});
prueba('SINPE a mi propio nombre (en otro orden) → Transferencia; a un pariente → Gasto', () => {
  const propia = sinpeEnviado.replace('ANA MARIA SOLIS VEGA', 'JUAN PEREZ MORA');
  assert.strictEqual(ctx.parsearSINPE(propia).tipoMov, 'Transferencia');
  const pariente = sinpeEnviado.replace('ANA MARIA SOLIS VEGA', 'LUCIA PEREZ MORA');
  assert.strictEqual(ctx.parsearSINPE(pariente).tipoMov, 'Gasto');
});

// ---------- Davibank ----------
const dvCompra = `Estimado cliente,
&nbsp
DAVIbank le notifica que la transacción realizada en AVIANCA.COM MC -I- PANAM Panamá, el día 08/09/2026 a las 08:14 AM con su tarjeta de crédito titular MC
terminada en 9615 con número de autorización 889833 y referencia 90677527 por USD 918.78, fue aprobada. La compra se facturará en dólares estadounidenses(USD)`;
const dvServicio = `DAVIbank le notifica que nuestro cliente PEREZ MORA, JUAN, ha realizado un pago de servicios con las
siguientes características:
TELECABLE SA - CABLE E INTERNET
 Nombre                         Identificador Fecha Vito. Monto
 Perez Mora Juan 3638808           10/10/2026 ₡ 32,978.54
Por su seguridad:`;
prueba('Davibank compra en dólares: Avianca, $918,78, tarjeta 9615', () => {
  const r = J(ctx.parsearCorreoBanco('Alerta Transacción Tarjeta de Crédito Titular\n' + dvCompra, '', new Date(), 'Davibank'));
  assert.strictEqual(r.length, 1); const t = r[0];
  assert.strictEqual(t.moneda, 'USD'); cerca(t.monto, 918.78, 'monto'); assert.strictEqual(t.ultimos4, '9615');
  assert.strictEqual(t.autorizacion, '889833'); assert.strictEqual(t.comercio, 'AVIANCA.COM MC -I- PANAM'); assert.strictEqual(t.lugar, 'Panamá');
  assert.strictEqual(t.fecha, '2026-09-08T14:14:00.000Z');
});
prueba('Davibank pago de servicio: Telecable ₡32.978,54, categoría Servicios, clave estable', () => {
  const r = J(ctx.parsearCorreoBanco('Pago de Servicio\n' + dvServicio, '', new Date('2026-10-10T17:05:00Z'), 'Davibank'));
  const t = r[0];
  assert.strictEqual(t.comercio, 'TELECABLE SA - CABLE E INTERNET'); cerca(t.monto, 32978.54, 'monto'); assert.strictEqual(t.moneda, 'CRC');
  assert.strictEqual(t.categoria, 'Servicios'); assert.strictEqual(t.esServicio, true);
  const r2 = J(ctx.parsearCorreoBanco('Pago de Servicio\n' + dvServicio, '', new Date('2026-10-10T19:00:00Z'), 'Davibank'));
  assert.strictEqual(r2[0].autorizacion, t.autorizacion, 'el correo repetido da la misma clave');
});
prueba('Davibank transacción rechazada → nada que anotar', () => {
  const r = J(ctx.parsearCorreoBanco(dvCompra.replace('fue aprobada', 'fue rechazada'), '', new Date(), 'Davibank'));
  assert.strictEqual(r.length, 0);
});

// ---------- Préstamo ----------
const recibo = fs.readFileSync(path.join(__dirname, 'muestras', 'RECIBOPAGOPRESTAMO.TXT'), 'utf8');
const estado = fs.readFileSync(path.join(__dirname, 'muestras', 'ESTADO_CUENTA_PRESTAMO.TXT'), 'utf8');
prueba('recibo del préstamo: capital, intereses, 4 pólizas, saldo y tasa', () => {
  const p = J(ctx.parsearComprobantePrestamo(recibo, null));
  assert.strictEqual(p.comprobante, '10184152'); assert.strictEqual(p.cuota, 184);
  cerca(p.principal, 77725.80, 'capital'); cerca(p.intereses, 125883.30, 'intereses'); cerca(p.polizas, 62766.33, 'pólizas');
  cerca(p.total, 266375.43, 'total'); cerca(p.principal + p.intereses + p.polizas, p.total, 'suma = total');
  cerca(p.saldoNuevo, 22775527.29, 'saldo'); cerca(p.tasa, 0.0661, 'tasa'); assert.strictEqual(p.cuotasPendientes, 176);
  assert.strictEqual(p.fecha.slice(0, 16), '2026-09-26T16:18'); assert.strictEqual(p.proximoVenc.slice(0, 10), '2026-11-07');
});
prueba('estado de cuenta mensual se reconoce (no se anota)', () => {
  assert.strictEqual(ctx.esEstadoCuentaPrestamo(estado), true);
  assert.strictEqual(ctx.esEstadoCuentaPrestamo(recibo), false);
  assert.strictEqual(ctx.parsearComprobantePrestamo(estado, null), null, 'el lector general tampoco lo toma como pago');
});

// ---------- BCR SAFI ----------
const safiInv = `Estimado inversionista JUAN PEREZ MORA
BCR SAFI le informa que realizó una inversión en el fondo BCR Mixto Colones ,
con el número de orden 574434 por un monto de ¢43,508.00 por medio de la aplicación de BCR SAFI.
Misma que quedará en firme el día 22/09/2026 .`;
const safiRet = `Estimado inversionista JUAN PEREZ MORA
BCR SAFI le informa que realizó un retiro del fondo BCR Mixto Colones
con el número de retiro 306286 por un monto de ¢50,575.00 por medio de la aplicación de BCR SAFI.
Misma que será acreditada en la cuenta seleccionada el día 04/09/2026.`;
prueba('SAFI: solicitud de inversión', () => {
  const t = J(ctx.parsearSAFI(safiInv, new Date('2026-09-22T20:13:00Z')));
  assert.strictEqual(t.tipoMov, 'Inversión'); cerca(t.monto, 43508, 'monto'); assert.strictEqual(t.moneda, 'CRC');
  assert.strictEqual(t.autorizacion, 'SAFI-I-574434'); assert.strictEqual(t.fondo, 'BCR Mixto Colones'); assert.strictEqual(t.fecha, '2026-09-22T20:13:00.000Z');
});
prueba('SAFI: solicitud de retiro (fecha de acreditación)', () => {
  const t = J(ctx.parsearSAFI(safiRet, new Date('2026-09-03T19:50:00Z')));
  assert.strictEqual(t.tipoMov, 'Retiro de fondo'); cerca(t.monto, 50575, 'monto'); assert.strictEqual(t.autorizacion, 'SAFI-R-306286');
  assert.strictEqual(t.fecha.slice(0, 10), '2026-09-04');
});
prueba('SINPE: sin el asterisco final del banco', () => {
  const t = J(ctx.parsearSINPE(sinpeEnviado.replace('ANA MARIA SOLIS VEGA', 'Castro Varela Marvin *')));
  assert.strictEqual(t.comercio, 'SINPE a Castro Varela Marvin');
});
prueba('v2.9.0: BCR en dólares escrito "US DOLLAR" (texto y HTML) → USD', () => {
  const tx = bcrTexto.replace('12,000.00', '13.99').replace('COLON COSTA RICA', 'US DOLLAR').replace('TIENDA DE MASCOTAS SAN ALAJUELA CRI', 'SERVICIO STREAMING USA');
  const r = J(ctx.parsearCorreoBanco(tx, '', new Date('2026-10-29T23:31:40Z'), 'BCR'));
  assert.strictEqual(r.length, 1); assert.strictEqual(r[0].monto, 13.99); assert.strictEqual(r[0].moneda, 'USD');
  const h = bcrHtml.replace('12,000.00</td><td>COLON COSTA RICA', '13.99</td><td>US DOLLAR');
  const r2 = J(ctx.parsearCorreoBanco('', h, new Date('2026-10-29T23:31:40Z'), 'BCR'));
  assert.strictEqual(r2[0].moneda, 'USD'); assert.strictEqual(r2[0].monto, 13.99); assert.strictEqual(r2[1].moneda, 'CRC');
  assert.strictEqual(ctx.identificarMoneda('US DOLLAR'), 'USD'); assert.strictEqual(ctx.identificarMoneda('COLON COSTA RICA'), 'CRC');
});
console.log(`\n${ok} pruebas correctas`);
