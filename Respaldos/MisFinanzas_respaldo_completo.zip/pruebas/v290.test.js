// v2.9.0: pagos próximos (avisos), tarjetas desconocidas, correo del resumen.  TZ=America/Costa_Rica node pruebas/v290.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const C = require('../web/js/calculos.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const hoy = new Date(2026, 10, 4);   // miércoles 4 nov
const d = {
  cuentas: [
    { fila: 2, nombre: 'Tarjeta A', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, diaCorte: 20, diaPago: 6, saldoCRC: 300000, fechaSaldo: '2026-10-30T12:00:00-06:00', ultimos4: '1111' },
    { fila: 3, nombre: 'Tarjeta B', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, diaCorte: 18, diaPago: 5, saldoCRC: 30000, saldoUSD: 0, fechaSaldo: '2026-10-30T12:00:00-06:00', ultimos4: '2222' },
    { fila: 4, nombre: 'Tarjeta C', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, diaCorte: 1, diaPago: 16, saldoCRC: -78000, fechaSaldo: '2026-10-30T12:00:00-06:00', ultimos4: '3333' },
    { fila: 5, nombre: 'Tarjeta D', tipo: 'Tarjeta de crédito', moneda: 'CRC', activa: true, diaCorte: 25, diaPago: 7, saldoCRC: 5000, fechaSaldo: '2026-10-30T12:00:00-06:00' },
    { fila: 6, nombre: 'Ahorros', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true, saldoCRC: 100000, fechaSaldo: '2026-11-01T12:00:00-06:00' }
  ],
  movimientos: [
    { fila: 10, fecha: '2026-11-02T10:00:00-06:00', tipo: 'Gasto', monto: 104, moneda: 'USD', cuenta: 'Tarjeta B', comercio: 'Compra' },
    { fila: 11, fecha: '2026-11-03T10:00:00-06:00', tipo: 'Pago de tarjeta', monto: 5000, moneda: 'CRC', cuenta: 'Tarjeta D' },
    { fila: 12, fecha: '2026-11-04T11:59:00-06:00', tipo: 'Gasto', monto: 6000, moneda: 'CRC', cuenta: '', comercio: 'CAFETERIA', nota: 'Tarjeta ••4444 no está en Cuentas' }
  ],
  sobres: [{ fila: 2, nombre: 'Ventas', moneda: 'CRC', tipo: 'Variable', saldoInicial: 1000 }], sobresMov: [], sobresDesde: '2026-10-01T00:00:00-06:00'
};
prueba('pagos de la semana con monto, ordenados; avisar solo 3, 1 y el día', () => {
  const p = C.pagosProximos(d, hoy, [3, 1, 0], 7);
  assert.deepStrictEqual(p.map(x => x.nombre + ':' + x.dias), ['Tarjeta B:1', 'Tarjeta A:2', 'Tarjeta D:3']);
  const b = p[0], a = p[1];
  assert.strictEqual(b.avisar, true); assert.strictEqual(b.CRC, 30000);
  assert.strictEqual(b.USD, 0, 'la compra en $ es después del corte: va al siguiente estado'); assert.strictEqual(b.deuda.USD, 104);
  assert.strictEqual(a.avisar, false, 'a 2 días no avisa con [3,1,0]');
  assert.strictEqual(C.pagosProximos(d, hoy, [2, 0], 7)[1].avisar, true);
});
prueba('no avisa si ya pagaste (no queda nada por pagar)', () => {
  const dd = C.pagosProximos(d, hoy, [3, 1, 0], 7).find(x => x.nombre === 'Tarjeta D');
  assert.strictEqual(dd.pagado, true); assert.strictEqual(dd.avisar, false);
});
prueba('pago parcial: si queda saldo del estado de cuenta, sigue avisando', () => {
  const d3 = JSON.parse(JSON.stringify(d)); d3.movimientos.push({ fila: 20, fecha: '2026-11-04T09:00:00-06:00', tipo: 'Pago de tarjeta', monto: 10000, moneda: 'CRC', cuenta: 'Tarjeta B' });
  const b = C.pagosProximos(d3, hoy, [3, 1, 0], 7)[0];
  assert.strictEqual(b.CRC, 20000); assert.strictEqual(b.avisar, true); assert.strictEqual(b.pagado, false);
});
prueba('a favor: aparece en la ventana pero no avisa', () => {
  const p = C.pagosProximos(d, new Date(2026, 10, 13), [3, 1, 0], 7).find(x => x.nombre === 'Tarjeta C');
  assert.strictEqual(p.dias, 3); assert.strictEqual(p.debe, false); assert.strictEqual(p.avisar, false); assert.strictEqual(p.CRC, -78000);
});
prueba('tarjeta desconocida: se detecta por la nota y no toca la cuenta principal ni pide sobre', () => {
  const m = d.movimientos[2];
  assert.strictEqual(C.tarjetaDesconocida(d, m), '4444');
  const o = C.origenes(d, { principal: 'Ahorros' });
  assert.ok(!C.efectosCuentas(d, o).some(e => e.mov === m));
  const sb = C.saldosSobres(d, new Date(2026, 10, 1), hoy, o);
  assert.ok(!sb.pendientes.some(x => x.mov === m));
  // si después se agrega la tarjeta a Cuentas, ya no es desconocida
  const d2 = Object.assign({}, d, { cuentas: d.cuentas.concat([{ fila: 9, nombre: 'Débito X', tipo: 'Cuenta de ahorro', ultimos4: '4444', activa: true }]) });
  assert.strictEqual(C.tarjetaDesconocida(d2, m), '');
  assert.strictEqual(C.tarjetaDesconocida(d, Object.assign({}, m, { cuenta: 'Ahorros' })), '');
});
prueba('servidor: formato de montos del correo', () => {
  const ctx = { console: { log() {} } }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
  assert.strictEqual(ctx.dinCorreo_(311977.8, 'CRC'), '₡311.977,80');
  assert.strictEqual(ctx.dinCorreo_(30465, 'CRC'), '₡30.465');
  assert.strictEqual(ctx.dinCorreo_(104, 'USD'), '$104,00');
  assert.strictEqual(ctx.dinCorreo_(-78424.87, 'CRC'), '₡78.424,87');
  assert.strictEqual(typeof ctx.Calc.pagosProximos, 'function');
});
console.log(`\n${ok} pruebas correctas`);
