// v2.13.0: categorías, reglas y tasa cero desde la app (#58), familia pausada y ajenas sin ignorar (#57).  TZ=America/Costa_Rica node pruebas/v2130.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
function tabla(nombre, filaEnc, enc, filas) { const h = hojaSim(nombre); h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]); filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f])); return h; }
const F = (d) => new Date(d + 'T12:00:00-06:00');
const hojas = {
  'Config': tabla('Config', 4, ['Banco', 'Correo de notificaciones', 'Estado', 'Categorías'], [['BCR', 'bcr@ejemplo.com', 'Activo', 'Supermercado'], ['', '', '', 'Mascotas'], ['', '', '', 'Salud']]),
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'], [
    [F('2026-10-01'), 'VETERINARIA', '', 10000, 'CRC', 'Gasto', 'Tarjeta A', 'Mascotas', '', 'Correo', 'a1', ''],
    [F('2026-10-02'), 'TV DEMO', '', 120000, 'CRC', 'Compra tasa cero', 'Tarjeta A', 'Compras', 'TASA CERO', 'Correo', 'a2', ''],
    [F('2026-10-15'), 'Cuota TV DEMO · 1 de 6', '', 20000, 'CRC', 'Cuota tasa cero', 'Tarjeta A', '', '', 'Manual', 'TC-8-1', ''],
    [F('2026-10-20'), 'PET SHOP', '', 5000, 'CRC', 'Gasto', 'Tarjeta A', 'Mascotas', '', 'Correo', 'a3', '']]),
  'Reglas': tabla('Reglas', 4, ['Si el comercio contiene', 'Categoría', 'Sobre'], [['VETERINARIA', 'Mascotas', ''], ['UBER', 'Transporte', '']]),
  'Tasa Cero': tabla('Tasa Cero', 6, ['Descripción', 'Tarjeta', 'Fecha de compra', 'Monto total', 'Moneda', 'Meses', 'Primera cuota'], [['OTRA', 'Tarjeta A', F('2026-09-01'), 60000, 'CRC', 3, F('2026-10-02')], ['TV DEMO', 'Tarjeta A', F('2026-10-02'), 120000, 'CRC', 6, F('2026-11-02')]]),
  'Abonos tasa cero': tabla('Abonos tasa cero', 4, ['Fecha', 'Compra', 'Tarjeta', 'Monto', 'Moneda', 'De dónde salió', 'Contar como gasto', 'Movimiento', 'Nota'], [[F('2026-10-25'), 'TV DEMO', 'Tarjeta A', 10000, 'CRC', 'Ahorros', 'No', '', '']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = {};
const ctx = { console: { log() {} }, SpreadsheetApp: { getActive: () => libro, flush() {} },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock: () => true, releaseLock() {} }) } };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 14).join('\n   ')); process.exitCode = 1; } }
const filas = (n, enc) => JSON.parse(JSON.stringify(ctx.leerTabla_(n, enc).filas));
prueba('categorías: agregar y quitar (sin repetidas)', () => {
  assert.strictEqual(ctx.guardarCategorias_(['Supermercado', 'Mascotas', 'Salud', 'Viajes', 'salud']), 4);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(ctx.listaConfig_('Categorías'))), ['Supermercado', 'Mascotas', 'Salud', 'Viajes']);
  ctx.guardarCategorias_(['Supermercado', 'Mascotas', 'Viajes']);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(ctx.listaConfig_('Categorías'))), ['Supermercado', 'Mascotas', 'Viajes']);
  assert.strictEqual(hojas.Config.getRange(1, 1, 1, 1).getValues()[0][0], '', 'no toca otras columnas');
  assert.strictEqual(hojas.Config.getRange(5, 1, 1, 1).getValues()[0][0], 'BCR');
});
prueba('renombrar categoría moviendo movimientos y reglas', () => {
  const r = ctx.renombrarCategoria_('Mascotas', 'Perros', true);
  assert.strictEqual(r.movimientos, 2); assert.strictEqual(r.reglas, 1);
  assert.ok(ctx.listaConfig_('Categorías').indexOf('Perros') >= 0 && ctx.listaConfig_('Categorías').indexOf('Mascotas') < 0);
  assert.ok(filas('Movimientos', 'Fecha').filter(m => m['Categoría'] === 'Perros').length === 2);
  assert.strictEqual(filas('Reglas', 'Si el comercio contiene')[0]['Categoría'], 'Perros');
  const r2 = ctx.renombrarCategoria_('Perros', 'Mascotas', false);
  assert.strictEqual(r2.movimientos, 0); assert.strictEqual(filas('Movimientos', 'Fecha')[0]['Categoría'], 'Perros', 'sin mover, los viejos quedan');
});
prueba('reglas: guardar nueva, editar (con control) y borrar', () => {
  ctx.API.guardarRegla('netflix', 'Suscripciones', '');
  let rs = filas('Reglas', 'Si el comercio contiene'); assert.strictEqual(rs.length, 3); assert.strictEqual(rs[2]['Si el comercio contiene'], 'NETFLIX');
  ctx.editarRegla_(6, { patron: 'uber trip', categoria: 'Transporte', sobre: 'SOBRE GASOLINA' }, 'UBER');
  rs = filas('Reglas', 'Si el comercio contiene'); assert.strictEqual(rs[1]['Si el comercio contiene'], 'UBER TRIP'); assert.strictEqual(rs[1]['Sobre'], 'SOBRE GASOLINA');
  assert.throws(() => ctx.editarRegla_(6, { patron: 'X', categoria: 'Y' }, 'UBER'), /cambió/);
  ctx.eliminarRegla_(5, 'VETERINARIA');
  rs = filas('Reglas', 'Si el comercio contiene'); assert.deepStrictEqual(rs.map(r => r['Si el comercio contiene']), ['UBER TRIP', 'NETFLIX']);
  const D = JSON.parse(ctx.obtenerDatos_ ? '{}' : '{}');
});
prueba('tasa cero: editar cambiando tarjeta mueve compra, cuotas y abonos', () => {
  const r = ctx.editarTasaCero_(8, { descripcion: 'TV DEMO 55', tarjeta: 'Tarjeta B', monto: 120000, meses: 6, primeraCuota: '2026-11-02T18:00:00.000Z' }, { descripcion: 'TV DEMO', tarjeta: 'Tarjeta A' });
  assert.deepStrictEqual(JSON.parse(JSON.stringify(r)), { compra: 1, abonos: 1, cuotas: 1 });
  const ms = filas('Movimientos', 'Fecha');
  assert.strictEqual(ms[1]['Cuenta / tarjeta'], 'Tarjeta B'); assert.strictEqual(ms[2]['Cuenta / tarjeta'], 'Tarjeta B'); assert.strictEqual(ms[2]['Comercio / descripción'], 'Cuota TV DEMO 55 · 1 de 6');
  assert.strictEqual(ms[0]['Cuenta / tarjeta'], 'Tarjeta A', 'lo demás no se toca');
  const z = filas('Tasa Cero', 'Descripción'); assert.strictEqual(z[1]['Descripción'], 'TV DEMO 55'); assert.strictEqual(z[1]['Tarjeta'], 'Tarjeta B');
  const ab = filas('Abonos tasa cero', 'Fecha'); assert.strictEqual(ab[0]['Compra'], 'TV DEMO 55'); assert.strictEqual(ab[0]['Tarjeta'], 'Tarjeta B');
});
prueba('tasa cero: quitar → gasto normal, borra cuotas y abonos, la fila queda "Quitada" (no se corre)', () => {
  const r = ctx.quitarTasaCero_(8, { descripcion: 'TV DEMO 55', tarjeta: 'Tarjeta B' });
  assert.deepStrictEqual(JSON.parse(JSON.stringify(r)), { compra: 1, abonos: 1, cuotas: 1 });
  const ms = filas('Movimientos', 'Fecha');
  assert.strictEqual(ms.length, 3); assert.strictEqual(ms[1]['Tipo'], 'Gasto'); assert.strictEqual(ms[1]['Sobre'], '');
  const z = filas('Tasa Cero', 'Descripción'); assert.strictEqual(z.length, 2); assert.strictEqual(z[1]['Estado'], 'Quitada'); assert.strictEqual(z[1]._fila, 8);
  assert.strictEqual(filas('Abonos tasa cero', 'Fecha').length, 0);
});
console.log(`\n${ok} pruebas correctas`);
