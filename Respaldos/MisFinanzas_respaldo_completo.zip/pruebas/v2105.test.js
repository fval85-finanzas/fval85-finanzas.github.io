// v2.10.4–2.10.5: listas de tiendas (personas, campos, pagado) y encargos (encargantes, terminar los conserva).  node pruebas/v2105.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path'); const vm = require('vm'); const crypto = require('crypto');
const { hojaSim } = require('./hoja-simulada');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const hojas = {}, props = {}, cache = {}; let uid = 0;
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'F' };
const ctx = { console: { log() {} }, SpreadsheetApp: { getActive: () => libro }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {}, tryLock: () => true }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
  CacheService: { getScriptCache: () => ({ get: (k) => cache[k] || null, put: (k, v) => { cache[k] = v; }, remove: (k) => { delete cache[k]; } }) },
  Utilities: { getUuid: () => crypto.randomUUID() } };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let l;
prueba('crear lista de tiendas con personas y campos', () => {
  l = ctx.crearLista_('Viaje', '🛍', [{ n: 'Tenis', p: 'Calzado', para: 'Fernando', talla: '9', color: 'Negro', max: 90, tienda: 'Albrook' }], { tipo: 'tiendas', personas: ['Fernando', ' Ana ', ''] });
  assert.strictEqual(l.tipo, 'tiendas'); assert.deepStrictEqual(l.personas, ['Fernando', 'Ana']);
  const t = l.items[0]; assert.strictEqual(t.talla, '9'); assert.strictEqual(t.max, 90); assert.strictEqual(t.para, 'Fernando'); assert.strictEqual(t.tienda, 'Albrook');
});
prueba('pagado marca como comprado; desmarcar borra lo pagado', () => {
  const id = l.items[0].id;
  l = ctx.cambiarLista_(l.id, { t: 'pagado', item: id, monto: 85.5, medio: 'Visa' }, 'Ana');
  assert.strictEqual(l.items[0].on, true); assert.strictEqual(l.items[0].pagado, 85.5); assert.strictEqual(l.items[0].medio, 'Visa');
  l = ctx.cambiarLista_(l.id, { t: 'marcar', item: id, on: false }, 'Ana');
  assert.strictEqual(l.items[0].pagado, '');
});
prueba('encargos: encargante con adelanto, renombrar, y terminar no los borra', () => {
  l = ctx.cambiarLista_(l.id, { t: 'encargante', datos: { n: 'Tía', adelanto: 80, moneda: 'USD' } }, 'F');
  l = ctx.cambiarLista_(l.id, { t: 'agregar', datos: { n: 'Perfume', p: 'Perfumería y belleza', enc: 'Tía' } }, 'F');
  const pid = l.items.find(x => x.enc).id;
  l = ctx.cambiarLista_(l.id, { t: 'pagado', item: pid, monto: 65 }, 'F');
  l = ctx.cambiarLista_(l.id, { t: 'encargante', antes: 'Tía', datos: { n: 'Tía Marta', adelanto: 80, moneda: 'USD', estado: 'entregado' } }, 'F');
  assert.strictEqual(l.encargantes[0].n, 'Tía Marta'); assert.strictEqual(l.encargantes[0].estado, 'entregado'); assert.strictEqual(l.items.find(x => x.id === pid).enc, 'Tía Marta');
  l = ctx.cambiarLista_(l.id, { t: 'terminar', pendientes: 'borrar' }, 'F');
  const p = l.items.find(x => x.id === pid);
  assert.ok(p && p.on && p.pagado === 65, 'el encargo se queda comprado y con su precio');
  assert.ok(!l.items.some(x => x.n === 'Tenis'), 'lo propio pendiente se borró');
  l = ctx.cambiarLista_(l.id, { t: 'quitarEncargante', n: 'Tía Marta' }, 'F');
  assert.strictEqual(l.encargantes.length, 0); assert.ok(!l.items.some(x => x.enc));
});
prueba('lista de super sigue igual', () => { const s = ctx.crearLista_('Super', '🛒', [{ n: 'Arroz', p: 'Granos y abarrotes' }]); assert.strictEqual(s.tipo, 'super'); assert.strictEqual(s.items[0].p, 'Granos y abarrotes'); });
console.log(`\n${ok} pruebas correctas`);
