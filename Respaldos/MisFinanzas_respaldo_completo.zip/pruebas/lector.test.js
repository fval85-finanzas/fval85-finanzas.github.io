// v2.3: lector de comprobantes en foto y de informes de BCR SAFI (datos inventados).  node pruebas/lector.test.js
const assert = require('assert');
const L = require('../web/js/lector.js');
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 3).join('\n   ')); process.exitCode = 1; } }
const cuentas = [{ nombre: 'Visa X', tipo: 'Tarjeta de crédito', ultimos4: '4321', activa: true }, { nombre: 'Ahorros', tipo: 'Cuenta de ahorro', moneda: 'CRC', activa: true }];
prueba('comprobante BCR de pago de tarjeta (el ₡ se lee como "d")', () => {
  const r = L.leerComprobante('5 de marzo, 2026\ne 09:05\nComprobante\nPago de tarjeta\nDocumento 01234567\nCuenta origen AH CR11000000000000001234\nPERSONA EJEMPLO\nTarjeta 4000 00** **** 4321\nMonto debitado d25.500,50\nMonto pagado d+25.500,50', cuentas);
  assert.strictEqual(r.tipo, 'Pago de tarjeta'); assert.strictEqual(r.monto, 25500.5); assert.strictEqual(r.cuenta, 'Visa X');
  assert.strictEqual(r.documento, '01234567'); assert.strictEqual(r.fecha.getMonth(), 2); assert.strictEqual(r.fecha.getHours(), 9);
});
prueba('números: formatos de Costa Rica y de EE. UU.', () => {
  assert.strictEqual(L.numero('₡1.234.567,89'), 1234567.89); assert.strictEqual(L.numero('1,234,567.89'), 1234567.89); assert.strictEqual(L.numero('$ 12.50'), 12.5);
});
prueba('informe de BCR SAFI: saldo final por subcuenta (fila partida en dos renglones)', () => {
  const lineas = ['Cliente PERSONA Código 111 - 0', 'SubCuenta PERSONA Custodio BCR CUSTODIO', 'BCR Mixto Colones - No diversificado', 'Período comprendido del 01/03/2026 al 31/03/2026',
    'Saldo Final', 'Valor', 'Fecha Serie Participaciones Principal Rendimientos Saldo Final', 'Participación', '31/03/2026 A 2.0475 59,844.11 100,000.00 442.61 100,442.61',
    'Cliente PERSONA Código 111 - 2', 'SubCuenta VIAJE A JAPON Custodio BCR CUSTODIO', 'BCR Mixto Colones - No diversificado',
    'Saldo Final', 'Valor', 'Fecha Serie Participaciones Principal Rendimientos Saldo Final', 'Participación', '31/03/2026', 'A 2.0475 1,000.00 2,000.00 10.50 2,010.50',
    'Cliente PERSONA Código 111 - 3', 'SubCuenta OTRA COSA Custodio BCR CUSTODIO', 'BCR Mixto Dólares - No diversificado', 'Saldo Final', '31/03/2026 A 1.1 10.00 20.00 1.00 21.00'];
  const e = L.leerEstadoFondos(lineas, [{ nombre: 'Principal', saldo: 1 }, { nombre: 'Viaje a Japón', saldo: 1 }]);
  assert.ok(e.safi); assert.strictEqual(e.corte.getDate(), 31);
  assert.deepStrictEqual(e.subcuentas.map(s => s.propuesto), [100442.61, 2010.5]);
  assert.strictEqual(e.subcuentas[1].safi.rendimientos, 10.5);
  assert.strictEqual(e.sobran.length, 1); assert.strictEqual(e.sobran[0].nombre, 'OTRA COSA'); assert.strictEqual(e.sobran[0].fondo, 'BCR Mixto Dólares');
});
prueba('monto: el ₡ en negrita leído como "d1" no se cuela', () => {
  const r = L.leerComprobante('Pago de tarjeta\nMonto debitado d12.000,00\nMonto pagado d112.000,00', cuentas);
  assert.strictEqual(r.monto, 12000); assert.ok(!r.montoDudoso);
  const r2 = L.leerComprobante('Pago de tarjeta\nMonto debitado 10.000,00\nMonto pagado 12.000,00', cuentas);
  assert.strictEqual(r2.monto, 12000); assert.ok(r2.montoDudoso);
});
console.log(ok + ' pruebas correctas');
