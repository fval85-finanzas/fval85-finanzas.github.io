// v2.2: deuda real de tarjetas (Fecha del saldo) y "Me deben".  TZ=America/Costa_Rica node pruebas/v22.test.js
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { hojaSim } = require('./hoja-simulada');
const C = require('../web/js/calculos.js');
function tabla(nombre, filaEnc, enc, filas) {
  const h = hojaSim(nombre);
  h.getRange(filaEnc, 1, 1, enc.length).setValues([enc]);
  filas.forEach((f, i) => h.getRange(filaEnc + 1 + i, 1, 1, f.length).setValues([f]));
  return h;
}
const hojas = {
  'Cuentas': tabla('Cuentas', 4, ['Nombre (único)', 'Tipo', 'Banco', 'Últimos 4', 'Moneda principal', 'Límite ₡', 'Límite $', 'Día de corte', 'Día de pago', 'Activa', 'Saldo actual ₡', 'Saldo actual $', 'Notas'],
    [['Visa BCR', 'Tarjeta de crédito', 'BCR', '4821', 'CRC', 1500000, '', 15, 30, 'Sí', 100000, 0, '']]),
  'Movimientos': tabla('Movimientos', 4, ['Fecha', 'Comercio / descripción', 'Lugar', 'Monto', 'Moneda', 'Tipo', 'Cuenta / tarjeta', 'Categoría', 'Sobre', 'Origen', 'Autorización', 'Nota'],
    [[new Date('2026-10-30T15:00:00Z'), 'TIENDA', '', 45000, 'CRC', 'Gasto', 'Visa BCR', '', '', 'Correo', '1', '']])
};
const libro = { getSheetByName: (n) => hojas[n] || null, insertSheet: (n) => (hojas[n] = hojaSim(n)), getName: () => 'Finanzas' };
const props = {};
const ctx = {
  console: { log() {} }, SpreadsheetApp: { getActive: () => libro }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'apps-script-simple', 'Codigo.gs'), 'utf8'), ctx);
let ok = 0;
function prueba(n, f) { try { f(); ok++; console.log('✅ ' + n); } catch (e) { console.log('❌ ' + n + '\n   ' + e.stack.split('\n').slice(0, 4).join('\n   ')); process.exitCode = 1; } }
const J = (x) => JSON.parse(JSON.stringify(x));
const filas = (n, c) => J(ctx.leerTabla_(n, c).filas);

prueba('preparación 2.2: columnas nuevas (una sola vez)', () => {
  ctx.prepararV22_(); ctx.prepararV22_();
  assert.ok(J(ctx.columnas_(hojas['Cuentas'], 4))['Fecha del saldo']);
  const mc = J(ctx.columnas_(hojas['Movimientos'], 4)); assert.ok(mc['Para otra persona'] && mc['Cobro']);
  assert.strictEqual(props.V22_LISTO, 'si');
});
prueba('actualizar saldo de una tarjeta guarda saldo y fecha', () => {
  ctx.actualizarSaldoCuenta_(5, 232800, 10, '2026-10-31T12:00:00Z');
  const r = filas('Cuentas', 'Nombre (único)')[0];
  assert.strictEqual(r['Saldo actual ₡'], 232800); assert.strictEqual(r['Saldo actual $'], 10); assert.ok(r['Fecha del saldo']);
  assert.throws(() => ctx.actualizarSaldoCuenta_(99, 1, 1, null), /No encontré/);
});
prueba('marcar "Para otra persona" y "Cobro"', () => {
  ctx.marcarMovimiento_(5, 'Para otra persona', 'Mamá', { monto: 45000 });
  ctx.marcarMovimiento_(5, 'Cobro', 'Pagado', { monto: 45000 });
  const r = filas('Movimientos', 'Fecha')[0];
  assert.strictEqual(r['Para otra persona'], 'Mamá'); assert.strictEqual(r['Cobro'], 'Pagado');
});
prueba('deuda viva: saldo + compras después de la fecha − pagos', () => {
  const c = { nombre: 'Visa', saldoCRC: 100000, saldoUSD: 0, fechaSaldo: '2026-10-20T18:00:00Z' };
  const d = { movimientos: [
    { fecha: '2026-10-20T20:00:00Z', cuenta: 'Visa', tipo: 'Gasto', monto: 999, moneda: 'CRC' },        // mismo día: ya estaba en el saldo
    { fecha: '2026-10-22T15:00:00Z', cuenta: 'Visa', tipo: 'Gasto', monto: 20000, moneda: 'CRC' },
    { fecha: '2026-10-23T15:00:00Z', cuenta: 'Visa', tipo: 'Compra tasa cero', monto: 60000, moneda: 'CRC' },
    { fecha: '2026-10-24T15:00:00Z', cuenta: 'Visa', tipo: 'Gasto', monto: 25.99, moneda: 'USD' },
    { fecha: '2026-10-25T15:00:00Z', cuenta: 'Visa', tipo: 'Pago de tarjeta', monto: 50000, moneda: 'CRC' },
    { fecha: '2026-10-25T15:00:00Z', cuenta: 'Otra', tipo: 'Gasto', monto: 7, moneda: 'CRC' }] };
  const r = C.deudaTarjeta(d, c);
  assert.strictEqual(r.CRC, 130000); assert.strictEqual(r.USD, 25.99); assert.strictEqual(r.compras, 3);
  assert.strictEqual(C.deudaTarjeta(d, { nombre: 'Visa', saldoCRC: 5 }).CRC, 5);   // sin fecha: no se mueve
});
prueba('Me deben: no es gasto mío, sugiere el pago y el cobro no cuenta como ingreso', () => {
  const d = { movimientos: [
    { fila: 5, fecha: '2026-10-27T15:00:00Z', comercio: 'TIENDA', tipo: 'Gasto', monto: 45000, moneda: 'CRC', cuenta: 'Visa', para: 'Mamá' },
    { fila: 6, fecha: '2026-10-28T15:00:00Z', comercio: 'SINPE recibido de MAMA', tipo: 'Ingreso', monto: 45000, moneda: 'CRC' },
    { fila: 7, fecha: '2026-10-28T15:00:00Z', comercio: 'Super', tipo: 'Gasto', monto: 1000, moneda: 'CRC', categoria: 'Super' }],
    tasaCero: [], sobres: [], cuentas: [] };
  const md = C.meDeben(d);
  assert.strictEqual(md.total.CRC, 45000); assert.strictEqual(md.sugerencias.length, 1); assert.strictEqual(md.sugerencias[0].ingreso.fila, 6);
  const res = C.resumenMes(d, new Date(2026, 9, 1));
  assert.strictEqual(res.gastos.CRC, 1000); assert.strictEqual(res.porRevisar, 0);
  d.movimientos[0].cobro = 'Pagado'; d.movimientos[1].cobro = 'Pago de Mamá';
  assert.strictEqual(C.meDeben(d).lista.length, 0);
  assert.strictEqual(C.resumenMes(d, new Date(2026, 9, 1)).ingresos.CRC, 0);
  assert.strictEqual(C.sentidoSobre(d, d.movimientos[0]), null);
  assert.strictEqual(C.sentidoSobre(d, d.movimientos[1]), 'entra');
});
console.log(ok + ' pruebas correctas');
